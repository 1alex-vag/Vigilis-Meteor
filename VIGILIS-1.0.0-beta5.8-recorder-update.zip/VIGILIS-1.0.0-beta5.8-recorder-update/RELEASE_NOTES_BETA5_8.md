# VIGILIS 1.0.0 Beta 5.8 – Recorder Update

## Added

- Asynchronous event-video writer running in its own worker thread.
- Fixed two-second raw-frame ring buffer with camera sequence numbers.
- Recording-health data in every new event JSON:
  - expected frames
  - written frames
  - source-dropped frames
  - writer-queue-dropped frames
- Bounded writer queue to isolate camera acquisition and detection from SSD latency.

## Changed

- Removed JPEG encoding and decoding from the pre-event recording path.
- Buffered frames now join live frames in sequence inside the same writer worker.
- MP4 creation, buffered-frame flushing, and ongoing disk writes no longer block the detector loop.

## Unchanged

- Two-second pre-event duration.
- Detection and classification thresholds.
- Event Browser, Telegram, Diagnostics, Climate Layout, storage fallback, and Lens Cover behavior.

## Test focus

Review newly recorded event videos around the two-second transition. The event JSON contains a `recording_health` section that reports any detected frame gaps or writer-queue losses.
