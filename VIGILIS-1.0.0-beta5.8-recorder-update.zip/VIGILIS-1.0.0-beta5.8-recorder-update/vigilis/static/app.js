let state=null;
const $=s=>document.querySelector(s);
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
function fmt(v,suffix=''){return v===null||v===undefined?'—':`${v}${suffix}`}
function healthScore(s){
  let score=100;
  if(!s.camera.camera_ok)score-=35;
  if(s.detector.mode==='disabled'){} else if(!s.detector.running && s.detector.mode!=='waiting for sunset' && s.detector.mode!=='waiting for schedule')score-=20;
  if(s.cover.state==='error'||s.cover.state==='fault')score-=25;
  if(s.sensor.status==='warning')score-=5;
  if(s.sensor.status==='fault'&&s.config.sensor.dht22_enabled)score-=10;
  if((s.system.cpu_temp_c||0)>75)score-=15;
  if(s.system.disk_free_gb<5)score-=15;
  if((s.system.ram_percent||0)>90)score-=10;
  return Math.max(0,score)
}
async function api(url,options={}){const r=await fetch(url,{headers:{'Content-Type':'application/json',...(options.headers||{})},...options});if(r.status===204)return null;const d=await r.json();if(!r.ok)throw new Error(d.error||'Request failed');return d}
function setPage(name){document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.page===name));$(`#page-${name}`).classList.add('active');if(name==='diagnostics'){loadLogs();loadEnvironmentHistory();}if(name==='events'&&!eventArchiveLoaded)reloadEventArchive()}
document.querySelectorAll('.nav').forEach(n=>n.addEventListener('click',()=>setPage(n.dataset.page)));
function render(s){const iv=$('#installedVersion');if(iv)iv.textContent=s.version;
  state=s;
  $('#observationLabel').textContent=s.observation.label;
  $('#sunAltitude').textContent=fmt(s.observation.sun_altitude,'°');
  const next=s.cover_automation?.next_action||'';$('#nextAction').textContent=next;$('#nextAction').hidden=!next;
  $('#cameraPill').textContent=s.camera.camera_ok?`${s.camera.fps} FPS`:'Offline';
  const eventSummary=s.event_summary||{};$('#eventsToday').textContent=eventSummary.total??s.detector.events_today??0;
  $('#detectorMode').textContent=`${s.detector.mode} · 🌠 ${eventSummary.meteor??0} · ✈ ${eventSummary.aircraft??0} · ? ${eventSummary.unknown??0}`;
  const hs=healthScore(s); $('#healthScore').textContent=`${hs}%`; $('#healthText').textContent=hs>=90?'Nominal':hs>=70?'Operational with notices':'Fault';
  const dome=s.sensor.dome||s.sensor,outdoor=s.sensor.outdoor||{}; $('#temperature').textContent=fmt(dome.temperature_c,' °C'); $('#humidity').textContent=fmt(dome.humidity,' %'); const domeDiag=$('#diagDomeTemp'),od=$('#diagOutdoorTemp'),td=$('#diagTempDelta'); if(domeDiag)domeDiag.textContent=fmt(dome.temperature_c,' °C');if(od)od.textContent=fmt(outdoor.temperature_c,' °C');if(td)td.textContent=(dome.temperature_c!=null&&outdoor.temperature_c!=null)?`${(dome.temperature_c-outdoor.temperature_c).toFixed(1)} °C`:'—'; const dh=$('#diagDomeHumidity'),oh=$('#diagOutdoorHumidity'),hd=$('#diagHumidityDelta');if(dh)dh.textContent=fmt(dome.humidity,' %');if(oh)oh.textContent=fmt(outdoor.humidity,' %');if(hd)hd.textContent=(dome.humidity!=null&&outdoor.humidity!=null)?`${(dome.humidity-outdoor.humidity).toFixed(1)} %`:'—';
  $('#heaterState').textContent=`${s.heater.mode} / ${s.heater.state} · ${fmt(s.heater.output_percent,' %')}`; $('#coverState').textContent=s.cover.installed===false?'Disabled':s.cover.state;
  document.querySelectorAll('[onclick^="coverAction"]').forEach(b=>b.disabled=s.cover.installed===false);
  const et=$('#environmentTemp'),eh=$('#environmentHumidity'),es=$('#environmentHeaterStatus'),eo=$('#environmentHeaterOutput'); if(et)et.textContent=fmt(dome.temperature_c,' °C'); if(eh)eh.textContent=fmt(dome.humidity,' %'); if(es)es.textContent=`${s.heater.mode} · ${s.heater.state}`; if(eo)eo.textContent=fmt(s.heater.output_percent,' %');
  $('#cpuLoad').textContent=fmt(s.system.cpu_percent,' %'); const sc=s.storage||{}; if($('#storageCurrentPath'))$('#storageCurrentPath').textContent=sc.path||'—';if($('#storageFreeSpace'))$('#storageFreeSpace').textContent=fmt(sc.free_gb,' GB');if($('#storageFavorites'))$('#storageFavorites').textContent=fmt(sc.favorites); $('#cpuTemp').textContent=fmt(s.system.cpu_temp_c,' °C'); $('#ramLoad').textContent=fmt(s.system.ram_percent,' %'); $('#diskFree').textContent=fmt(s.system.disk_free_gb,' GB'); renderDiagnosticMetrics(s);
  const disabled=s.config.camera.preview==='disabled'; $('#previewImage').style.display=disabled?'none':'block'; $('#previewDisabled').classList.toggle('active',disabled);
  if(s.config.ui.background_url){document.body.style.setProperty('--bg-image',`url('${s.config.ui.background_url}')`);const bg=$('#globalBackground');if(bg)bg.style.backgroundImage=`linear-gradient(rgba(3,9,14,.28),rgba(3,9,14,.50)),url('${s.config.ui.background_url}')`;}
  $('#cameraDiagnostics').textContent=JSON.stringify(s.camera,null,2); $('#coverDiagnostics').textContent=JSON.stringify(s.cover,null,2);
  const vm=$('#visionMedian'),vg=$('#visionGamma'),vb=$('#visionBackground'),vp=$('#visionBrightPoints'); if(vm)vm.textContent=fmt(s.camera.vision_median); if(vg)vg.textContent=fmt(s.camera.vision_gamma); if(vb)vb.textContent=fmt(s.camera.vision_background); if(vp)vp.textContent=fmt(s.camera.vision_bright_points);
  const dd=s.detector.debug||{}; const dp=$('#detectionDebugPanel');
  if(dp){
    const enabled=!!s.config.detection.debug_enabled; dp.hidden=!enabled;
    if(enabled){
      $('#debugState').textContent=dd.state||'—';
      $('#debugMotion').textContent=dd.motion_percent===undefined?'—':`${dd.motion_percent}%`;
      $('#debugObjects').textContent=`${dd.objects??0} / ${dd.tracks??0}`;
      $('#debugBlob').textContent=dd.largest_blob_area===undefined?'—':`${dd.largest_blob_area} px²`;
      $('#debugScores').textContent=`${dd.single_frame_score??0} / ${dd.fast_trail_score??0} / ${dd.tracked_object_score??0}`;
      $('#debugReason').textContent=dd.reason||'—';
    }
  }
  if(!eventArchiveLoaded)renderEventsStable(s.events); renderTimeline(s.events); loadForm(s.config)
}
function renderTimeline(events){const el=$('#timeline');if(!events.length){el.className='timeline empty';el.textContent='No events recorded.';return}el.className='timeline';el.innerHTML=events.slice(0,8).map(e=>`<div class="timeline-item"><span>${new Date(e.created_at).toLocaleTimeString()}</span><strong>${e.classification}</strong><span>Score ${e.score}</span></div>`).join('')}
let lastEventSignature='';
function renderEventsStable(events){
  const signature=events.map(e=>`${e.id}:${e.classification}:${e.favorite}`).join('|');
  if(signature===lastEventSignature)return;
  if($('#videoModal').classList.contains('active'))return;
  lastEventSignature=signature;
  renderEvents(events);
}
function renderEvents(events){const el=$('#eventGrid');if(!events.length){el.innerHTML='<p class="hint">No events recorded.</p>';return}el.innerHTML=eventCards(events)}
let formLoaded=false;
function loadForm(c){
  if(formLoaded)return; formLoaded=true;
  $('#previewSetting').value=c.camera.preview; $('#cameraOutputMode').value=c.camera.output_mode||'mono'; $('#cameraMode').value=c.camera.mode; $('#cameraSource').value=c.camera.source||''; $('#cameraPreset').value=c.camera.preset||'meteor_hunter'; $('#cameraTuning').value=c.camera.tuning_profile||'meteor'; $('#cameraCustomTuning').value=c.camera.custom_tuning_file||''; $('#cameraFps').value=String(c.camera.fps||10); $('#cameraVisionMode').value=c.camera.vision_mode||({'natural':'off','enhanced':'balanced','extreme':'deep'}[c.camera.image_enhancement]||'balanced'); $('#cameraVisionTnr').value=c.camera.vision_tnr||'auto'; $('#visionTargetMedian').value=c.camera.vision_target_median??38; $('#visionMaxGain').value=c.camera.vision_max_gain??2.2; $('#visionGammaMin').value=c.camera.vision_gamma_min??0.62; $('#cameraExposureCompensation').value=c.camera.exposure_compensation??0; $('#cameraExposureUs').value=c.camera.exposure_us||33000; $('#cameraGain').value=c.camera.gain||8; $('#zwoCameraIndex').value=c.camera.zwo_camera_index??0; $('#zwoBin').value=String(c.camera.zwo_bin||1); $('#zwoPixelFormat').value=c.camera.zwo_pixel_format||'RAW8'; $('#zwoBayerMode').value=c.camera.zwo_bayer_mode||'auto'; $('#zwoExposure').value=c.camera.zwo_exposure_us||50000; $('#zwoGain').value=c.camera.zwo_gain||100; $('#zwoAutoExposure').checked=c.camera.zwo_auto_exposure!==false; $('#zwoAutoGain').checked=c.camera.zwo_auto_gain!==false; updateCameraPresetUI();
  $('#locationMode').value=c.location.mode||'manual'; $('#locationName').value=c.location.name||''; $('#locationLatitude').value=c.location.latitude??''; $('#locationLongitude').value=c.location.longitude??''; $('#locationElevation').value=c.location.elevation_m??0; $('#locationTimezone').value=c.location.timezone||Intl.DateTimeFormat().resolvedOptions().timeZone||'';
  $('#detectionScheduleMode').value=c.detection.schedule_mode||(c.detection.enabled?'always':'disabled');
  $('#detectionStartSun').value=c.detection.start_sun_altitude??-6; $('#detectionStopSun').value=c.detection.stop_sun_altitude??-4;
  $('#detectionCustomStart').value=c.detection.custom_start||'20:00'; $('#detectionCustomStop').value=c.detection.custom_stop||'06:00';
  $('#sensitivity').value=c.detection.sensitivity; $('#sensitivityOut').textContent=c.detection.sensitivity; $('#minScore').value=c.detection.min_event_score; $('#minScoreOut').textContent=c.detection.min_event_score;
  const cc=c.classification||{};$('#classificationEnabled').checked=cc.enabled!==false;$('#aircraftThreshold').value=cc.aircraft_threshold??70;$('#meteorThreshold').value=cc.meteor_threshold??78;
  $('#singleFlashDelta').value=c.detection.single_flash_delta??35; $('#trailMinLength').value=c.detection.trail_min_length_px??12; $('#slowTrackFrames').value=c.detection.slow_track_min_frames??3; $('#trackDistance').value=c.detection.track_distance_px??70; $('#ignoreBottomPercent').value=c.detection.ignore_bottom_percent??0; $('#ignoreBottomOut').textContent=`${c.detection.ignore_bottom_percent??0}%`; $('#detectionDebug').checked=!!c.detection.debug_enabled;
  $('#recordingMode').value=c.recording.mode; $('#fixedSeconds').value=c.recording.fixed_seconds; $('#eventEndSeconds').value=c.recording.event_end_seconds; $('#maxEventSeconds').value=c.recording.max_event_seconds;
  $('#coverInstalled').checked=c.cover.installed!==false;$('#coverMode').value=c.cover.mode||'automatic';$('#coverOpenLead').value=c.cover.open_before_detection_deg??0.5;$('#coverStabilization').value=c.cover.stabilization_seconds??5;$('#coverOpeningTimeout').value=c.cover.opening_timeout_seconds??20;$('#coverClosingTimeout').value=c.cover.closing_timeout_seconds??20; $('#coverDirection').value=c.cover.direction||'normal'; $('#coverSpeedMinute').value=c.cover.speed_steps_per_minute||12000; $('#coverOpenOffset').value=c.cover.open_offset_steps||0; $('#coverClosedOffset').value=c.cover.closed_offset_steps||0; $('#coverHallConfirm').value=c.cover.hall_confirm_ms??25;updateCoverSettingsVisibility();
  const dse=$('#domeSensorEnabled'),ose=$('#outdoorSensorEnabled');if(dse)dse.checked=c.sensor?.dht22_enabled!==false;if($('#domeSensorPin'))$('#domeSensorPin').value=c.gpio?.dht_pin??4;if(ose)ose.checked=!!c.sensor?.outdoor_dht22_enabled;if($('#outdoorSensorPin'))$('#outdoorSensorPin').value=c.gpio?.outdoor_dht_pin??18; populateTelegram(c); $('#heaterMode').value=(c.heater.mode==='manual'?'on':(c.heater.mode||'off')); $('#heaterRegulation').value=c.heater.regulation||'time_window'; $('#targetTemp').value=c.heater.target_temp_c; $('#humidityTrigger').value=c.heater.humidity_trigger_percent; $('#heaterManualOutput').value=c.heater.manual_output_percent??35; $('#heaterManualOutputOut').textContent=`${c.heater.manual_output_percent??35}%`; $('#heaterWindow').value=String(c.heater.window_seconds||60); $('#bgOpacity').value=c.ui.background_opacity; $('#bgOpacityOut').textContent=`${c.ui.background_opacity}%`; const st=c.storage||{};$('#storageCustomPath').value=st.recordings_path||'';$('#automaticCleanup').checked=!!st.automatic_cleanup;$('#retentionDays').value=String(st.retention_days||7);$('#overlayMargin').value=String(st.overlay_margin_percent??50);scanStorageLocations()
}
$('#sensitivity')?.addEventListener('input',e=>$('#sensitivityOut').textContent=e.target.value); $('#ignoreBottomPercent')?.addEventListener('input',e=>$('#ignoreBottomOut').textContent=`${e.target.value}%`); $('#heaterManualOutput')?.addEventListener('input',e=>$('#heaterManualOutputOut').textContent=`${e.target.value}%`); $('#minScore')?.addEventListener('input',e=>$('#minScoreOut').textContent=e.target.value); $('#bgOpacity')?.addEventListener('input',e=>{$('#bgOpacityOut').textContent=`${e.target.value}%`;document.body.style.setProperty('--bg-opacity',e.target.value/100);const bg=$('#globalBackground');if(bg)bg.style.opacity=e.target.value/100});
async function save(section,data){const r=await api('/api/settings',{method:'POST',body:JSON.stringify({[section]:data})});toast('Settings saved.');formLoaded=false;await refresh();if(r.restart_required&&confirm('A VIGILIS restart is required to apply these changes. Restart now?')){await api('/api/system/restart-service',{method:'POST',body:'{}'});toast('VIGILIS is restarting…')}}
const cameraPresetInfo={meteor_hunter:['Meteor priority: short exposures with user-selectable 1–15, 20, 25 or 30 FPS.',5,'meteor'],moon:['Shorter exposure for moonlight and bright sky.',10,'moon'],day_calibration:['Daylight preview for focus and maintenance.',15,'standard'],expert:['Full manual exposure and gain control.',5,null]};
function updateCameraPresetUI(){const preset=$('#cameraPreset').value;const info=cameraPresetInfo[preset]||cameraPresetInfo.meteor_hunter;$('#cameraPresetHint').textContent=info[0];$('#cameraAdvanced').classList.toggle('expert-active',preset==='expert')}
$('#cameraPreset')?.addEventListener('change',e=>{const info=cameraPresetInfo[e.target.value];if(info){$('#cameraFps').value=String(info[1]);if(info[2])$('#cameraTuning').value=info[2]}updateCameraPresetUI()});
function saveCamera(){const preset=$('#cameraPreset').value;const profile=preset==='expert'?'manual':'automatic';save('camera',{preview:$('#previewSetting').value,output_mode:$('#cameraOutputMode').value,mode:$('#cameraMode').value,source:$('#cameraSource').value,preset,profile,tuning_profile:$('#cameraTuning').value,custom_tuning_file:$('#cameraCustomTuning').value,fps:+$('#cameraFps').value,vision_mode:$('#cameraVisionMode').value,vision_tnr:$('#cameraVisionTnr').value,vision_target_median:+($('#visionTargetMedian').value||38),vision_max_gain:+($('#visionMaxGain').value||2.2),vision_gamma_min:+($('#visionGammaMin').value||0.62),exposure_mode:profile==='manual'?'manual':'auto',exposure_compensation:+$('#cameraExposureCompensation').value,exposure_us:+$('#cameraExposureUs').value,gain:+$('#cameraGain').value,zwo_camera_index:+$('#zwoCameraIndex').value,zwo_bin:+$('#zwoBin').value,zwo_pixel_format:$('#zwoPixelFormat').value,zwo_exposure_us:+$('#zwoExposure').value,zwo_gain:+$('#zwoGain').value,zwo_auto_exposure:$('#zwoAutoExposure').checked,zwo_auto_gain:$('#zwoAutoGain').checked,zwo_bayer_mode:$('#zwoBayerMode').value})}
async function scanCameras(){const box=$('#cameraDiscovery');box.textContent='Scanning…';try{const d=await api('/api/cameras');const rows=[];rows.push(`<div><strong>CSI</strong><span>${d.csi.available?'Available':'Not available'}</span></div>`);if(d.zwo.sdk_available){if(d.zwo.cameras.length)d.zwo.cameras.forEach(c=>rows.push(`<div><strong>${c.name}</strong><span>ZWO #${c.index} · ${c.max_width}×${c.max_height}</span></div>`));else rows.push('<div><strong>ZWO SDK</strong><span>No camera connected</span></div>')}else rows.push(`<div><strong>ZWO SDK</strong><span>${d.zwo.error||'Not installed'}</span></div>`);box.innerHTML=rows.join('');$('#cameraManagerSummary').textContent=`${d.csi.available?'CSI ':''}${d.zwo.cameras?.length?'· ZWO ':''}`||'No camera'}catch(e){box.textContent=e.message}}
function saveObservation(){save('observation',{mode:$('#observationMode').value,start_sun_altitude:+$('#startSun').value,stop_sun_altitude:+$('#stopSun').value})}
function saveLocation(){save('location',{mode:$('#locationMode').value,name:$('#locationName').value||'VIGILIS Station',latitude:+$('#locationLatitude').value,longitude:+$('#locationLongitude').value,elevation_m:+$('#locationElevation').value||0,timezone:$('#locationTimezone').value||Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC'})}
function detectLocation(){
  if(!navigator.geolocation){toast('Browser location is not available.');return}
  toast('Requesting location permission...');
  navigator.geolocation.getCurrentPosition(
    pos=>{
      $('#locationLatitude').value=pos.coords.latitude.toFixed(6);
      $('#locationLongitude').value=pos.coords.longitude.toFixed(6);
      $('#locationTimezone').value=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC';
      $('#locationMode').value='automatic';
      if(Number.isFinite(pos.coords.altitude))$('#locationElevation').value=Math.round(pos.coords.altitude);
      toast('Location detected. Save the location settings.');
    },
    err=>toast(`Location unavailable: ${err.message}`),
    {enableHighAccuracy:true,timeout:15000,maximumAge:60000}
  )
}

async function saveDetection(){const mode=$('#detectionScheduleMode').value;await save('detection',{enabled:mode!=='disabled',schedule_mode:mode,start_sun_altitude:+$('#detectionStartSun').value,stop_sun_altitude:+$('#detectionStopSun').value,custom_start:$('#detectionCustomStart').value,custom_stop:$('#detectionCustomStop').value,sensitivity:+$('#sensitivity').value,min_event_score:+$('#minScore').value,single_flash_delta:+$('#singleFlashDelta').value,trail_min_length_px:+$('#trailMinLength').value,slow_track_min_frames:+$('#slowTrackFrames').value,track_distance_px:+$('#trackDistance').value,ignore_bottom_percent:+$('#ignoreBottomPercent').value,debug_enabled:$('#detectionDebug').checked});await save('classification',{enabled:$('#classificationEnabled').checked,sort_into_folders:true,aircraft_threshold:+$('#aircraftThreshold').value,meteor_threshold:+$('#meteorThreshold').value})}
async function uploadDetectionMask(){const f=$('#detectionMaskFile').files[0];if(!f)return toast('Select a mask image first.');const fd=new FormData();fd.append('mask',f);const r=await fetch('/api/detection/mask',{method:'POST',body:fd});const d=await r.json();if(!r.ok||!d.ok)return toast(d.error||'Mask upload failed');toast('Detection mask saved and activated.')}
async function clearDetectionMask(){if(!confirm('Clear the custom detection mask?'))return;await api('/api/detection/mask',{method:'DELETE'});toast('Detection mask cleared.')}
function saveRecording(){save('recording',{mode:$('#recordingMode').value,fixed_seconds:+$('#fixedSeconds').value,event_end_seconds:+$('#eventEndSeconds').value,max_event_seconds:+$('#maxEventSeconds').value})}
function updateCoverSettingsVisibility(){const enabled=$('#coverInstalled')?.checked!==false;const body=$('#coverSettingsBody');if(body){body.classList.toggle('module-disabled',!enabled);body.querySelectorAll('input,select').forEach(el=>el.disabled=!enabled)}}
function saveCover(){save('cover',{installed:$('#coverInstalled').checked,mode:$('#coverMode').value,open_before_detection_deg:+$('#coverOpenLead').value,stabilization_seconds:+$('#coverStabilization').value,opening_timeout_seconds:+$('#coverOpeningTimeout').value,closing_timeout_seconds:+$('#coverClosingTimeout').value,direction:$('#coverDirection').value,speed_steps_per_minute:+$('#coverSpeedMinute').value,open_offset_steps:+$('#coverOpenOffset').value,closed_offset_steps:+$('#coverClosedOffset').value,hall_confirm_ms:+$('#coverHallConfirm').value})}
async function saveEnvironment(){const payload={sensor:{dht22_enabled:$('#domeSensorEnabled').checked,outdoor_dht22_enabled:$('#outdoorSensorEnabled').checked},gpio:{dht_pin:+$('#domeSensorPin').value,outdoor_dht_pin:+$('#outdoorSensorPin').value},heater:{mode:$('#heaterMode').value,regulation:$('#heaterRegulation').value,target_temp_c:+$('#targetTemp').value,humidity_trigger_percent:+$('#humidityTrigger').value,manual_output_percent:+$('#heaterManualOutput').value,window_seconds:+$('#heaterWindow').value}};const r=await api('/api/settings',{method:'POST',body:JSON.stringify(payload)});toast('Environment settings saved.');formLoaded=false;await refresh();if(r.restart_required&&confirm('A VIGILIS restart is required to apply sensor changes. Restart now?')){await api('/api/system/restart-service',{method:'POST',body:'{}'});toast('VIGILIS is restarting…')}}
function saveHeater(){saveEnvironment()}
async function coverAction(a){toast(`Lens cover: ${a}`);const body=(a==='jog-open'||a==='jog-close')?JSON.stringify({steps:100}):'{}';try{const r=await api(`/api/cover/${a}`,{method:'POST',body});toast(r.ok?`Lens cover ${r.state||a}: ${r.reason||''}`:r.error)}catch(e){toast(e.message)}}
async function heaterAction(m){await api(`/api/heater/${m}`,{method:'POST',body:'{}'});toast(`Heater mode: ${m}`)}
async function classify(id,v){await api(`/api/events/${id}`,{method:'POST',body:JSON.stringify({classification:v})});lastEventSignature=''; if(eventArchiveLoaded)reloadEventArchive(); else refresh()}
async function favorite(id,v){await api(`/api/events/${id}`,{method:'POST',body:JSON.stringify({favorite:v})});lastEventSignature=''; if(eventArchiveLoaded)reloadEventArchive(); else refresh()}

let currentEvent=null;const eventCache={};
function playEvent(id){currentEvent=eventCache[id]||null;const m=$('#videoModal'),v=$('#eventVideo');v.src=currentEvent.video_url||`/media/${currentEvent.video}`;m.classList.add('active');$('#eventOverlayInfo').textContent=currentEvent.detections?.length?`${currentEvent.detections.length} detector samples · ${currentEvent.trigger_path||'event'} · score ${currentEvent.score}`:'No detection coordinates stored for this event';v.onloadedmetadata=()=>{resizeEventOverlay();drawEventOverlay()};v.ontimeupdate=drawEventOverlay;window.addEventListener('resize',resizeEventOverlay,{once:true});v.play().catch(()=>{})}
function resizeEventOverlay(){const v=$('#eventVideo'),c=$('#eventOverlay');if(!v.videoWidth||!v.videoHeight)return;c.width=v.videoWidth;c.height=v.videoHeight;drawEventOverlay()}
function drawEventOverlay(){const c=$('#eventOverlay'),ctx=c?.getContext('2d'),v=$('#eventVideo');if(!ctx||!v)return;ctx.clearRect(0,0,c.width,c.height);if(!$('#showEventOverlay')?.checked||!currentEvent?.detections?.length)return;let best=null,dist=Infinity;for(const d of currentEvent.detections){const delta=Math.abs((d.time||0)-v.currentTime);if(delta<dist){dist=delta;best=d}}if(!best||dist>Math.max(.35,2/(currentEvent.fps||5)))return;const b=best.box||{};const margin=((state?.config?.storage?.overlay_margin_percent??50)/100);let bx=b.x,by=b.y,bw=b.w,bh=b.h;bx=Math.max(0,bx-bw*margin);by=Math.max(0,by-bh*margin);bw=Math.min(1-bx,bw*(1+2*margin));bh=Math.min(1-by,bh*(1+2*margin));const x=bx*c.width,y=by*c.height,w=bw*c.width,h=bh*c.height;ctx.strokeStyle='#43e36c';ctx.lineWidth=Math.max(2,c.width/900);ctx.shadowColor='rgba(67,227,108,.65)';ctx.shadowBlur=8;ctx.strokeRect(x,y,w,h);ctx.shadowBlur=0}
function closeVideo(event){if(event&&event.target!==event.currentTarget&& !event.target.classList.contains('video-close'))return;const m=$('#videoModal'),v=$('#eventVideo');v.pause();v.removeAttribute('src');v.load();currentEvent=null;const c=$('#eventOverlay');c?.getContext('2d')?.clearRect(0,0,c.width,c.height);m.classList.remove('active')}

async function removeEvent(id){if(!confirm('Delete this event? This also removes its thumbnail, metadata and generated overlay video.'))return;try{await api(`/api/events/${id}`,{method:'DELETE'});}catch(e){return toast(e.message)}lastEventSignature='';delete eventCache[id];if(eventArchiveLoaded)reloadEventArchive();else refresh()}
async function uploadBackground(){const f=$('#backgroundFile').files[0];if(!f)return toast('Select a file first.');const fd=new FormData();fd.append('background',f);const r=await fetch('/api/ui/background',{method:'POST',body:fd});const d=await r.json();if(d.ok){document.body.style.setProperty('--bg-image',`url('${d.url}')`);const bg=$('#globalBackground');if(bg){bg.style.backgroundImage=`linear-gradient(rgba(3,9,14,.28),rgba(3,9,14,.50)),url('${d.url}')`;bg.style.opacity=$('#bgOpacity').value/100;}toast('Background uploaded and saved.')}else toast(d.error||'Upload failed')}

async function saveAppearance(){
  const opacity=Math.max(0,Math.min(100,Number($('#bgOpacity').value||72)));
  await save('ui',{background_opacity:opacity});
  document.body.style.setProperty('--bg-opacity',opacity/100);
  const bg=$('#globalBackground'); if(bg) bg.style.opacity=opacity/100;
  toast('Appearance saved.');
}
function storageDeviceCards(devices){
  const root=$('#storageDevices');if(!root)return;
  if(!devices?.length){root.innerHTML='<p class="hint">No external USB storage detected.</p>';return}
  root.innerHTML=devices.map(d=>{
    const parts=(d.partitions||[]).map(p=>`<div class="storage-part"><span>${p.device} · ${p.filesystem||'No filesystem'} · ${p.size_gb} GB</span>${p.mounted?`<strong>Mounted at ${p.mountpoint}</strong>`:`<button onclick="prepareStorage('${p.device}','mount')">Mount</button>`}</div>`).join('');
    return `<article class="storage-device"><div><strong>${d.name}</strong><small>${d.device} · ${d.size_gb} GB</small></div>${parts||`<div class="storage-warning"><span>⚠ No partition found</span><button class="danger" onclick="prepareStorage('${d.device}','initialize')">Initialize as EXT4</button></div>`}</article>`
  }).join('')
}
async function scanStorageLocations(){try{const d=await api('/api/storage/locations');const select=$('#storageLocation');if(!select)return;const current=$('#storageCustomPath').value||d.current?.path||'';select.innerHTML='<option value="">Internal VIGILIS storage</option>'+d.locations.map(x=>`<option value="${x.path}">${x.name} · ${x.free_gb} GB free</option>`).join('');if([...select.options].some(o=>o.value===current))select.value=current;select.onchange=()=>{if(select.value)$('#storageCustomPath').value=select.value};storageDeviceCards(d.devices||[])}catch(e){toast(e.message)}}
async function prepareStorage(device,action){
  let confirmation='';
  if(action==='initialize'){if(!confirm(`Initialize ${device} as EXT4?

ALL DATA ON THIS DRIVE WILL BE ERASED.`))return;confirmation=prompt('Type ERASE to confirm:')||'';if(confirmation!=='ERASE'){toast('Initialization cancelled.');return}}
  toast(action==='initialize'?'Initializing drive…':'Mounting drive…');
  try{const d=await api('/api/storage/prepare',{method:'POST',body:JSON.stringify({device,action,confirmation})});if(d.recordings_path)$('#storageCustomPath').value=d.recordings_path;toast(action==='initialize'?'Drive initialized and mounted.':'Drive mounted.');await scanStorageLocations()}catch(e){toast(e.message)}
}
async function saveStorage(){
  const path=$('#storageCustomPath').value.trim();
  const button=document.querySelector('button[onclick="saveStorage()"]');
  if(button){button.disabled=true;button.dataset.oldText=button.textContent;button.textContent='Testing storage…'}
  try{
    const d=await api('/api/storage/activate',{method:'POST',body:JSON.stringify({
      path,
      automatic_cleanup:$('#automaticCleanup').checked,
      retention_days:+$('#retentionDays').value,
      overlay_margin_percent:+$('#overlayMargin').value
    })});
    $('#storageCustomPath').value=d.path||path;
    if($('#storageCurrentPath'))$('#storageCurrentPath').textContent=d.storage?.path||d.path||'—';
    if($('#storageFreeSpace'))$('#storageFreeSpace').textContent=fmt(d.storage?.free_gb,' GB');
    if($('#storageFavorites'))$('#storageFavorites').textContent=fmt(d.storage?.favorites);
    toast(`Storage ready: ${d.path}`);
    await scanStorageLocations();
    await refresh();
    reloadEventArchive();
  }catch(e){toast(`Storage unchanged: ${e.message}`)}
  finally{if(button){button.disabled=false;button.textContent=button.dataset.oldText||'Save storage settings'}}
}
async function runCleanupNow(){if(!confirm('Run automatic cleanup now? Favorites remain protected.'))return;const d=await api('/api/storage/cleanup',{method:'POST',body:'{}'});toast(`${d.removed_events} old events removed.`);reloadEventArchive()}

async function uploadUpdate(){const f=$('#updateFile').files[0];if(!f)return toast('Select a .vup package first.');if(!f.name.toLowerCase().endsWith('.vup'))return toast('Only VIGILIS .vup packages are accepted.');const dev=$('#allowUnsignedUpdates')?.checked;const warning=dev?'Developer Mode is enabled. Install this trusted VIGILIS package?':`Install signed update ${f.name}?`;if(!confirm(warning))return;const fd=new FormData();fd.append('update',f);const st=$('#updateStatus');st.textContent='Uploading and verifying…';try{const r=await fetch('/api/update/upload',{method:'POST',body:fd});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.error||'Update rejected');st.textContent=`Verified ${d.version} (${d.trust||'signed'}). Installation started; VIGILIS will restart.`;toast('Update verified. Installing…')}catch(e){st.textContent=`Update rejected: ${e.message}`;toast(e.message)}}
async function systemAction(action){const labels={'restart-service':'restart VIGILIS','reboot':'restart the Raspberry Pi','shutdown':'shut down the Raspberry Pi'};if(!confirm(`Really ${labels[action]}?`))return;await api(`/api/system/${action}`,{method:'POST',body:'{}'});toast(`Requested: ${labels[action]}`)}
async function loadLogs(){for(const kind of ['user','developer']){const d=await api(`/api/logs/${kind}`);$(`#${kind}Log`).textContent=d.lines.join('\n')}}
let eventArchiveLoaded=false;
const EVENT_PAGE_SIZE=20;
const selectedEvents=new Set();
const eventArchiveState={day:'',classification:'meteor',offset:0,total:0,favorites:false,days:[]};
function friendlyEventDay(day){if(day==='unknown')return 'Older events';const value=`${day}T12:00:00`;const today=new Date();today.setHours(0,0,0,0);const eventDate=new Date(value);eventDate.setHours(0,0,0,0);const diff=Math.round((today-eventDate)/86400000);if(diff===0)return 'Today';if(diff===1)return 'Yesterday';return eventDate.toLocaleDateString(undefined,{day:'numeric',month:'long',year:'numeric'})}
function updateBulkBar(){const bar=$('#bulkEventBar');if(!bar)return;bar.hidden=selectedEvents.size===0;$('#selectedEventCount').textContent=`${selectedEvents.size} selected`}
function toggleEventSelection(id,checked){checked?selectedEvents.add(id):selectedEvents.delete(id);updateBulkBar()}
function clearEventSelection(){selectedEvents.clear();document.querySelectorAll('.event-select').forEach(x=>x.checked=false);updateBulkBar()}
async function deleteSelectedEvents(){if(!selectedEvents.size)return;if(!confirm(`Delete ${selectedEvents.size} selected events? Favorites will be protected.`))return;const d=await api('/api/events/delete-many',{method:'POST',body:JSON.stringify({ids:[...selectedEvents]})});toast(`${d.removed?.length||0} files removed${d.protected?.length?`; ${d.protected.length} favorites protected`:''}`);clearEventSelection();refreshEventArchive()}
async function reclassifyExisting(){if(!confirm('Analyse and sort all existing unclassified events? Existing manual classifications and favorites will be kept.'))return;toast('Classifying existing events…');try{const d=await api('/api/classification/reclassify',{method:'POST',body:JSON.stringify({only_unknown:true})});toast(`Classified ${d.processed} events · ${d.failed} failed`);refreshEventArchive()}catch(e){toast(e.message)}}
function selectedDayInfo(){return eventArchiveState.days.find(d=>d.date===eventArchiveState.day)||null}
function updateEventTabCounts(){const info=selectedDayInfo(),c=info?.classifications||{};$('#meteorTabCount').textContent=c.meteor||0;$('#aircraftTabCount').textContent=c.aircraft||0;$('#unknownTabCount').textContent=c.unknown||0;$('#allTabCount').textContent=info?.count||0;document.querySelectorAll('[data-event-filter]').forEach(b=>b.classList.toggle('active',b.dataset.eventFilter===eventArchiveState.classification))}
async function reloadEventArchive(){
  eventArchiveLoaded=true;clearEventSelection();
  const grid=$('#eventGrid');if(grid)grid.innerHTML='<p class="hint">Loading event index…</p>';
  try{
    const data=await api('/api/event-days');eventArchiveState.days=data.days||[];
    const select=$('#eventDaySelect'),previous=eventArchiveState.day;
    select.innerHTML=eventArchiveState.days.map(d=>`<option value="${d.date}">${friendlyEventDay(d.date)} · ${d.count} events</option>`).join('');
    if(previous&&eventArchiveState.days.some(d=>d.date===previous))eventArchiveState.day=previous;else eventArchiveState.day=eventArchiveState.days[0]?.date||'';
    select.value=eventArchiveState.day;eventArchiveState.favorites=false;
    $('#eventArchiveCount').textContent=`${data.total||0} events · ${eventArchiveState.days.length} days · ${data.favorites||0} favorites`;
    updateEventTabCounts();renderEventIndexProgress(data.index);
    if(!eventArchiveState.day){grid.innerHTML=data.index?.running?'<p class="hint">Indexing existing events…</p>':'<p class="hint">No events recorded.</p>';return}
    await loadSelectedEvents(true);
  }catch(e){grid.innerHTML=`<p class="hint">${e.message}</p>`}
}
async function refreshEventArchive(){await reloadEventArchive()}
function eventDayChanged(){eventArchiveState.day=$('#eventDaySelect').value;eventArchiveState.favorites=false;updateEventTabCounts();loadSelectedEvents(true)}
function setEventFilter(classification){eventArchiveState.classification=classification||'';eventArchiveState.favorites=false;updateEventTabCounts();loadSelectedEvents(true)}
async function showFavorites(){eventArchiveLoaded=true;eventArchiveState.favorites=true;eventArchiveState.day='';eventArchiveState.classification='';document.querySelectorAll('[data-event-filter]').forEach(b=>b.classList.remove('active'));$('#eventArchiveCount').textContent='Protected favorites';await loadSelectedEvents(true)}
async function loadSelectedEvents(replace=false){
  if(replace){eventArchiveState.offset=0;eventArchiveState.total=0;clearEventSelection();$('#eventGrid').innerHTML='<p class="hint">Loading events…</p>'}
  return loadMoreSelectedEvents(replace);
}
async function loadMoreSelectedEvents(replace=false){
  const params=new URLSearchParams({offset:String(eventArchiveState.offset),limit:String(EVENT_PAGE_SIZE)});
  if(eventArchiveState.day)params.set('date',eventArchiveState.day);if(eventArchiveState.classification)params.set('classification',eventArchiveState.classification);if(eventArchiveState.favorites)params.set('favorites','1');
  const data=await api(`/api/events?${params}`),items=data.events||[],grid=$('#eventGrid');
  if(replace||eventArchiveState.offset===0)grid.innerHTML=items.length?eventCards(items):'<p class="hint">No matching events.</p>';else if(items.length)grid.insertAdjacentHTML('beforeend',eventCards(items));
  eventArchiveState.offset+=items.length;eventArchiveState.total=data.total||0;const button=$('#eventLoadMore');button.hidden=!data.has_more;button.textContent=data.has_more?`Load more (${data.total-eventArchiveState.offset} remaining)`:'All events loaded';
}
function eventCards(events){events.forEach(e=>eventCache[e.id]=e);return events.map(e=>{const seq=e.daily_sequence?`#${String(e.daily_sequence).padStart(3,'0')}`:'';const time=new Date(e.created_at).toLocaleTimeString();return `<article class="event"><div style="position:relative"><label class="event-select-wrap"><input class="event-select" type="checkbox" onchange="toggleEventSelection('${e.id}',this.checked)"></label><img loading="lazy" src="${e.thumbnail_url||'/media/'+e.thumbnail}" alt="Event thumbnail">${e.detections?.length?'<span class="event-overlay-badge">Detection marked</span>':''}</div><div class="event-body"><div class="event-title"><strong>${seq?`${seq} · `:''}${time}</strong><span>${e.favorite?'⭐ Protected favorite':''}</span></div><small>${e.classification} · Score ${e.score}${e.duration_seconds?` · ${e.duration_seconds}s`:''} · ${String(e.storage_location||'').toUpperCase()||'—'}<br><span class="event-id">${e.id}</span></small><div class="event-controls"><select onchange="classify('${e.id}',this.value)">${['unknown','meteor','aircraft','satellite','insect','false_positive'].map(x=>`<option value="${x}" ${x===e.classification?'selected':''}>${x}</option>`).join('')}</select><button onclick="favorite('${e.id}',${!e.favorite})">${e.favorite?'Unfavorite':'Favorite'}</button><button onclick="playEvent('${e.id}')">Play</button><a href="${e.video_url||'/media/'+e.video}" download><button>MP4</button></a>${e.detections?.length?`<button onclick="downloadOverlay('${e.id}',this)">MP4 + Overlay</button>`:''}<button class="danger" onclick="removeEvent('${e.id}')" ${e.favorite?'title="Unfavorite before deleting"':''}>Delete</button></div></div></article>`}).join('')}
async function rebuildEventIndex(){if(!confirm('Rebuild the local event index from the selected recording drive? This runs in the background.'))return;const d=await api('/api/event-index/rebuild',{method:'POST',body:'{}'});toast(d.started?'Event index rebuild started.':(d.reason||'Index is already running.'));pollEventIndex()}
function renderEventIndexProgress(index){const el=$('#eventIndexProgress');if(!el||!index)return;el.hidden=!index.running;if(index.running){const total=index.total||0,processed=index.processed||0;el.textContent=`Indexing existing events: ${processed} / ${total||'…'}`}}
async function pollEventIndex(){try{const d=await api('/api/event-index/status');renderEventIndexProgress(d);if(d.running)setTimeout(pollEventIndex,1000);else reloadEventArchive()}catch(e){console.warn(e)}}
async function createSelectedDayStack(mode){if(!eventArchiveState.day)return toast('Select a day first.');return createEventStack(eventArchiveState.day,mode)}
async function deleteSelectedDay(){const info=selectedDayInfo();if(!info)return;return deleteEventDay(info.date,info.count)}

async function deleteEventDay(day,count,event){event?.stopPropagation();if(!confirm(`Delete all non-favorite events from ${friendlyEventDay(day)}?\n\n${count} events are in this folder. Favorites will be kept.\n\nThis action cannot be undone.`))return;const d=await api(`/api/event-days/${encodeURIComponent(day)}`,{method:'DELETE'});toast(`${d.events_removed} events deleted; ${d.protected?.length||0} favorites kept.`);reloadEventArchive()}
async function startEventStackJob(day,mode){
  const started=await api(`/api/event-stacks/${encodeURIComponent(day)}?mode=${encodeURIComponent(mode)}`,{method:'POST'}),jobId=started.job.id;
  const modal=$('#stackProgressModal');modal.classList.add('active');$('#stackProgressTitle').textContent=`${friendlyEventDay(day)} · ${mode==='overlay'?'Overlay':'Clean'} Stack`;
  while(true){
    const data=await api(`/api/event-stacks/jobs/${jobId}`),job=data.job;
    $('#stackProgressStage').textContent=job.stage||job.status;$('#stackProgressFill').style.width=`${job.percent||0}%`;$('#stackProgressPercent').textContent=`${job.percent||0}%`;$('#stackProgressCount').textContent=`${job.processed||0} / ${job.total||0} meteors`;
    if(job.status==='complete'){
      const r=await fetch(`/api/event-stacks/jobs/${jobId}/file`);if(!r.ok)throw new Error('Stack download failed');const blob=await r.blob(),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`event_stack_${day}${mode==='overlay'?'_overlay':'_clean'}.jpg`;a.click();URL.revokeObjectURL(url);setTimeout(()=>modal.classList.remove('active'),900);return;
    }
    if(job.status==='failed'){modal.classList.remove('active');throw new Error(job.error||'Event Stack failed')}
    await new Promise(resolve=>setTimeout(resolve,700));
  }
}
async function createEventStack(day,mode='clean',event){event?.stopPropagation();try{if(mode==='both'){await startEventStackJob(day,'clean');await startEventStackJob(day,'overlay')}else await startEventStackJob(day,mode);toast(mode==='both'?'Both Meteor Stacks created.':'Meteor Stack created.')}catch(e){$('#stackProgressModal')?.classList.remove('active');toast(e.message)}}

async function downloadOverlay(id,button){
  const original=button.textContent;button.disabled=true;button.textContent='Rendering…';toast('Rendering overlay video…');
  try{
    const response=await fetch(`/api/events/${encodeURIComponent(id)}/overlay.mp4`);
    if(!response.ok){let message='Overlay export failed';try{const data=await response.json();message=data.error||message}catch{}throw new Error(message)}
    const blob=await response.blob();const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;
    const disposition=response.headers.get('content-disposition')||'';const match=disposition.match(/filename\*?=(?:UTF-8''|\")?([^\";]+)/i);link.download=match?decodeURIComponent(match[1].replace(/\"/g,'')):`${id}_overlay.mp4`;
    document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);toast('Overlay video ready.');
  }catch(error){toast(error.message)}finally{button.disabled=false;button.textContent=original}
}

async function refresh(){try{render(await api('/api/status'))}catch(e){console.error(e);$('#observationLabel').textContent='System unavailable'}}
setTimeout(scanCameras,800); setTimeout(loadDeveloperUpdateMode,900);
function updateClock(){const now=new Date();$('#currentDate').textContent=now.toLocaleDateString();$('#currentTime').textContent=now.toLocaleTimeString()}updateClock();setInterval(updateClock,1000); setInterval(refresh,2500); refresh();

async function saveTelegram(){
  await save('telegram',{
    enabled:$('#telegramEnabled').checked,
    bot_token:$('#telegramToken').value.trim(),
    chat_id:$('#telegramChatId').value.trim(),
    observer_name:$('#telegramObserverName').value.trim(),
    station_name:$('#telegramStationName').value.trim(),
    station_location:$('#telegramStationLocation').value.trim(),
    cooldown_seconds:5,
    event_notifications:{
      meteor:$('#tgMeteor').checked,
      aircraft:$('#tgAircraft').checked,
      unknown:$('#tgUnknown').checked,
      all_events:$('#tgAllEvents').checked,
      delivery:$('#telegramEventDelivery').value
    },
    critical_notifications:{
      camera_offline:$('#tgCamera').checked,
      lens_cover_fault:$('#tgCover').checked,
      temperature_high:$('#tgTemperature').checked,
      humidity_high:$('#tgHumidity').checked,
      storage_warning:$('#tgStorage').checked,
      system_warning:$('#tgSystem').checked,
      vigilis_restarted:$('#tgRestart').checked,
      delivery:$('#telegramCriticalDelivery').value,
      temperature_limit_c:+($('#tgTemperatureLimit').value||45),
      humidity_limit_percent:+($('#tgHumidityLimit').value||90),
      storage_limit_percent:+($('#tgStorageLimit').value||90)
    },
    daily_summary:{
      enabled:$('#tgDailyEnabled').checked,
      time:$('#tgDailyTime').value||'08:00',
      include_event_statistics:$('#tgDailyEvents').checked,
      include_temperature_chart:$('#tgDailyTemperature').checked,
      include_humidity_chart:$('#tgDailyHumidity').checked
    }
  })
}
async function testTelegram(){try{const r=await fetch('/api/telegram/test',{method:'POST'});let j={};try{j=await r.json()}catch{throw new Error(`Telegram test failed (HTTP ${r.status})`)}if(!r.ok||!j.ok)throw new Error(j.error||`Telegram test failed (HTTP ${r.status})`);toast('Telegram preview sent')}catch(error){toast(error.message||'Telegram test failed')}}
function populateTelegram(c){
  const t=c.telegram||{},e=t.event_notifications||{},w=t.critical_notifications||{},d=t.daily_summary||{};
  $('#telegramEnabled').checked=!!t.enabled;
  $('#telegramToken').value=t.bot_token||'';
  $('#telegramChatId').value=t.chat_id||'';
  $('#telegramObserverName').value=t.observer_name||'';
  $('#telegramStationName').value=t.station_name||c.location?.name||'';
  $('#telegramStationLocation').value=t.station_location||'';
  $('#tgMeteor').checked=e.meteor!==false;
  $('#tgAircraft').checked=!!e.aircraft;
  $('#tgUnknown').checked=!!e.unknown;
  $('#tgAllEvents').checked=!!e.all_events;
  $('#telegramEventDelivery').value=e.delivery||'immediate';
  $('#tgCamera').checked=w.camera_offline!==false;
  $('#tgCover').checked=w.lens_cover_fault!==false;
  $('#tgTemperature').checked=w.temperature_high!==false;
  $('#tgHumidity').checked=w.humidity_high!==false;
  $('#tgStorage').checked=w.storage_warning!==false;
  $('#tgSystem').checked=w.system_warning!==false;
  $('#tgRestart').checked=w.vigilis_restarted!==false;
  $('#telegramCriticalDelivery').value=w.delivery||'immediate';
  $('#tgTemperatureLimit').value=w.temperature_limit_c??45;
  $('#tgHumidityLimit').value=w.humidity_limit_percent??90;
  $('#tgStorageLimit').value=w.storage_limit_percent??90;
  $('#tgDailyEnabled').checked=!!d.enabled;
  $('#tgDailyTime').value=d.time||'08:00';
  $('#tgDailyEvents').checked=d.include_event_statistics!==false;
  $('#tgDailyTemperature').checked=!!d.include_temperature_chart;
  $('#tgDailyHumidity').checked=!!d.include_humidity_chart;
  const badge=$('#telegramStatusBadge');if(badge){badge.textContent=t.enabled&&t.bot_token&&t.chat_id?'Configured':'Not configured';badge.classList.toggle('ok',!!(t.enabled&&t.bot_token&&t.chat_id));}
}

async function loadDeveloperUpdateMode(){
  try{const d=await api('/api/update/developer-mode');const el=$('#allowUnsignedUpdates');if(el)el.checked=!!d.enabled;}catch(e){console.warn('Developer update mode status unavailable',e)}
}
async function setDeveloperUpdateMode(enabled){
  if(enabled&&!confirm('Enable unsigned developer updates? Only install packages from a trusted source.')){const el=$('#allowUnsignedUpdates');if(el)el.checked=false;return}
  try{const d=await api('/api/update/developer-mode',{method:'POST',body:JSON.stringify({enabled})});toast(d.enabled?'Unsigned developer updates enabled.':'Developer update mode disabled.')}catch(e){const el=$('#allowUnsignedUpdates');if(el)el.checked=!enabled;toast(e.message)}
}

let climateRange='1d',climateStart='',climateEnd='';
function climateQuery(metric=''){
  const q=new URLSearchParams();if(metric)q.set('metric',metric);q.set('range',climateRange);
  if(climateRange==='custom'){q.set('start',climateStart);q.set('end',climateEnd)}return q.toString()
}
function climateTickLabel(date,totalMs){if(totalMs<=36*3600000)return date.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});if(totalMs<=100*86400000)return date.toLocaleDateString([],{day:'2-digit',month:'short'});return date.toLocaleDateString([],{month:'short',year:'numeric'})}
function drawClimateChart(canvasId,samples,field,unit,emptyText){
  const canvas=$(canvasId);if(!canvas)return;const ctx=canvas.getContext('2d'),dpr=window.devicePixelRatio||1,w=canvas.clientWidth||1200,h=440;canvas.width=w*dpr;canvas.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);
  const pad={l:56,r:20,t:25,b:48},series=[{key:'dome',label:'Dome',color:'#4da3ff'},{key:'outdoor',label:'Outdoor',color:'#57d58b'}];
  const points=series.map(x=>({s:x,values:samples.map(i=>({t:new Date(i.iso||i.timestamp*1000),v:i[x.key]?.[field]})).filter(p=>p.v!=null&&!Number.isNaN(p.t.getTime()))}));const all=points.flatMap(x=>x.values.map(p=>p.v));
  if(!all.length){ctx.fillStyle='#8da0ad';ctx.font='14px system-ui';ctx.fillText(emptyText,pad.l,70);return}
  let min,max;if(field==='humidity'){min=Math.max(0,Math.floor(Math.min(...all)-5));max=Math.min(100,Math.ceil(Math.max(...all)+5));}else{min=Math.floor(Math.min(...all)-2);max=Math.ceil(Math.max(...all)+2)}if(max<=min)max=min+1;
  const timestamps=points.flatMap(x=>x.values.map(p=>p.t.getTime())),t0=Math.min(...timestamps),t1=Math.max(...timestamps),timeSpan=Math.max(1,t1-t0),plotW=w-pad.l-pad.r,plotH=h-pad.t-pad.b;ctx.strokeStyle='rgba(180,200,215,.15)';ctx.fillStyle='#8da0ad';ctx.font='12px system-ui';
  for(let i=0;i<=5;i++){const y=pad.t+i*plotH/5;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.fillText((max-i*(max-min)/5).toFixed(1)+unit,5,y+4)}
  for(let i=0;i<=6;i++){const frac=i/6,x=pad.l+frac*plotW,date=new Date(t0+frac*timeSpan);ctx.beginPath();ctx.moveTo(x,pad.t);ctx.lineTo(x,h-pad.b);ctx.stroke();ctx.fillText(climateTickLabel(date,timeSpan),Math.min(w-pad.r-70,Math.max(pad.l,x-28)),h-16)}
  points.forEach(({s,values})=>{if(!values.length)return;ctx.strokeStyle=s.color;ctx.lineWidth=2.5;ctx.beginPath();values.forEach((p,i)=>{const x=pad.l+(p.t.getTime()-t0)/timeSpan*plotW,y=pad.t+(max-p.v)/(max-min)*plotH;i?ctx.lineTo(x,y):ctx.moveTo(x,y)});ctx.stroke()});
  let lx=pad.l;series.forEach(x=>{ctx.fillStyle=x.color;ctx.fillRect(lx,pad.t-17,25,3);ctx.fillStyle='#c9d5dc';ctx.fillText(x.label,lx+32,pad.t-11);lx+=110});
}
function drawTemperatureChart(samples){drawClimateChart('#temperatureChart',samples,'temperature_c','°','No valid temperature samples for this range.')}
function drawHumidityChart(samples){drawClimateChart('#humidityChart',samples,'humidity','%','No valid humidity samples for this range.')}
function formatClimateStats(obj,unit){if(!obj||obj.avg==null)return'Min — · Avg — · Max —';return`Min ${obj.min.toFixed(1)}${unit} · Avg ${obj.avg.toFixed(1)}${unit} · Max ${obj.max.toFixed(1)}${unit}`}
function setClimateStats(data){const st=data.stats||{},d=st.dome||{},o=st.outdoor||{};$('#tempDomeStats').textContent=formatClimateStats(d.temperature_c,' °C');$('#tempOutdoorStats').textContent=formatClimateStats(o.temperature_c,' °C');$('#humidityDomeStats').textContent=formatClimateStats(d.humidity,' %');$('#humidityOutdoorStats').textContent=formatClimateStats(o.humidity,' %');$('#tempDifferenceStats').textContent=(d.temperature_c?.avg!=null&&o.temperature_c?.avg!=null)?`${(d.temperature_c.avg-o.temperature_c.avg).toFixed(1)} °C`:'—';$('#humidityDifferenceStats').textContent=(d.humidity?.avg!=null&&o.humidity?.avg!=null)?`${(d.humidity.avg-o.humidity.avg).toFixed(1)} %`:'—'}
async function loadEnvironmentHistory(){try{const data=await api(`/api/environment/history?${climateQuery()}`),samples=data.samples||[];drawTemperatureChart(samples);drawHumidityChart(samples);setClimateStats(data);const period=data.start===data.end?data.start:`${data.start} – ${data.end}`,aggregation=data.display_count<data.sample_count?` · ${data.display_count} displayed`:'';$('#climateChartHint').textContent=`${data.sample_count} climate samples${aggregation} · ${period}`;}catch(e){toast(e.message)}}
function selectClimateRange(range){climateRange=range;document.querySelectorAll('[data-climate-range] button').forEach(b=>b.classList.toggle('active',b.dataset.range===range));const custom=$('#climateCustomRange');custom.hidden=range!=='custom';if(range!=='custom')loadEnvironmentHistory()}
function loadCustomEnvironmentHistory(){climateStart=$('#climateStart').value;climateEnd=$('#climateEnd').value;if(!climateStart||!climateEnd)return;if(climateStart>climateEnd){toast('The From date must be before the To date.');return}loadEnvironmentHistory()}
function loadTemperatureHistory(){return loadEnvironmentHistory()}
function downloadTemperatureChart(){window.open(`/api/environment/chart.png?${climateQuery('temperature')}`,'_blank')}
function downloadHumidityChart(){window.open(`/api/environment/chart.png?${climateQuery('humidity')}`,'_blank')}
document.addEventListener('click',e=>{const b=e.target.closest('[data-climate-range] button');if(b)selectClimateRange(b.dataset.range)});
document.addEventListener('change',e=>{if(e.target.matches('#climateStart,#climateEnd'))loadCustomEnvironmentHistory()});
function setUsageBar(id,value){const el=$(id);if(el)el.style.width=`${Math.max(0,Math.min(100,Number(value)||0))}%`}
function renderDiagnosticMetrics(s){const sys=s.system||{},st=s.storage||{};const storagePct=(st.total_gb>0)?st.used_gb/st.total_gb*100:0;const set=(id,v)=>{const el=$(id);if(el)el.textContent=v};set('#diagCpuLoad',fmt(sys.cpu_percent,' %'));set('#diagCpuTemp',`CPU temperature ${fmt(sys.cpu_temp_c,' °C')}`);setUsageBar('#diagCpuBar',sys.cpu_percent);set('#diagRamLoad',fmt(sys.ram_percent,' %'));set('#diagRamDetail',`${fmt(sys.ram_used_mb,' MB')} / ${fmt(sys.ram_total_mb,' MB')}`);setUsageBar('#diagRamBar',sys.ram_percent);set('#diagSdLoad',fmt(sys.disk_percent,' %'));set('#diagSdDetail',`${fmt(sys.disk_used_gb,' GB')} / ${fmt(sys.disk_total_gb,' GB')}`);setUsageBar('#diagSdBar',sys.disk_percent);set('#diagStorageLoad',st.total_gb?`${storagePct.toFixed(1)} %`:'—');set('#diagStorageDetail',st.total_gb?`${st.used_gb} GB / ${st.total_gb} GB`:(st.error||'Unavailable'));setUsageBar('#diagStorageBar',storagePct)}

document.addEventListener('DOMContentLoaded',()=>{const today=new Date().toISOString().slice(0,10),start=new Date(Date.now()-6*86400000).toISOString().slice(0,10);if($('#climateEnd'))$('#climateEnd').value=today;if($('#climateStart'))$('#climateStart').value=start;climateStart=start;climateEnd=today;loadEnvironmentHistory()});
