from __future__ import annotations
from pathlib import Path
import json, os, subprocess, threading, time, uuid
import datetime as dt
from flask import Flask, Response, jsonify, render_template, request, send_file, send_from_directory

from . import __version__
from .core.config import load_config, save_config
from .core.logging_setup import setup_logging
from .modules.camera import CameraManager
from .modules.zwo_camera import ZwoCameraBackend
from .modules.cover import CoverController
from .modules.detector import Detector
from .modules.event_index import EventIndex
from .modules.heater import HeaterController
from .modules.observation import ObservationManager
from .modules.sensor import SensorReader
from .modules.storage import StorageManager
from .modules.system_info import get_system_info
from .modules.telegram import TelegramNotifier

ROOT=Path(__file__).resolve().parents[1]
app=Flask(__name__,template_folder='templates',static_folder='static')
app.config['MAX_CONTENT_LENGTH']=300*1024*1024
config=load_config(); logger=setup_logging(ROOT)
camera=CameraManager(config,logger); camera.start()
cover=CoverController(config,logger)
sensor=SensorReader(config,logger); sensor.start()
heater=HeaterController(config,logger)
observation=ObservationManager(config)
event_index=EventIndex(ROOT,config,logger)
storage=StorageManager(ROOT,config,event_index=event_index)
detector=Detector(config,camera,observation,ROOT,logger,event_index=event_index)
detector.set_start_gate(False,'initializing observation')
detector.start()
telegram=TelegramNotifier(config,ROOT,logger)

# Existing archives are imported once in the background.  The web UI and
# detector are available immediately; no recursive SSD scan blocks startup.
def _start_initial_event_index():
    try:
        target=storage.recordings_root
        if target != storage.configured_recordings_root:
            logger.warning('Preferred storage unavailable; indexing internal fallback: %s',target)
        event_index.start_rebuild(target,force=False)
    except Exception:
        logger.exception('Initial event index start failed')
threading.Thread(target=_start_initial_event_index,daemon=True,name='event-index-start').start()

def _telegram_worker():
    known=set()
    hourly_counts={'meteor':0,'aircraft':0,'unknown':0}
    last_hour=None
    last_daily_key=None
    alert_states={}
    time.sleep(5)

    def selected(classification, tg):
        choices=tg.get('event_notifications',{})
        if choices.get('all_events'):
            return classification in {'meteor','aircraft','unknown'}
        return bool(choices.get(classification,False))

    def warn_once(key, active, title, details, enabled=True):
        previous=bool(alert_states.get(key,False))
        alert_states[key]=bool(active)
        if active and not previous and enabled:
            telegram.send_warning(key,title,details)

    while True:
        try:
            tg=config.get('telegram',{})
            event_cfg=tg.get('event_notifications',{})
            event_mode=event_cfg.get('delivery','immediate')
            current=storage.events(100)
            new=[e for e in reversed(current) if e.get('id') not in known]
            for e in current:
                known.add(e.get('id'))
            if len(known)>1000:
                known=set(e.get('id') for e in current)

            if tg.get('enabled'):
                for event in new:
                    classification=str(event.get('classification') or 'unknown').lower()
                    if classification in hourly_counts and selected(classification,tg):
                        hourly_counts[classification]+=1
                        if event_mode=='immediate':
                            telegram.send_event(event)

                now=dt.datetime.now()
                hour_key=(now.year,now.timetuple().tm_yday,now.hour)
                if last_hour is not None and hour_key!=last_hour and event_mode=='hourly':
                    if any(hourly_counts.values()):
                        end_hour=now.replace(minute=0,second=0,microsecond=0)
                        telegram.send_hourly_summary(hourly_counts,end_hour-dt.timedelta(hours=1),end_hour)
                    hourly_counts={'meteor':0,'aircraft':0,'unknown':0}
                last_hour=hour_key

                daily=tg.get('daily_summary',{})
                if daily.get('enabled'):
                    try:
                        target_h,target_m=[int(v) for v in str(daily.get('time','08:00')).split(':',1)]
                    except Exception:
                        target_h,target_m=8,0
                    daily_key=(now.date(),target_h,target_m)
                    if now.hour==target_h and now.minute>=target_m and daily_key!=last_daily_key:
                        day=now.date()-dt.timedelta(days=1)
                        day_text=day.isoformat()
                        counts={name:event_index.count(day=day_text,classification=name) for name in ('meteor','aircraft','unknown')}
                        dome=(sensor.latest or {}).get('dome') or {}
                        temperature=dome.get('temperature_c')
                        humidity=dome.get('humidity')
                        storage_text=f"{storage.free_gb():.1f} GB free" if hasattr(storage,'free_gb') else None
                        telegram.send_daily_summary(counts,day,{'temperature':f'{temperature:.1f} °C' if isinstance(temperature,(int,float)) else None,'humidity':f'{humidity:.0f} %' if isinstance(humidity,(int,float)) else None,'storage':storage_text})
                        last_daily_key=daily_key

                critical=tg.get('critical_notifications',{})
                critical_enabled=critical.get('delivery','immediate')=='immediate'
                cam_online=bool(camera.status.get('connected',camera.status.get('running',True)))
                warn_once('camera_offline',not cam_online,'Camera offline',[('Camera',camera.status.get('camera_name') or camera.status.get('backend','Unknown'))],critical_enabled and critical.get('camera_offline',True))
                cover_state=cover.status()
                warn_once('lens_cover_fault',cover_state.get('state')=='fault','Lens Cover Fault',[('State',cover_state.get('state','fault')),('Message',cover_state.get('error') or 'The cover did not reach its target position.')],critical_enabled and critical.get('lens_cover_fault',True))
                dome=(sensor.latest or {}).get('dome') or {}
                temp=dome.get('temperature_c'); humidity=dome.get('humidity')
                temp_limit=float(critical.get('temperature_limit_c',45) or 45)
                humidity_limit=float(critical.get('humidity_limit_percent',90) or 90)
                warn_once('temperature_high',isinstance(temp,(int,float)) and temp>=temp_limit,'Temperature Warning',[('Current temperature',f'{temp:.1f} °C'),('Configured limit',f'{temp_limit:.1f} °C')],critical_enabled and critical.get('temperature_high',True))
                warn_once('humidity_high',isinstance(humidity,(int,float)) and humidity>=humidity_limit,'Humidity Warning',[('Current humidity',f'{humidity:.0f} %'),('Configured limit',f'{humidity_limit:.0f} %')],critical_enabled and critical.get('humidity_high',True))
        except Exception:
            logger.exception('Telegram notification worker failed')
        time.sleep(10)

threading.Thread(target=_telegram_worker,daemon=True,name='telegram-worker').start()

def _cleanup_worker():
    last_day=None
    while True:
        try:
            s=config.get('storage',{})
            local=time.localtime(); key=(local.tm_year,local.tm_yday)
            if s.get('automatic_cleanup') and local.tm_hour==int(s.get('cleanup_hour',12)) and key!=last_day:
                result=storage.cleanup(int(s.get('retention_days',7)))
                logger.info('Automatic event cleanup: %s',result)
                last_day=key
        except Exception: logger.exception('Automatic cleanup failed')
        time.sleep(300)

threading.Thread(target=_cleanup_worker,daemon=True,name='storage-cleanup').start()

cover_automation_state={
    'installed':bool(config.get('cover',{}).get('installed',True)),
    'phase':'initializing',
    'next_action':'',
    'open_altitude':None,
    'detection_altitude':None,
}

def _cover_automation_worker():
    window_active=False
    cover_open_since=None
    last_sun=None
    time.sleep(3)
    while True:
        try:
            dcfg=config.get('detection',{})
            ccfg=config.get('cover',{})
            schedule=str(dcfg.get('schedule_mode','always')).lower().replace('-','_')
            enabled=bool(dcfg.get('enabled',True)) and schedule!='disabled'
            installed=bool(ccfg.get('installed',True)) and bool(config.get('gpio',{}).get('enabled',True))
            automatic=str(ccfg.get('mode','automatic')).lower()=='automatic'
            start=float(dcfg.get('start_sun_altitude',-6))
            stop=float(dcfg.get('stop_sun_altitude',-4))
            lead=max(0.0,float(ccfg.get('open_before_detection_deg',0.5)))
            stabilize=max(0.0,float(ccfg.get('stabilization_seconds',5)))
            sun=observation.sun_altitude()
            previous_sun=last_sun
            if sun is not None:
                last_sun=sun

            if not enabled:
                window_active=False
            elif schedule=='always':
                window_active=True
            elif schedule=='custom':
                window_active=observation.time_window_active(dcfg.get('custom_start','20:00'),dcfg.get('custom_stop','06:00'))
            elif schedule in {'sun','sun_altitude'} and sun is not None:
                if window_active:
                    if sun>=stop:
                        window_active=False
                elif sun<=start:
                    window_active=True
            else:
                window_active=False

            cover_automation_state.update(
                installed=installed,
                open_altitude=(start+lead if schedule in {'sun','sun_altitude'} else None),
                detection_altitude=(start if schedule in {'sun','sun_altitude'} else None),
            )

            if not installed:
                # Keeping the gate closed outside the observation window creates
                # a clean false->true transition.  That transition clears the
                # ring buffer and detector history before fresh night frames are used.
                detector.set_start_gate(window_active,'preparing detector')
                cover_automation_state['phase']='detecting' if window_active else 'waiting'
                cover_automation_state['next_action']=(
                    f'Detection starts at {start:.1f}°' if schedule in {'sun','sun_altitude'} and not window_active else ''
                )
                cover_open_since=None
                time.sleep(1)
                continue

            cover_state=cover.status()
            current=str(cover_state.get('state','unknown'))

            if not automatic:
                ready=window_active and current=='open'
                detector.set_start_gate(ready,'waiting for lens cover')
                cover_automation_state['phase']='manual cover' if not ready else 'detecting'
                cover_automation_state['next_action']='Open lens cover manually' if window_active and not ready else ''
                time.sleep(1)
                continue

            preopen=False
            if schedule in {'sun','sun_altitude'} and sun is not None:
                descending = previous_sun is None or sun <= previous_sun
                preopen=(not window_active and descending and sun<=start+lead)
            elif schedule in {'always','custom'}:
                preopen=window_active
            should_be_open=window_active or preopen

            if should_be_open:
                if current=='open':
                    if cover_open_since is None:
                        cover_open_since=time.monotonic()
                        detector.request_reset()
                    stable=(time.monotonic()-cover_open_since)>=stabilize
                    ready=window_active and stable
                    detector.set_start_gate(ready,'preparing detector' if window_active else 'waiting for detection altitude')
                    if ready:
                        cover_automation_state['phase']='detecting'
                        cover_automation_state['next_action']=''
                    elif window_active:
                        remaining=max(0,int(round(stabilize-(time.monotonic()-cover_open_since))))
                        cover_automation_state['phase']='preparing detector'
                        cover_automation_state['next_action']=f'Detection starts after stabilization ({remaining}s)'
                    else:
                        cover_automation_state['phase']='cover open'
                        cover_automation_state['next_action']=f'Detection starts at {start:.1f}°'
                else:
                    cover_open_since=None
                    detector.set_start_gate(False,'opening lens cover')
                    cover_automation_state['phase']='opening lens cover'
                    cover_automation_state['next_action']=f'Detection starts at {start:.1f}°' if schedule in {'sun','sun_altitude'} else 'Waiting for OPEN sensor'
                    if not cover_state.get('moving') and current not in {'opening','fault'}:
                        result=cover.move_to('open')
                        logger.info('Automatic lens cover open: %s',result)
            else:
                cover_open_since=None
                detector.set_start_gate(False,'waiting for observation')
                cover_automation_state['phase']='waiting'
                cover_automation_state['next_action']=(f'Lens cover opens at {start+lead:.1f}°' if schedule in {'sun','sun_altitude'} else '')
                # Detection is gated off before closing, so the cover movement
                # cannot be captured as an event.
                if current not in {'closed','closing'} and not cover_state.get('moving'):
                    result=cover.move_to('closed')
                    logger.info('Automatic lens cover close: %s',result)
        except Exception:
            logger.exception('Automatic lens cover worker failed')
        time.sleep(1)

threading.Thread(target=_cover_automation_worker,daemon=True,name='cover-automation').start()
if config.get('telegram',{}).get('enabled') and config.get('telegram',{}).get('critical_notifications',{}).get('vigilis_restarted',True):
    threading.Thread(target=lambda: (time.sleep(8),telegram.restart_message()),daemon=True).start()


def _background_path():
    raw=str(config.get('ui',{}).get('background_image','/static/background.jpg'))
    if raw.startswith('/static/'):
        return ROOT/'vigilis'/'static'/raw.removeprefix('/static/')
    p=ROOT/raw.lstrip('/')
    return p


def _background_url():
    p=_background_path()
    if p.exists() and 'data/backgrounds' in p.as_posix():
        return f"/ui-background/{p.name}?v={int(p.stat().st_mtime)}"
    raw=str(config.get('ui',{}).get('background_image','/static/background.jpg'))
    if raw.startswith('/static/'):
        stamp=int(p.stat().st_mtime) if p.exists() else 0
        return f'{raw}?v={stamp}'
    return '/static/background.jpg'


def snapshot():
    try: heater.auto(sensor.latest)
    except Exception: pass
    cfg=dict(config); cfg['ui']=dict(config.get('ui',{})); cfg['ui']['background_url']=_background_url()
    observation_state=observation.status()
    observation_state['active']=bool(detector.status.get('running'))
    observation_state['label']=str(detector.status.get('mode','waiting')).replace('_',' ').title()
    # All event values below are SQLite queries on the internal SD card.  The
    # dashboard never scans the recording SSD.
    try:
        recent_events=storage.events(8)
        event_summary=storage.event_summary()
    except Exception:
        logger.exception('Event index query failed')
        recent_events=[]
        event_summary={'total':0,'meteor':0,'aircraft':0,'unknown':0,'ssd':0,'sd':0}
    try: storage_state=storage.storage_status()
    except Exception as exc:
        storage_state={'ok':False,'path':str(config.get('storage',{}).get('recordings_path','')),'error':str(exc)}
    detector_state=dict(detector.status)
    detector_state['events_today']=event_summary.get('total',0)
    return {'version':__version__,'observation':observation_state,'camera':camera.status,'detector':detector_state,
            'cover':cover.status(),'cover_automation':dict(cover_automation_state),'sensor':sensor.latest,'heater':heater.status(),
            'system':get_system_info(ROOT),'config':cfg,'events':recent_events,'event_count':event_summary.get('total',0),
            'event_summary':event_summary,'event_index':event_index.status(),'storage':storage_state}


@app.get('/')
def home(): return render_template('index.html',version=__version__,config=config,background_url=_background_url())
@app.get('/api/status')
def status(): return jsonify(snapshot())
@app.get('/api/events')
def events():
    limit=max(1,min(int(request.args.get('limit',100)),500))
    offset=max(0,int(request.args.get('offset',0)))
    day=(request.args.get('date') or '').strip() or None
    favorites=(request.args.get('favorites') or '').lower() in {'1','true','yes'}
    classification=(request.args.get('classification') or '').strip().lower() or None
    items=storage.events(limit=limit,offset=offset,day=day,favorites=favorites,classification=classification)
    total=storage.event_count(day=day,favorites=favorites,classification=classification)
    return jsonify({'events':items,'offset':offset,'limit':limit,'date':day,'classification':classification,'total':total,'has_more':offset+len(items)<total})

@app.get('/api/event-days')
def event_days():
    return jsonify({'days':storage.event_days(),'total':storage.event_count(),'favorites':storage.event_count(favorites=True),'index':event_index.status()})

@app.get('/api/event-index/status')
def event_index_status():
    return jsonify(event_index.status())

@app.post('/api/event-index/rebuild')
def event_index_rebuild():
    return jsonify(event_index.start_rebuild(storage.recordings_root,force=True))

@app.post('/api/classification/reclassify')
def classification_reclassify():
    payload=request.get_json(silent=True) or {}
    return jsonify({'ok':True,**storage.reclassify_existing(bool(payload.get('only_unknown',True)))})

@app.get('/api/classification/summary')
def classification_summary():
    return jsonify({name:storage.event_count(classification=name) for name in ('meteor','aircraft','unknown','satellite','insect','false_positive')})

@app.get('/api/events/<event_id>/overlay.mp4')
def event_overlay_download(event_id):
    try:
        margin=int(config.get('storage',{}).get('overlay_margin_percent',50))
        output=storage.render_overlay_video(event_id,margin)
        return send_file(output,as_attachment=True,download_name=output.name,mimetype='video/mp4',conditional=True)
    except FileNotFoundError as exc:
        return jsonify({'ok':False,'error':str(exc)}),404
    except ValueError as exc:
        return jsonify({'ok':False,'error':str(exc)}),409
    except Exception as exc:
        logger.exception('Overlay rendering failed for %s',event_id)
        return jsonify({'ok':False,'error':str(exc)}),500

@app.get('/api/cameras')
@app.get('/api/camera/scan')
def cameras_discover():
    result={'active':config.get('camera',{}).get('mode','auto'),'csi':{'available':False},'zwo':ZwoCameraBackend.discover()}
    try:
        from picamera2 import Picamera2
        cams=Picamera2.global_camera_info()
        result['csi']={'available':bool(cams),'cameras':cams}
    except Exception as exc:
        result['csi']={'available':False,'error':str(exc)}
    return jsonify(result)

@app.get('/api/camera/zwo/health')
def zwo_health():
    info=ZwoCameraBackend.discover()
    return jsonify({'ok':bool(info.get('cameras')),'zwo':info})

@app.get('/media/<path:name>')
def media(name): return send_from_directory(ROOT,name)
@app.get('/ui-background/<path:name>')
def ui_background(name): return send_from_directory(ROOT/'data'/'backgrounds',name,max_age=0)

@app.get('/video_feed')
def video_feed():
    mode=config['camera'].get('preview','360p'); heights={'360p':360,'720p':720,'1080p':1080}
    if mode=='disabled': return ('',204)
    height=heights.get(mode,360)
    def gen():
        while True:
            jpg=camera.jpeg(height)
            if jpg: yield b'--frame\r\nContent-Type: image/jpeg\r\n\r\n'+jpg+b'\r\n'
            time.sleep(0.05)
    return Response(gen(),mimetype='multipart/x-mixed-replace; boundary=frame')

@app.post('/api/settings')
def settings():
    data=request.get_json(force=True) or {}
    for section,values in data.items():
        if section in config and isinstance(values,dict) and isinstance(config[section],dict): config[section].update(values)
    save_config(config)
    restart_sections={'camera','gpio','cover','storage'}
    restart_required=any(k in data for k in restart_sections)
    return jsonify({'ok':True,'restart_required':restart_required,'restart_type':'service' if restart_required else None})

@app.post('/api/cover/<action>')
def cover_action(action):
    if action=='open': return jsonify(cover.move_to('open'))
    if action=='close': return jsonify(cover.move_to('closed'))
    if action=='stop': return jsonify(cover.stop())
    payload=request.get_json(silent=True) or {}; jog_steps=max(1,min(int(payload.get('steps',10)),5000))
    if action=='jog-open': return jsonify(cover.jog(bool(int(config['cover'].get('direction_open',1))),jog_steps))
    if action=='jog-close': return jsonify(cover.jog(not bool(int(config['cover'].get('direction_open',1))),jog_steps))
    return jsonify({'ok':False,'error':'unknown action'}),400

@app.post('/api/heater/<mode>')
def heater_action(mode):
    if mode not in {'on','off','auto'}: return jsonify({'ok':False}),400
    config['heater']['mode']=mode; save_config(config)
    return jsonify({'ok':True,'mode':mode,**(heater.set(mode=='on') if mode!='auto' else {})})

@app.post('/api/events/<event_id>')
def event_update(event_id):
    data=request.get_json(force=True) or {}; allowed={k:v for k,v in data.items() if k in {'classification','favorite'}}
    result=storage.update(event_id,**allowed); return jsonify({'ok':bool(result),'event':result})
@app.delete('/api/events/<event_id>')
def event_delete(event_id):
    try:return jsonify({'ok':True,'removed':storage.delete(event_id)})
    except PermissionError as exc:return jsonify({'ok':False,'error':str(exc)}),409

@app.get('/api/events/<event_id>/file/<kind>')
def event_file_download(event_id,kind):
    path=storage.event_file(event_id,kind)
    if not path or not path.exists(): return jsonify({'ok':False,'error':'File not found'}),404
    return send_file(path,conditional=True)

@app.post('/api/events/delete-many')
def event_delete_many():
    ids=(request.get_json(force=True) or {}).get('ids',[])
    return jsonify({'ok':True,**storage.delete_many(ids)})

@app.delete('/api/event-days/<day>')
def event_day_delete(day):
    return jsonify({'ok':True,**storage.delete_day(day)})

@app.get('/api/storage/locations')
def storage_locations():
    return jsonify({'locations':storage.available_storage_locations(),'devices':storage.storage_devices(),'current':storage.storage_status()})

@app.post('/api/storage/prepare')
def storage_prepare():
    payload=request.get_json(silent=True) or {}
    action=str(payload.get('action',''))
    device=str(payload.get('device',''))
    if action=='initialize' and payload.get('confirmation')!='ERASE':
        return jsonify({'error':'Type ERASE to confirm drive initialization.'}),400
    try:
        result=storage.prepare_storage(device,action)
        return jsonify({'ok':True,**result,'locations':storage.available_storage_locations(),'devices':storage.storage_devices()})
    except Exception as exc:
        return jsonify({'error':str(exc)}),400

@app.post('/api/storage/activate')
def storage_activate():
    payload=request.get_json(silent=True) or {}
    previous=str(config.get('storage',{}).get('recordings_path','') or '')
    try:
        result=storage.activate_storage_path(payload.get('path',''))
        config.setdefault('storage',{})['automatic_cleanup']=bool(payload.get('automatic_cleanup',config.get('storage',{}).get('automatic_cleanup',True)))
        config['storage']['retention_days']=max(1,int(payload.get('retention_days',config['storage'].get('retention_days',7))))
        config['storage']['overlay_margin_percent']=max(0,min(500,int(payload.get('overlay_margin_percent',config['storage'].get('overlay_margin_percent',50)))))
        save_config(config)
        event_index.start_rebuild(storage.configured_recordings_root,force=True)
        logger.info('Recording storage activated: %s',result['path'])
        return jsonify({'ok':True,**result,'storage':storage.storage_status()})
    except Exception as exc:
        config.setdefault('storage',{})['recordings_path']=previous
        logger.exception('Storage activation failed')
        return jsonify({'ok':False,'error':str(exc),'rolled_back_to':previous or str(ROOT/'recordings')}),400

@app.post('/api/storage/cleanup')
def storage_cleanup():
    days=int(config.get('storage',{}).get('retention_days',7))
    return jsonify({'ok':True,**storage.cleanup(days)})

@app.post('/api/event-stacks/<day>')
def event_stack(day):
    mode=(request.args.get('mode') or 'clean').lower()
    if mode not in {'clean','overlay'}:
        return jsonify({'ok':False,'error':'mode must be clean or overlay'}),400
    margin=int(config.get('storage',{}).get('overlay_margin_percent',50))
    return jsonify({'ok':True,'job':storage.start_event_stack(day,overlay=(mode=='overlay'),margin_percent=margin)})

@app.get('/api/event-stacks/jobs/<job_id>')
def event_stack_job(job_id):
    job=storage.event_stack_status(job_id)
    if not job: return jsonify({'ok':False,'error':'Stack job not found'}),404
    return jsonify({'ok':True,'job':job})

@app.get('/api/event-stacks/jobs/<job_id>/file')
def event_stack_job_file(job_id):
    output=storage.event_stack_file(job_id)
    if not output: return jsonify({'ok':False,'error':'Stack is not ready'}),409
    return send_file(output,as_attachment=True,download_name=output.name,mimetype='image/jpeg')

def _environment_period():
    today=dt.date.today()
    key=(request.args.get('range') or '').strip().lower()
    if request.args.get('day'):
        day=dt.date.fromisoformat(request.args.get('day').strip())
        return day,day,'1d'
    if key=='custom':
        start=dt.date.fromisoformat((request.args.get('start') or today.isoformat()).strip())
        end=dt.date.fromisoformat((request.args.get('end') or today.isoformat()).strip())
        if end < start: start,end=end,start
        if (end-start).days > 366: start=end-dt.timedelta(days=366)
        return start,end,'custom'
    days={'1d':1,'7d':7,'30d':30,'2m':60,'6m':183,'1y':365}.get(key,1)
    return today-dt.timedelta(days=days-1),today,key or '1d'

@app.get('/api/environment/history')
def environment_history():
    try:
        start,end,key=_environment_period()
    except ValueError:
        return jsonify({'ok':False,'error':'Invalid date'}),400
    samples,stats,raw_count=sensor.history_range(start,end)
    return jsonify({'range':key,'start':start.isoformat(),'end':end.isoformat(),'days':sensor.available_days(),'samples':samples,'sample_count':raw_count,'display_count':len(samples),'stats':stats})

def _environment_chart_png_range(metric='temperature'):
    try:
        start,end,key=_environment_period()
    except ValueError:
        return jsonify({'ok':False,'error':'Invalid date'}),400
    samples,stats,raw_count=sensor.history_range(start,end,max_points=2200)
    if not samples:
        return jsonify({'ok':False,'error':'No climate data for this range'}),404
    import cv2, numpy as np
    metric='humidity' if metric=='humidity' else 'temperature'
    field='humidity' if metric=='humidity' else 'temperature_c'
    unit='%' if metric=='humidity' else 'C'
    title='Humidity' if metric=='humidity' else 'Temperature'
    width,height=1400,700; image=np.full((height,width,3),18,dtype=np.uint8)
    left,right,top,bottom=90,40,70,100
    series=[]
    for sensor_key,color,label in [('dome',(255,150,60),'Dome'),('outdoor',(80,210,120),'Outdoor')]:
        pts=[]
        for item in samples:
            value=(item.get(sensor_key) or {}).get(field)
            if isinstance(value,(int,float)): pts.append((float(item.get('timestamp',0)),float(value)))
        if pts: series.append((pts,color,label))
    if not series: return jsonify({'ok':False,'error':f'No valid {metric} samples'}),404
    values=[v for pts,_,_ in series for _,v in pts]
    if metric=='humidity': vmin=max(0,min(values)-5); vmax=min(100,max(values)+5)
    else: vmin=min(values)-2; vmax=max(values)+2
    if vmax<=vmin: vmax=vmin+1
    plot_w=width-left-right; plot_h=height-top-bottom
    first=min(t for pts,_,_ in series for t,_ in pts); last=max(t for pts,_,_ in series for t,_ in pts)
    if last<=first: last=first+1
    for i in range(6):
        y=top+int(i*plot_h/5); cv2.line(image,(left,y),(width-right,y),(55,60,65),1)
        value=vmax-i*(vmax-vmin)/5; cv2.putText(image,f'{value:.1f} {unit}',(12,y+6),cv2.FONT_HERSHEY_SIMPLEX,.65,(180,185,190),1,cv2.LINE_AA)
    tick_count=6
    total_days=max(1,(end-start).days+1)
    for i in range(tick_count+1):
        frac=i/tick_count; x=left+int(frac*plot_w); cv2.line(image,(x,top),(x,height-bottom),(45,50,55),1)
        moment=dt.datetime.fromtimestamp(first+frac*(last-first))
        label=moment.strftime('%H:%M') if total_days<=1 else (moment.strftime('%d %b') if total_days<=90 else moment.strftime('%b %Y'))
        cv2.putText(image,label,(max(left,x-32),height-48),cv2.FONT_HERSHEY_SIMPLEX,.52,(170,175,180),1,cv2.LINE_AA)
    for pts,color,label in series:
        xy=[]
        for timestamp,value in pts:
            x=left+int((timestamp-first)/(last-first)*plot_w); y=top+int((vmax-value)/(vmax-vmin)*plot_h); xy.append((x,y))
        if len(xy)>1: cv2.polylines(image,[np.array(xy,np.int32)],False,color,3,cv2.LINE_AA)
    period=start.isoformat() if start==end else f'{start.isoformat()} to {end.isoformat()}'
    cv2.putText(image,f'VIGILIS {title} History - {period}',(left,38),cv2.FONT_HERSHEY_SIMPLEX,.85,(230,235,238),2,cv2.LINE_AA)
    cv2.putText(image,f'{raw_count} climate samples',(left,height-18),cv2.FONT_HERSHEY_SIMPLEX,.55,(145,155,165),1,cv2.LINE_AA)
    xleg=width-360
    for i,(_,color,label) in enumerate(series):
        y=32+i*28; cv2.line(image,(xleg,y),(xleg+45,y),color,4); cv2.putText(image,label,(xleg+55,y+6),cv2.FONT_HERSHEY_SIMPLEX,.6,(220,225,230),1,cv2.LINE_AA)
    ok,buf=cv2.imencode('.png',image)
    filename=f'{metric}_{key}_{end.isoformat()}.png'
    return Response(buf.tobytes(),mimetype='image/png',headers={'Content-Disposition':f'inline; filename={filename}'})

@app.get('/api/environment/chart.png')
def environment_chart_png(): return _environment_chart_png_range(request.args.get('metric','temperature'))

# Backward-compatible one-day PNG endpoints.
@app.get('/api/environment/history/<day>.png')
def environment_history_png(day):
    with app.test_request_context(f'/api/environment/chart.png?metric=temperature&day={day}'):
        return _environment_chart_png_range('temperature')

@app.get('/api/environment/humidity/<day>.png')
def environment_humidity_png(day):
    with app.test_request_context(f'/api/environment/chart.png?metric=humidity&day={day}'):
        return _environment_chart_png_range('humidity')

@app.post('/api/detection/mask')
def detection_mask_upload():
    f = request.files.get('mask')
    if not f:
        return jsonify({'ok':False,'error':'no mask file'}), 400
    ext = (f.filename.rsplit('.',1)[-1] if '.' in f.filename else '').lower()
    if ext not in {'png','jpg','jpeg'}:
        return jsonify({'ok':False,'error':'Use a PNG or JPEG mask.'}), 400
    folder = ROOT / 'data'
    folder.mkdir(parents=True, exist_ok=True)
    temp = folder / 'detection_mask_upload'
    f.save(temp)
    import cv2
    image = cv2.imread(str(temp), cv2.IMREAD_GRAYSCALE)
    try: temp.unlink()
    except OSError: pass
    if image is None:
        return jsonify({'ok':False,'error':'The mask image could not be read.'}), 400
    _, image = cv2.threshold(image, 127, 255, cv2.THRESH_BINARY)
    dest = folder / 'detection_mask.png'
    cv2.imwrite(str(dest), image)
    config['detection']['mask_file'] = str(dest.relative_to(ROOT))
    save_config(config)
    detector._load_mask()
    return jsonify({'ok':True,'mask':str(dest.relative_to(ROOT))})

@app.delete('/api/detection/mask')
def detection_mask_delete():
    p = ROOT / config.get('detection', {}).get('mask_file', 'data/detection_mask.png')
    try:
        if p.exists(): p.unlink()
    except OSError:
        pass
    detector.mask = None
    return jsonify({'ok':True})

@app.post('/api/ui/background')
def background():
    f=request.files.get('background')
    if not f: return jsonify({'ok':False,'error':'no file'}),400
    ext=(f.filename.rsplit('.',1)[-1] if '.' in f.filename else 'jpg').lower()
    if ext not in {'jpg','jpeg','png','webp'}: return jsonify({'ok':False,'error':'unsupported'}),400
    folder=ROOT/'data'/'backgrounds'; folder.mkdir(parents=True,exist_ok=True)
    for old in folder.glob('background.*'):
        try: old.unlink()
        except OSError: pass
    dest=folder/f'background.{ext}'; f.save(dest)
    config['ui']['background_image']=str(dest.relative_to(ROOT)); save_config(config)
    return jsonify({'ok':True,'url':_background_url()})

@app.get('/api/logs/<kind>')
def logs(kind):
    p=ROOT/'logs'/('developer.log' if kind=='developer' else 'user.log')
    return jsonify({'lines':p.read_text(errors='replace').splitlines()[-300:] if p.exists() else []})


def _delayed_system_command(command):
    def run():
        time.sleep(0.8)
        try: subprocess.Popen(command)
        except Exception: logger.exception('System command failed: %s',command)
    threading.Thread(target=run,daemon=True).start()

@app.post('/api/system/<action>')
def system_action(action):
    commands={'restart-service':['sudo','systemctl','restart','vigilis.service'],
              'reboot':['sudo','systemctl','reboot'],
              'shutdown':['sudo','systemctl','poweroff']}
    if action not in commands: return jsonify({'ok':False,'error':'unknown system action'}),400
    logger.warning('Requested system action: %s',action); _delayed_system_command(commands[action])
    return jsonify({'ok':True,'action':action})




@app.post('/api/telegram/test')
def telegram_test():
    try:
        dome=(sensor.latest or {}).get('dome') or {}
        camera_ok=bool(camera.status.get('camera_ok',camera.status.get('running',False)))
        camera_text='Online' if camera_ok else 'Offline'
        storage_text=str(storage.recordings_root)
        sun=observation.status().get('sun_altitude')
        status_data={
            'camera':camera_text,
            'storage':storage_text,
            'temperature':f"{dome.get('temperature_c'):.1f} °C" if isinstance(dome.get('temperature_c'),(int,float)) else '—',
            'humidity':f"{dome.get('humidity'):.0f} %" if isinstance(dome.get('humidity'),(int,float)) else '—',
            'sun_altitude':f"{sun:.1f}°" if isinstance(sun,(int,float)) else '—',
        }
        result=telegram.test(status_data)
        if not result.get('ok'):
            logger.warning('Telegram preview failed: %s',result.get('error') or result)
        return jsonify(result), (200 if result.get('ok') else 502)
    except Exception as exc:
        logger.exception('Telegram preview endpoint failed')
        return jsonify({'ok':False,'error':str(exc)}),500

@app.post('/api/zwo/fix-permissions')
def zwo_fix_permissions():
    try:
        result=subprocess.run(['sudo','/usr/local/sbin/vigilis-zwo-permissions'],capture_output=True,text=True,timeout=30)
        if result.returncode != 0:
            raise RuntimeError((result.stderr or result.stdout or 'Permission helper failed').strip())
        return jsonify({'ok':True,'message':'ZWO USB permissions installed. Reconnect the camera once.'})
    except Exception as exc:
        return jsonify({'ok':False,'error':str(exc)}),400


@app.get('/api/update/developer-mode')
def developer_update_mode_status():
    try:
        result=subprocess.run(['sudo','/usr/local/sbin/vigilis-dev-update-mode','status'],capture_output=True,text=True,timeout=10,check=True)
        return jsonify(json.loads(result.stdout.strip()))
    except Exception as exc:
        return jsonify({'ok':False,'enabled':False,'error':str(exc)}),500

@app.post('/api/update/developer-mode')
def developer_update_mode_set():
    enabled=bool((request.get_json(silent=True) or {}).get('enabled',False))
    try:
        action='enable' if enabled else 'disable'
        result=subprocess.run(['sudo','/usr/local/sbin/vigilis-dev-update-mode',action],capture_output=True,text=True,timeout=10,check=True)
        config.setdefault('updates',{})['allow_unsigned_developer_updates']=enabled
        save_config(config)
        logger.warning('Unsigned developer updates %s', 'enabled' if enabled else 'disabled')
        return jsonify(json.loads(result.stdout.strip()))
    except Exception as exc:
        return jsonify({'ok':False,'error':str(exc)}),400

@app.post('/api/update/upload')
def update_upload():
    f=request.files.get('update')
    if not f or not f.filename:
        return jsonify({'ok':False,'error':'No update package selected'}),400
    if not f.filename.lower().endswith('.vup'):
        return jsonify({'ok':False,'error':'Only signed VIGILIS .vup packages are accepted'}),400
    folder=ROOT/'data'/'updates'/'incoming'; folder.mkdir(parents=True,exist_ok=True)
    dest=folder/f"{uuid.uuid4().hex}.vup"
    f.save(dest)
    try:
        # The root-owned helper performs a second, authoritative signature,
        # checksum and archive-path verification before changing any files.
        check=subprocess.run(['sudo','/usr/local/sbin/vigilis-update-helper','--verify-only',str(dest)],capture_output=True,text=True,timeout=60)
        if check.returncode != 0:
            raise RuntimeError((check.stderr or check.stdout or 'Package verification failed').strip())
        info=json.loads(check.stdout.strip().splitlines()[-1])
        subprocess.run(['sudo','/usr/local/sbin/vigilis-update-launcher',str(dest)],capture_output=True,text=True,timeout=20,check=True)
        logger.warning('Verified update upload: %s (%s)',info.get('version'),info.get('trust','signed'))
        return jsonify({'ok':True,'version':info.get('version'),'trust':info.get('trust','signed'),'message':'Installation started'})
    except Exception as exc:
        try: dest.unlink()
        except OSError: pass
        logger.warning('Update rejected: %s',exc)
        return jsonify({'ok':False,'error':str(exc)}),400

def main(): app.run(host=config['app']['host'],port=int(config['app']['port']),debug=bool(config['app'].get('debug',False)),threaded=True)
if __name__=='__main__': main()
