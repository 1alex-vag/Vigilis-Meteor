from __future__ import annotations
import copy
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]
CONFIG_PATH = ROOT / "config.yaml"
EXAMPLE_PATH = ROOT / "config.example.yaml"

def _merge(base: dict, override: dict) -> dict:
    result = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = value
    return result

def load_config() -> dict:
    base = yaml.safe_load(EXAMPLE_PATH.read_text(encoding="utf-8")) or {}
    if not CONFIG_PATH.exists():
        save_config(base)
        return base
    current = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8")) or {}
    return _merge(base, current)

def save_config(config: dict) -> None:
    CONFIG_PATH.write_text(yaml.safe_dump(config, allow_unicode=True, sort_keys=False), encoding="utf-8")
