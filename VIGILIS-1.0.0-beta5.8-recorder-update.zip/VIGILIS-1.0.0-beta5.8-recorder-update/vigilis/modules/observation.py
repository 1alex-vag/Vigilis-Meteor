from __future__ import annotations
from datetime import datetime, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from astral import Observer
from astral.sun import elevation, azimuth


class ObservationManager:
    def __init__(self, config):
        self.config = config

    def _timezone(self):
        name = str(self.config.get('location', {}).get('timezone') or 'UTC').strip()
        try:
            return ZoneInfo(name), name
        except ZoneInfoNotFoundError:
            return timezone.utc, 'UTC'

    def astronomy(self):
        loc = self.config.get('location', {})
        try:
            latitude = float(loc.get('latitude', 0))
            longitude = float(loc.get('longitude', 0))
            elevation_m = float(loc.get('elevation_m', 0) or 0)
            tz, timezone_name = self._timezone()
            local_now = datetime.now(tz)
            utc_now = local_now.astimezone(timezone.utc)
            observer = Observer(latitude, longitude, elevation_m)
            altitude = round(float(elevation(observer, local_now)), 2)
            sun_azimuth = round(float(azimuth(observer, local_now)), 2)
            return {
                'sun_altitude': altitude,
                'sun_azimuth': sun_azimuth,
                'latitude': latitude,
                'longitude': longitude,
                'elevation_m': elevation_m,
                'timezone': timezone_name,
                'local_time': local_now.isoformat(timespec='seconds'),
                'utc_time': utc_now.isoformat(timespec='seconds'),
                'error': '',
            }
        except Exception as exc:
            return {
                'sun_altitude': None,
                'sun_azimuth': None,
                'timezone': str(loc.get('timezone') or 'UTC'),
                'error': str(exc),
            }

    def sun_altitude(self):
        return self.astronomy().get('sun_altitude')

    def _local_now(self):
        tz, _ = self._timezone()
        return datetime.now(tz)

    def time_window_active(self, start, stop):
        now = self._local_now().strftime('%H:%M')
        return (start <= now or now < stop) if start > stop else start <= now < stop

    def status(self):
        astronomy = self.astronomy()
        sun = astronomy.get('sun_altitude')
        mode = self.config.get('observation', {}).get('mode', 'sun')
        if mode == 'always':
            active = True
            label = 'Observation running'
        elif mode == 'custom':
            start = self.config['observation'].get('custom_start', '20:00')
            stop = self.config['observation'].get('custom_stop', '06:00')
            active = self.time_window_active(start, stop)
            label = 'Observation running' if active else 'Waiting for schedule...'
        else:
            start = float(self.config['observation'].get('start_sun_altitude', -6))
            active = sun is not None and sun <= start
            label = 'Observation running' if active else 'Waiting for sunset...'
        return {
            'active': active,
            'label': label,
            'mode': mode,
            'sun_altitude': sun,
            'astronomy': astronomy,
        }
