from __future__ import annotations

from collections import Counter
from pathlib import Path
import datetime as dt
import json
import os
import shutil
import subprocess
import threading
import uuid
import time

import cv2
import numpy as np

from .classification import EventClassifier


class StorageManager:
    def __init__(self, root, config=None, event_index=None):
        self.root = Path(root).resolve()
        self.config = config or {}
        self.event_index = event_index
        self._render_locks: dict[str, threading.Lock] = {}
        self._render_locks_guard = threading.Lock()
        self._stack_jobs: dict[str, dict] = {}
        self._stack_jobs_lock = threading.Lock()

    @property
    def configured_recordings_root(self):
        raw = str(self.config.get('storage', {}).get('recordings_path', '') or '').strip()
        path = Path(raw).expanduser() if raw else self.root / 'recordings'
        if not path.is_absolute():
            path = self.root / path
        return path.resolve()

    @property
    def internal_recordings_root(self):
        return (self.root / 'recordings').resolve()

    @property
    def recordings_root(self):
        """Return the active recording root without blocking startup.

        The configured external path remains the preferred destination. If the
        drive is not mounted, VIGILIS temporarily records to the internal SD
        archive and never creates a misleading directory below /media or /mnt.
        """
        preferred = self.configured_recordings_root
        external = str(preferred).startswith(('/media/', '/mnt/'))
        path = self.internal_recordings_root if external and not self._path_is_mounted(preferred) else preferred
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def favorites_root(self):
        path = self.recordings_root / 'favorites'
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def stacks_root(self):
        path = self.recordings_root / 'event_stacks'
        path.mkdir(parents=True, exist_ok=True)
        return path

    @staticmethod
    def _read_classification(path):
        try:
            return str(json.loads(Path(path).read_text(encoding='utf-8')).get('classification', 'unknown')).lower()
        except Exception:
            return 'unknown'

    @staticmethod
    def _event_day(data, path=None):
        created = str(data.get('created_at', ''))
        if len(created) >= 10:
            return created[:10]
        if path is not None:
            for part in Path(path).parts:
                try:
                    dt.date.fromisoformat(part)
                    return part
                except (TypeError, ValueError):
                    continue
        event_id = str(data.get('id', ''))
        if event_id.startswith('event_') and len(event_id) >= 14:
            raw = event_id[6:14]
            return f'{raw[:4]}-{raw[4:6]}-{raw[6:8]}'
        return 'unknown'

    @staticmethod
    def _recordings_root_for_metadata(meta_path):
        if meta_path is None:
            return None
        path = Path(meta_path).resolve()
        parts = path.parts
        if 'favorites' in parts:
            index = parts.index('favorites')
            return Path(*parts[:index])
        for index, part in enumerate(parts):
            try:
                dt.date.fromisoformat(part)
            except (TypeError, ValueError):
                continue
            return Path(*parts[:index])
        return None

    def _resolve_value(self, value, meta_path=None):
        if not value:
            return None
        raw = str(value)
        if raw.startswith('storage:'):
            event_root = self._recordings_root_for_metadata(meta_path) or self.recordings_root
            return (event_root / raw[8:]).resolve()
        p = Path(raw).expanduser()
        if p.is_absolute():
            return p.resolve()
        candidate = (self.root / p).resolve()
        if candidate.exists() or str(p).startswith(('recordings/', 'data/')):
            return candidate
        if meta_path is not None:
            local = (Path(meta_path).parent / p.name).resolve()
            if local.exists():
                return local
        return (self.recordings_root / p).resolve()

    def _encode_path(self, path, recordings_root=None):
        p = Path(path).resolve()
        base = Path(recordings_root).resolve() if recordings_root else self.recordings_root
        try:
            return 'storage:' + str(p.relative_to(base))
        except ValueError:
            try:
                return str(p.relative_to(self.root))
            except ValueError:
                return str(p)

    def _decorate(self, data, path=None):
        data = dict(data)
        data.setdefault('day', self._event_day(data, path))
        event_id = data.get('id', Path(path).stem if path else '')
        data['video_url'] = f'/api/events/{event_id}/file/video'
        data['thumbnail_url'] = f'/api/events/{event_id}/file/thumbnail'
        if data.get('overlay_video'):
            data['overlay_url'] = f'/api/events/{event_id}/file/overlay'
        data['favorite'] = bool(data.get('favorite'))
        return data

    def events(self, limit=200, offset=0, day=None, favorites=False, classification=None):
        if not self.event_index:
            return []
        return [self._decorate(item) for item in self.event_index.events(
            limit=limit, offset=offset, day=day, favorites=favorites, classification=classification
        )]

    def event_days(self):
        return self.event_index.event_days() if self.event_index else []

    def event_count(self, day=None, favorites=False, classification=None):
        return self.event_index.count(day=day, favorites=favorites, classification=classification) if self.event_index else 0

    def event_summary(self, day=None):
        return self.event_index.summary(day) if self.event_index else {
            'day': day or dt.date.today().isoformat(), 'total': 0, 'meteor': 0,
            'aircraft': 0, 'unknown': 0, 'ssd': 0, 'sd': 0
        }

    def _find_metadata(self, event_id):
        return self.event_index.metadata_path(event_id) if self.event_index else None

    def get(self, event_id):
        data = self.event_index.get(event_id) if self.event_index else None
        return self._decorate(data) if data else None

    def event_file(self, event_id, kind):
        return self.event_index.event_file(event_id, kind) if self.event_index else None

    def _move_event(self,p,target_dir,favorite):
        data=json.loads(p.read_text(encoding='utf-8'))
        target_dir.mkdir(parents=True,exist_ok=True)
        moved={}
        for key in ('video','thumbnail','overlay_video'):
            old=self._resolve_value(data.get(key),p)
            if old and old.exists():
                new=target_dir/old.name
                if old.resolve()!=new.resolve(): shutil.move(str(old),str(new))
                moved[key]=new
        new_meta=target_dir/p.name
        data['favorite']=favorite
        event_root=self._recordings_root_for_metadata(new_meta) or self.recordings_root
        for key,new in moved.items(): data[key]=self._encode_path(new,event_root)
        new_meta.write_text(json.dumps(data,indent=2),encoding='utf-8')
        if new_meta.resolve()!=p.resolve() and p.exists(): p.unlink()
        self._prune_empty(p.parent)
        if self.event_index:
            self.event_index.upsert(data, new_meta, event_root)
        return self._decorate(data,new_meta)

    def update(self,event_id,**changes):
        p=self._find_metadata(event_id)
        if not p:return None
        data=json.loads(p.read_text(encoding='utf-8'))
        event_root=self._recordings_root_for_metadata(p) or self.recordings_root
        old_fav=bool(data.get('favorite') or (event_root/'favorites') in p.parents)
        old_class=str(data.get('classification','unknown')).lower()
        new_fav=bool(changes.get('favorite',old_fav))
        new_class=str(changes.get('classification',old_class)).lower()
        allowed={'unknown','meteor','aircraft','satellite','insect','false_positive'}
        if new_class not in allowed:new_class='unknown'
        data.update(changes);data['classification']=new_class
        p.write_text(json.dumps(data,indent=2),encoding='utf-8')
        if new_fav!=old_fav or (not new_fav and new_class!=old_class):
            day=self._event_day(data,p)
            event_root=self._recordings_root_for_metadata(p) or self.recordings_root
            target=(event_root/'favorites'/day) if new_fav else (event_root/day/new_class)
            return self._move_event(p,target,new_fav)
        if self.event_index:
            event_root=self._recordings_root_for_metadata(p) or self.recordings_root
            self.event_index.upsert(data, p, event_root)
        return self._decorate(data,p)

    def _prune_empty(self,parent):
        base=self._recordings_root_for_metadata(parent) or self.recordings_root
        while parent!=base and base in parent.parents:
            try: parent.rmdir()
            except OSError: break
            parent=parent.parent

    def delete(self,event_id,allow_favorite=False):
        p=self._find_metadata(event_id)
        if not p:return []
        data=json.loads(p.read_text(encoding='utf-8'))
        event_root=self._recordings_root_for_metadata(p) or self.recordings_root
        if (data.get('favorite') or (event_root/'favorites') in p.parents) and not allow_favorite:
            raise PermissionError('Favorite events are protected. Remove the favorite first.')
        removed=[]; candidates=[]
        for key in ('video','thumbnail','overlay_video'):
            f=self._resolve_value(data.get(key),p)
            if f:candidates.append(f)
        v=self._resolve_value(data.get('video'),p)
        if v:candidates.append(v.with_name(f'{v.stem}_overlay.mp4'))
        for f in candidates:
            if f.exists() and f.is_file(): f.unlink(); removed.append(str(f))
        p.unlink(); removed.append(str(p)); self._prune_empty(p.parent)
        if self.event_index:
            self.event_index.delete(event_id)
        return removed

    def delete_many(self,event_ids):
        removed=[]; protected=[]
        for event_id in dict.fromkeys(event_ids or []):
            try: removed.extend(self.delete(str(event_id)))
            except PermissionError: protected.append(str(event_id))
        return {'removed':removed,'protected':protected}

    def delete_day(self,day):
        ids=[]
        for event in self.events(limit=None,day=day): ids.append(event['id'])
        result=self.delete_many(ids)
        return {'day':day,'events_removed':len(ids)-len(result['protected']),**result}

    def cleanup(self,days):
        cutoff=dt.date.today()-dt.timedelta(days=max(1,int(days)))
        removed_events=0
        for info in self.event_days():
            try: event_day=dt.date.fromisoformat(info['date'])
            except ValueError: continue
            if event_day < cutoff:
                result=self.delete_day(info['date']); removed_events += result['events_removed']
        return {'removed_events':removed_events,'cutoff':cutoff.isoformat()}

    def reclassify_existing(self, only_unknown=True):
        cfg=self.config.get('classification',{})
        changed=0; skipped=0; failed=0; counts=Counter()
        items=self.events(limit=None)
        for item in items:
            try:
                current=str(item.get('classification','unknown')).lower()
                if only_unknown and current!='unknown':
                    skipped+=1
                    continue
                result=EventClassifier.classify(
                    item.get('detections') or [], item.get('fps',0), item.get('frames',0), item.get('trigger_path'),
                    aircraft_threshold=int(cfg.get('aircraft_threshold',70)),
                    meteor_threshold=int(cfg.get('meteor_threshold',78)),
                )
                changes={
                    'classification':result['classification'],
                    'classification_engine':'VIGILIS Classification Engine 1.0',
                    'classification_reason':result.get('reason'),
                    'aircraft_score':result.get('aircraft_score',0),
                    'meteor_score':result.get('meteor_score',0),
                    'classification_features':result.get('features',{}),
                }
                self.update(str(item.get('id')),**changes)
                counts[result['classification']]+=1;changed+=1
            except Exception:
                failed+=1
        return {'processed':changed,'skipped':skipped,'failed':failed,'classifications':dict(counts)}

    def storage_status(self):
        try:
            root=self.recordings_root
            usage=shutil.disk_usage(root)
            preferred=self.configured_recordings_root
            fallback=root.resolve()!=preferred.resolve()
            return {
                'ok': True,
                'path':str(root),
                'active_path':str(root),
                'preferred_path':str(preferred),
                'fallback_active':fallback,
                'total_gb':round(usage.total/2**30,2),
                'used_gb':round(usage.used/2**30,2),
                'free_gb':round(usage.free/2**30,2),
                'favorites':self.event_count(favorites=True),
                'error':'',
            }
        except Exception as exc:
            raw=str(self.config.get('storage',{}).get('recordings_path','') or self.root/'recordings')
            return {'ok':False,'path':raw,'total_gb':None,'used_gb':None,'free_gb':None,'favorites':0,'error':str(exc)}

    @staticmethod
    def _path_is_mounted(path: Path) -> bool:
        path=Path(path).resolve()
        for parent in (path, *path.parents):
            text=str(parent)
            external_mount=text in {'/media','/mnt'} or text.startswith(('/media/','/mnt/'))
            if external_mount and os.path.ismount(parent):
                return True
        return False

    def activate_storage_path(self, raw_path):
        """Validate and activate a recording root without leaving VIGILIS broken.

        The new path is prepared first, including all VIGILIS subfolders and a
        read/write verification. Only after every check succeeds is the live
        configuration changed. On any failure the previous path remains active.
        """
        previous=str(self.config.get('storage',{}).get('recordings_path','') or '')
        raw=str(raw_path or '').strip()
        target=(Path(raw).expanduser() if raw else self.root/'recordings')
        if not target.is_absolute():
            target=self.root/target
        target=target.resolve()

        # External paths must sit on an actually mounted filesystem. This avoids
        # silently writing into an empty /media directory when a drive is absent.
        if str(target).startswith(('/media/','/mnt/')) and not self._path_is_mounted(target):
            raise RuntimeError('External storage is not mounted or has been disconnected.')

        created=[]
        try:
            target.mkdir(parents=True,exist_ok=True)
            for name in ('favorites','event_stacks','thumbnails','logs','timelapse'):
                folder=target/name
                folder.mkdir(parents=True,exist_ok=True)
                created.append(folder)

            probe=target/f'.vigilis_storage_test_{os.getpid()}_{uuid.uuid4().hex[:8]}'
            payload=b'VIGILIS storage read/write test\n'
            with probe.open('wb') as handle:
                handle.write(payload); handle.flush(); os.fsync(handle.fileno())
            if probe.read_bytes()!=payload:
                raise RuntimeError('Storage read-back test failed.')
            probe.unlink(missing_ok=True)

            usage=shutil.disk_usage(target)
            if usage.free < 100*1024*1024:
                raise RuntimeError('Storage has less than 100 MB free.')

            self.config.setdefault('storage',{})['recordings_path']=str(target)
            return {
                'path':str(target),
                'previous_path':previous,
                'total_gb':round(usage.total/2**30,2),
                'free_gb':round(usage.free/2**30,2),
                'folders_created':[str(x) for x in created],
                'write_test':True,
                'read_test':True,
            }
        except Exception:
            self.config.setdefault('storage',{})['recordings_path']=previous
            raise

    @staticmethod
    def _lsblk_tree():
        columns='NAME,KNAME,PATH,TYPE,SIZE,FSTYPE,LABEL,UUID,MOUNTPOINTS,MODEL,TRAN,RM,RO'
        result=subprocess.run(['lsblk','-J','-b','-o',columns],capture_output=True,text=True,timeout=8,check=True)
        return json.loads(result.stdout).get('blockdevices',[])

    @classmethod
    def storage_devices(cls):
        devices=[]
        try: roots=cls._lsblk_tree()
        except Exception: return devices
        for disk in roots:
            path=str(disk.get('path') or '')
            if disk.get('type')!='disk' or not path.startswith('/dev/sd'): continue
            transport=str(disk.get('tran') or '').lower()
            if transport and transport!='usb': continue
            children=disk.get('children') or []
            parts=[]
            for part in children:
                if part.get('type')!='part': continue
                mounts=[m for m in (part.get('mountpoints') or []) if m]
                parts.append({
                    'device':part.get('path'),'name':part.get('name'),'size_gb':round(int(part.get('size') or 0)/2**30,1),
                    'filesystem':part.get('fstype') or '', 'label':part.get('label') or '', 'uuid':part.get('uuid') or '',
                    'mountpoint':mounts[0] if mounts else '', 'mounted':bool(mounts), 'read_only':bool(part.get('ro'))
                })
            devices.append({
                'device':path,'name':(disk.get('model') or disk.get('name') or 'USB storage').strip(),
                'size_gb':round(int(disk.get('size') or 0)/2**30,1),'transport':transport or 'usb',
                'has_partition':bool(parts),'partitions':parts,'can_initialize':not parts and not bool(disk.get('ro'))
            })
        return devices

    @classmethod
    def available_storage_locations(cls):
        out=[]; seen=set()
        internal=Path.home()/'vigilis'/'recordings'
        candidates=[(internal,'Internal VIGILIS storage')]
        for disk in cls.storage_devices():
            for part in disk['partitions']:
                if part['mounted']:
                    target=Path(part['mountpoint'])/'VIGILIS'/'recordings'
                    candidates.append((target,f"{disk['name']} · {part['filesystem'] or 'filesystem'}"))
        for p,name in candidates:
            try:
                p=p.expanduser().resolve(); p.mkdir(parents=True,exist_ok=True)
                if str(p) in seen or not os.access(p,os.W_OK): continue
                seen.add(str(p)); u=shutil.disk_usage(p)
                out.append({'path':str(p),'name':name,'free_gb':round(u.free/2**30,1),'total_gb':round(u.total/2**30,1)})
            except Exception: continue
        return out

    @staticmethod
    def prepare_storage(device, action):
        if action not in {'initialize','mount'}: raise ValueError('Unsupported storage action.')
        if not str(device).startswith('/dev/sd'): raise ValueError('Only USB storage devices are supported.')
        command=['sudo','/usr/local/sbin/vigilis-storage-helper',action,str(device)]
        result=subprocess.run(command,capture_output=True,text=True,timeout=180)
        if result.returncode!=0: raise RuntimeError((result.stderr or result.stdout or 'Storage preparation failed').strip())
        try: return json.loads(result.stdout.strip().splitlines()[-1])
        except Exception: raise RuntimeError('Storage helper returned an invalid response.')

    @staticmethod
    def _expanded_box(box, margin_percent):
        margin=max(0,min(500,int(margin_percent)))/100.0
        x=float(box.get('x',0)); y=float(box.get('y',0)); w=float(box.get('w',0)); h=float(box.get('h',0))
        x=max(0.0,x-w*margin); y=max(0.0,y-h*margin)
        w=min(1.0-x,w*(1.0+2.0*margin)); h=min(1.0-y,h*(1.0+2.0*margin))
        return x,y,w,h

    def _read_event_sequence(self,event,max_frames=240):
        meta_path=self._find_metadata(event.get('id',''))
        data=event if meta_path is None else json.loads(meta_path.read_text(encoding='utf-8'))
        video=self._resolve_value(data.get('video'),meta_path)
        frames=[]
        if video and video.exists():
            cap=cv2.VideoCapture(str(video))
            try:
                total=int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
                stride=max(1,total//max_frames) if total else 1; idx=0
                while len(frames)<max_frames:
                    ok,frame=cap.read()
                    if not ok: break
                    if idx%stride==0:
                        if frame.ndim==3: gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
                        else: gray=frame
                        frames.append(gray)
                    idx+=1
            finally: cap.release()
        if not frames:
            thumb=self._resolve_value(data.get('thumbnail'),meta_path)
            image=cv2.imread(str(thumb),cv2.IMREAD_GRAYSCALE) if thumb and thumb.exists() else None
            if image is not None: frames=[image]
        return data,frames

    def _event_stack_layer(self,event,overlay=False,margin_percent=0):
        data,frames=self._read_event_sequence(event,max_frames=360)
        if not frames: return None,None,[]
        h,w=frames[0].shape[:2]
        frames=[cv2.resize(f,(w,h)) if f.shape[:2]!=(h,w) else f for f in frames]
        sample=np.stack(frames,axis=0)
        background=np.median(sample,axis=0).astype(np.uint8)
        detections=data.get('detections') or []
        if not detections: return background,np.zeros((h,w,3),dtype=np.uint8),[]
        track=np.zeros((h,w),dtype=np.uint8); boxes=[]; centers=[]
        # Use detector coordinates to restrict extraction to the actual moving meteor path.
        extraction_margin=max(75,min(250,int(margin_percent or 100)))
        for detection in detections:
            box=detection.get('box') or {}
            x,y,bw,bh=self._expanded_box(box,extraction_margin)
            x1=max(0,int(x*w)); y1=max(0,int(y*h)); x2=min(w,int((x+bw)*w)); y2=min(h,int((y+bh)*h))
            if x2<=x1 or y2<=y1: continue
            boxes.append((x1,y1,x2,y2)); centers.append(((x1+x2)//2,(y1+y2)//2))
            cv2.rectangle(track,(x1,y1),(x2,y2),255,-1)
        if len(centers)>1:
            thickness=max(7,int(np.median([max(2,b[3]-b[1]) for b in boxes])))
            for a,b in zip(centers,centers[1:]): cv2.line(track,a,b,255,thickness)
        track=cv2.dilate(track,np.ones((5,5),np.uint8),iterations=1)
        maximum=np.max(sample,axis=0).astype(np.uint8)
        diff=cv2.subtract(maximum,background)
        roi_values=diff[track>0]
        threshold=max(5,int(np.percentile(roi_values,72)) if roi_values.size else 9)
        meteor_mask=np.where((diff>=threshold)&(track>0),255,0).astype(np.uint8)
        meteor_mask=cv2.morphologyEx(meteor_mask,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
        count,labels,stats,_=cv2.connectedComponentsWithStats(meteor_mask,8)
        clean=np.zeros_like(meteor_mask)
        for i in range(1,count):
            _,_,cw,ch,area=stats[i]
            elong=max(cw,ch)/max(1,min(cw,ch))
            if area>=4 and (elong>=1.4 or max(cw,ch)>=5): clean[labels==i]=255
        # Soft edge keeps faint meteor trails natural instead of dot-like.
        alpha=cv2.GaussianBlur(clean,(0,0),1.1).astype(np.float32)/255.0
        signal=cv2.cvtColor(maximum,cv2.COLOR_GRAY2BGR).astype(np.float32)
        layer=(signal*alpha[...,None]).clip(0,255).astype(np.uint8)
        return background,layer,boxes

    def _create_event_stack_sync(self,day,favorites_only=False,overlay=False,margin_percent=0,progress=None):
        events=self.events(limit=None,day=None if favorites_only else day,favorites=favorites_only,classification='meteor')
        if favorites_only and day: events=[e for e in events if e.get('day')==day]
        if not events: raise ValueError('No events classified as meteor are available for this day.')
        base=None; composite=None; all_boxes=[]; processed=0
        total=len(events)
        for event in events:
            background,layer,boxes=self._event_stack_layer(event,overlay=overlay,margin_percent=margin_percent)
            processed+=1
            if background is not None:
                if base is None:
                    base=cv2.cvtColor(background,cv2.COLOR_GRAY2BGR); composite=base.copy()
                elif background.shape[:2]!=base.shape[:2]:
                    layer=cv2.resize(layer,(base.shape[1],base.shape[0]))
                composite=np.maximum(composite,layer)
                if overlay: all_boxes.extend(boxes)
            if progress: progress(processed,total,'Extracting meteor trails')
        if composite is None: raise ValueError('No readable event frames are available for this day.')
        if overlay:
            for x1,y1,x2,y2 in all_boxes:
                cv2.rectangle(composite,(x1,y1),(x2,y2),(60,230,90),max(2,composite.shape[1]//900))
        suffix='_overlay' if overlay else '_clean'
        output=self.stacks_root/f'event_stack_{day}{suffix}.jpg'
        if progress: progress(total,total,'Finalizing image')
        cv2.imwrite(str(output),composite,[int(cv2.IMWRITE_JPEG_QUALITY),94])
        return output

    def create_event_stack(self,day,favorites_only=False,overlay=False,margin_percent=0):
        return self._create_event_stack_sync(day,favorites_only,overlay,margin_percent)

    def start_event_stack(self,day,overlay=False,margin_percent=0):
        job_id=uuid.uuid4().hex[:12]
        job={'id':job_id,'day':day,'overlay':bool(overlay),'status':'queued','stage':'Queued','processed':0,'total':0,'percent':0,'started_at':time.time(),'finished_at':None,'output':None,'error':''}
        with self._stack_jobs_lock: self._stack_jobs[job_id]=job
        def update(done,total,stage):
            with self._stack_jobs_lock:
                current=self._stack_jobs[job_id]; current.update(status='running',stage=stage,processed=done,total=total,percent=round(done*100/max(1,total)))
        def worker():
            try:
                update(0,self.event_count(day=day,classification='meteor'),'Preparing classified meteors')
                output=self._create_event_stack_sync(day,overlay=overlay,margin_percent=margin_percent,progress=update)
                with self._stack_jobs_lock: self._stack_jobs[job_id].update(status='complete',stage='Complete',percent=100,finished_at=time.time(),output=str(output))
            except Exception as exc:
                with self._stack_jobs_lock: self._stack_jobs[job_id].update(status='failed',stage='Failed',finished_at=time.time(),error=str(exc))
        threading.Thread(target=worker,daemon=True,name=f'event-stack-{job_id}').start()
        return dict(job)

    def event_stack_status(self,job_id):
        with self._stack_jobs_lock:
            job=self._stack_jobs.get(job_id)
            return dict(job) if job else None

    def event_stack_file(self,job_id):
        job=self.event_stack_status(job_id)
        if not job or job.get('status')!='complete' or not job.get('output'): return None
        path=Path(job['output'])
        return path if path.exists() else None

    def _render_lock(self,event_id):
        with self._render_locks_guard:return self._render_locks.setdefault(event_id,threading.Lock())

    def render_overlay_video(self,event_id,margin_percent=0):
        lock=self._render_lock(event_id)
        with lock:
            meta_path=self._find_metadata(event_id)
            if not meta_path:raise FileNotFoundError('Event metadata not found.')
            data=json.loads(meta_path.read_text(encoding='utf-8'))
            source=self._resolve_value(data.get('video'),meta_path)
            if not source or not source.exists():raise FileNotFoundError('Original video not found.')
            detections=data.get('detections') or []
            if not detections:raise ValueError('No detection coordinates are stored for this event.')
            margin=max(0,min(500,int(margin_percent)))
            output=source.with_name(f'{source.stem}_overlay_m{margin}.mp4')
            if output.exists() and output.stat().st_mtime>=max(source.stat().st_mtime,meta_path.stat().st_mtime):return output
            cap=cv2.VideoCapture(str(source)); fps=float(cap.get(cv2.CAP_PROP_FPS) or data.get('fps') or 5.0)
            width=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH));height=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            if not cap.isOpened() or width<=0 or height<=0:raise RuntimeError('Original video could not be opened.')
            temp=output.with_suffix('.rendering.mp4');writer=cv2.VideoWriter(str(temp),cv2.VideoWriter_fourcc(*'mp4v'),max(.1,fps),(width,height),True)
            sorted_d=sorted(detections,key=lambda i:float(i.get('time',0)));tol=max(.35,2/max(.1,fps));idx=0
            try:
                while True:
                    ok,frame=cap.read()
                    if not ok:break
                    if frame.ndim==2:frame=cv2.cvtColor(frame,cv2.COLOR_GRAY2BGR)
                    now=idx/max(.1,fps);best=None;dist=float('inf')
                    for d in sorted_d:
                        dd=abs(float(d.get('time',0))-now)
                        if dd<dist:best,dist=d,dd
                        if float(d.get('time',0))>now+tol:break
                    if best is not None and dist<=tol:
                        b=best.get('box') or {};x=float(b.get('x',0));y=float(b.get('y',0));bw=float(b.get('w',0));bh=float(b.get('h',0))
                        mx=bw*margin/100;my=bh*margin/100;x=max(0,x-mx);y=max(0,y-my);bw=min(1-x,bw+2*mx);bh=min(1-y,bh+2*my)
                        x1=int(x*width);y1=int(y*height);x2=max(x1+1,int((x+bw)*width));y2=max(y1+1,int((y+bh)*height))
                        cv2.rectangle(frame,(x1,y1),(min(width-1,x2),min(height-1,y2)),(60,230,90),max(2,width//900))
                    writer.write(frame);idx+=1
            finally:cap.release();writer.release()
            if idx==0 or not temp.exists():raise RuntimeError('Overlay video rendering produced no frames.')
            temp.replace(output);data['overlay_video']=self._encode_path(output);meta_path.write_text(json.dumps(data,indent=2),encoding='utf-8')
            if self.event_index:
                self.event_index.upsert(data, meta_path, self.recordings_root)
            return output
