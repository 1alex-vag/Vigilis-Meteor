from __future__ import annotations

import math
from collections import Counter, defaultdict


class EventClassifier:
    """Lightweight, explainable event classifier.

    It does not use a neural network and never deletes recordings.  It evaluates
    temporal continuity, apparent speed, path straightness and repeated gaps to
    separate likely aircraft from short meteor-like tracks.  Ambiguous events
    remain in ``unknown`` for manual review.
    """

    @staticmethod
    def _clamp(value, lo=0.0, hi=100.0):
        return max(lo, min(hi, float(value)))

    @staticmethod
    def analyse(detections, fps, total_frames, trigger_path=None):
        fps=max(0.1, float(fps or 1.0))
        total_frames=max(1, int(total_frames or 1))
        duration=total_frames/fps
        by_time=defaultdict(list)
        for item in detections or []:
            try:
                t=round(float(item.get('time',0.0)), 3)
                box=item.get('box') or {}
                x=float(box.get('x',0)); y=float(box.get('y',0)); w=float(box.get('w',0)); h=float(box.get('h',0))
                by_time[t].append({
                    'time':t, 'center':(x+w/2.0,y+h/2.0), 'area':max(0.0,w*h),
                    'score':float(item.get('score',0)), 'delta':float(box.get('delta',0)),
                })
            except (TypeError, ValueError):
                continue
        times=sorted(by_time)
        points=[]
        multi_frames=0
        for t in times:
            entries=by_time[t]
            if len(entries)>1: multi_frames+=1
            points.append(max(entries,key=lambda e:(e['score'],e['delta'],e['area'])))
        active_span=(times[-1]-times[0]) if len(times)>1 else (1.0/fps if times else 0.0)
        expected=max(1, int(round(active_span*fps))+1)
        continuity=min(1.0, len(times)/expected) if times else 0.0
        gaps=[]
        if len(times)>1:
            gaps=[max(0.0,(b-a)*fps-1.0) for a,b in zip(times,times[1:])]
        significant_gaps=sum(1 for g in gaps if g>=1.5)
        blink_ratio=(significant_gaps/max(1,len(gaps))) if gaps else 0.0
        multi_ratio=multi_frames/max(1,len(times))

        path_length=0.0
        displacement=0.0
        straightness=0.0
        speed=0.0
        if len(points)>1:
            coords=[p['center'] for p in points]
            path_length=sum(math.hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(coords,coords[1:]))
            displacement=math.hypot(coords[-1][0]-coords[0][0],coords[-1][1]-coords[0][1])
            straightness=displacement/path_length if path_length>1e-6 else 0.0
            speed=path_length/max(active_span,1.0/fps)
        peak_score=max((p['score'] for p in points),default=0.0)

        aircraft=0.0
        if active_span>=2.5: aircraft+=25
        if active_span>=4.0: aircraft+=15
        if speed and speed<0.10: aircraft+=20
        if speed and speed<0.045: aircraft+=10
        if continuity<0.72 and len(times)>=5: aircraft+=15
        if significant_gaps>=2: aircraft+=20
        if blink_ratio>=0.25: aircraft+=10
        if multi_ratio>=0.25: aircraft+=10
        if straightness>=0.65 and active_span>=2.0: aircraft+=5

        meteor=0.0
        if 0<active_span<=1.5: meteor+=30
        elif active_span<=3.0: meteor+=15
        if speed>=0.08: meteor+=20
        if speed>=0.16: meteor+=10
        if straightness>=0.72: meteor+=25
        if continuity>=0.55: meteor+=10
        if peak_score>=70: meteor+=10
        if trigger_path in {'fast_trail','single_frame'}: meteor+=10
        if significant_gaps>=2: meteor-=15
        if active_span>=4.0: meteor-=20

        aircraft=EventClassifier._clamp(aircraft)
        meteor=EventClassifier._clamp(meteor)
        features={
            'event_duration_seconds':round(duration,3), 'active_span_seconds':round(active_span,3),
            'samples':len(times), 'continuity':round(continuity,3),
            'significant_gaps':significant_gaps, 'blink_ratio':round(blink_ratio,3),
            'multiple_light_ratio':round(multi_ratio,3), 'normalized_path_length':round(path_length,4),
            'normalized_displacement':round(displacement,4), 'normalized_speed_per_second':round(speed,4),
            'straightness':round(straightness,3), 'peak_detection_score':round(peak_score,1),
        }
        return {'aircraft_score':round(aircraft,1),'meteor_score':round(meteor,1),'features':features}

    @staticmethod
    def classify(detections, fps, total_frames, trigger_path=None, aircraft_threshold=70, meteor_threshold=75):
        result=EventClassifier.analyse(detections,fps,total_frames,trigger_path)
        aircraft=result['aircraft_score']; meteor=result['meteor_score']
        label='unknown'; reason='ambiguous event'
        if aircraft>=aircraft_threshold and aircraft>=meteor+10:
            label='aircraft'; reason='long/slow or blinking track'
        elif meteor>=meteor_threshold and meteor>=aircraft+10:
            label='meteor'; reason='short, straight and fast track'
        result.update({'classification':label,'reason':reason})
        return result
