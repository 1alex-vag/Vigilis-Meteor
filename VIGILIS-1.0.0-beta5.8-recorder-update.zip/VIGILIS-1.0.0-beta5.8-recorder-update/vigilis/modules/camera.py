from __future__ import annotations

import threading
import time
from collections import deque

import cv2
import numpy as np


class CameraManager:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.lock = threading.Lock()
        self.frame = None
        self.seq = 0
        self.status = {
            'running': False,
            'camera_ok': False,
            'fps': 0.0,
            'frames': 0,
            'dropped': 0,
            'last_error': '',
            'backend': 'none',
            'last_frame_at': None,
            'pixel_format': '',
            'capture_format': '',
            'processing_format': '',
            'profile': '',
            'tuning_profile': 'standard',
            'tuning_file': '',
            'target_fps': None,
            'exposure_mode': '',
            'camera_name': '',
            'camera_temperature_c': None,
            'exposure_us': None,
            'analogue_gain': None,
            'frame_duration_us': None,
            'lux': None,
            'preset': '',
            'image_enhancement': 'natural',
            'vision_engine': 'off',
            'vision_gamma': 1.0,
            'vision_low': 0.0,
            'vision_high': 255.0,
            'vision_mean': 0.0,
            'vision_median': 0.0,
            'vision_clipped_percent': 0.0,
            'vision_tnr': 'off',
            'vision_bright_points': 0,
            'vision_background': 0.0,
        }
        self.stop_event = threading.Event()
        self.thread = None
        self.picam = None
        self.cap = None
        self.zwo = None
        self._tnr_accumulator = None
        self._tnr_prev_gray = None

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._run, daemon=True, name='camera-manager')
        self.thread.start()

    def _camera_controls(self, cam):
        """Build controls from the selected observatory preset.

        Presets keep the everyday UI simple. Expert mode exposes the manual
        exposure and analogue gain values. Automatic presets leave AEC/AGC to
        libcamera and only constrain the frame duration through the target FPS.
        """
        preset = str(cam.get('preset', 'meteor_hunter')).lower()
        preset_defaults = {
            'meteor_hunter': {'fps': 5, 'profile': 'automatic'},
            'moon': {'fps': 15, 'profile': 'automatic'},
            'day_calibration': {'fps': 30, 'profile': 'automatic'},
            'expert': {'fps': float(cam.get('fps', 10)), 'profile': 'manual'},
        }
        defaults = preset_defaults.get(preset, preset_defaults['meteor_hunter'])
        target_fps = max(1.0, float(cam.get('fps', defaults['fps'])))
        # Presets are authoritative. This also migrates older installations
        # that may still have profile: manual saved from alpha12.
        profile = 'manual' if preset == 'expert' else 'automatic'

        frame_us = max(1000, int(round(1_000_000 / target_fps)))
        controls = {
            'AwbEnable': bool(cam.get('awb_enabled', True)),
            'FrameDurationLimits': (frame_us, frame_us),
        }

        if profile == 'manual':
            exposure_us = max(100, int(cam.get('exposure_us', frame_us)))
            frame_us = max(frame_us, exposure_us)
            controls['FrameDurationLimits'] = (frame_us, frame_us)
            controls.update({
                'AeEnable': False,
                'ExposureTime': exposure_us,
                'AnalogueGain': max(1.0, min(31.62, float(cam.get('gain', 8.0)))),
            })
            exposure_mode = 'manual'
        else:
            controls['AeEnable'] = True
            controls['ExposureValue'] = float(cam.get('exposure_compensation', 0.0))
            exposure_mode = 'auto'

        return controls, profile, preset, target_fps, exposure_mode

    def _open(self):
        cam = self.config['camera']
        mode = cam.get('mode', 'auto')
        if mode == 'zwo':
            try:
                from .zwo_camera import ZwoCameraBackend
                z = ZwoCameraBackend(cam, self.logger)
                info = z.open()
                self.zwo = z
                self.status.update(camera_ok=True, backend='zwoasi', pixel_format=info.get('pixel_format','RAW8'), profile='zwo', preset=str(cam.get('preset','meteor_hunter')), target_fps=float(cam.get('fps',5)), last_error='', camera_name=info.get('name','ZWO ASI'), exposure_mode='auto' if info.get('auto_exposure') else 'manual', exposure_us=int(cam.get('zwo_exposure_us',20000)), analogue_gain=int(cam.get('zwo_gain',100)), frame_duration_us=None)
                self.logger.info('ZWO camera opened: %s', info)
                return True
            except Exception as exc:
                self.status['last_error'] = f'ZWO camera unavailable: {exc}'
                self.logger.warning(self.status['last_error'])
                return False
        if mode in ('auto', 'csi'):
            try:
                from pathlib import Path
                from picamera2 import Picamera2

                tuning_name = str(cam.get('tuning_profile', 'meteor')).lower()
                tuning_file = ''
                tuning = None
                if tuning_name not in ('standard', 'default', ''):
                    candidate = Path(__file__).resolve().parents[1] / 'tuning' / f'imx462_{tuning_name}.json'
                    if tuning_name == 'custom':
                        configured = str(cam.get('custom_tuning_file', '')).strip()
                        candidate = Path(configured).expanduser() if configured else Path(__file__).resolve().parents[2] / 'data' / 'custom_tuning.json'
                    if candidate.exists():
                        tuning_file = str(candidate)
                        tuning = Picamera2.load_tuning_file(tuning_file)
                    else:
                        self.logger.warning('Requested tuning profile %s not found at %s; using system default', tuning_name, candidate)
                        tuning_name = 'standard'

                p = Picamera2(tuning=tuning) if tuning is not None else Picamera2()
                output_mode = str(cam.get('output_mode', 'mono')).lower()
                # True low-bandwidth mono path for CSI cameras: ask the ISP for
                # YUV420 and retain only the Y (luminance) plane. RGB888 is used
                # only when colour output is explicitly selected.
                pixel_format = 'YUV420' if output_mode == 'mono' else str(cam.get('pixel_format', 'RGB888')).upper()
                if pixel_format == 'BGR888':
                    pixel_format = 'RGB888'

                controls, profile, preset, target_fps, exposure_mode = self._camera_controls(cam)
                cfg = p.create_video_configuration(
                    main={
                        'size': (int(cam['width']), int(cam['height'])),
                        'format': pixel_format,
                    },
                    controls=controls,
                )
                p.configure(cfg)
                p.start()
                self.picam = p
                self.status.update(
                    backend='picamera2',
                    pixel_format=pixel_format,
                    capture_format=pixel_format,
                    processing_format='Y8' if output_mode == 'mono' else pixel_format,
                    profile=profile,
                    preset=preset,
                    image_enhancement=str(cam.get('image_enhancement', 'enhanced')),
                    tuning_profile=tuning_name,
                    tuning_file=tuning_file,
                    target_fps=target_fps,
                    exposure_mode=exposure_mode,
                    exposure_us=controls.get('ExposureTime'),
                    analogue_gain=controls.get('AnalogueGain'),
                    frame_duration_us=controls.get('FrameDurationLimits', (None, None))[0],
                )
                self.logger.info(
                    'Camera opened: preset=%s profile=%s tuning=%s target_fps=%s controls=%s',
                    preset,
                    profile,
                    tuning_name,
                    target_fps,
                    controls,
                )
                return True
            except Exception as exc:
                self.logger.warning('Picamera2 unavailable: %s', exc)
                self.status['last_error'] = str(exc)
                if mode == 'csi':
                    return False

        source = cam.get('source') if mode == 'rtsp' else int(cam.get('device', 0))
        if mode == 'auto' and cam.get('source'):
            source = cam.get('source')
        cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG if isinstance(source, str) else cv2.CAP_ANY)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(cam['width']))
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(cam['height']))
        cap.set(cv2.CAP_PROP_FPS, float(cam.get('fps', 10)))
        if not cap.isOpened():
            self.status['last_error'] = f'cannot open camera: {source}'
            cap.release()
            return False
        self.cap = cap
        self.status.update(
            backend='opencv',
            pixel_format='BGR',
            profile=str(cam.get('profile', 'automatic')),
            preset=str(cam.get('preset', 'meteor_hunter')),
            image_enhancement=str(cam.get('image_enhancement', 'enhanced')),
            target_fps=float(cam.get('fps', 10)),
        )
        return True

    def _close(self):
        try:
            if self.picam:
                self.picam.stop()
                self.picam.close()
        except Exception:
            pass
        try:
            if self.cap:
                self.cap.release()
        except Exception:
            pass
        self.picam = None
        self.cap = None
        if self.zwo is not None:
            try:
                self.zwo.close()
            except Exception:
                pass
        self.zwo = None

    def _read(self):
        if self.zwo is not None:
            return self.zwo.read()
        if self.picam is not None:
            # This byte order is already correct for the OpenCV JPEG/video path
            # on the tested Raspberry Pi IMX462 pipeline. Do not swap channels.
            frame = self.picam.capture_array('main')
            if str(self.config['camera'].get('output_mode', 'mono')).lower() == 'mono' and self.status.get('capture_format') == 'YUV420':
                # Picamera2 represents YUV420 as an array with height * 1.5.
                # The first configured-height rows are the full-resolution Y plane.
                height = int(self.config['camera']['height'])
                frame = frame[:height, :]
            return True, frame
        if self.cap is not None:
            return self.cap.read()
        return False, None

    def _transform(self, frame):
        cam = self.config['camera']
        r = int(cam.get('rotate', 0))
        if r == 90:
            frame = cv2.rotate(frame, cv2.ROTATE_90_CLOCKWISE)
        elif r == 180:
            frame = cv2.rotate(frame, cv2.ROTATE_180)
        elif r == 270:
            frame = cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)
        if cam.get('flip_horizontal'):
            frame = cv2.flip(frame, 1)
        if cam.get('flip_vertical'):
            frame = cv2.flip(frame, 0)
        # Astronomy Mono: keep a genuine single-channel frame throughout the
        # Python pipeline. CSI/YUV420 already arrives as Y8; other backends are
        # converted once at the boundary. Preview, Vision, Detection and MP4
        # recording all consume this same mono frame.
        if str(cam.get('output_mode', 'mono')).lower() == 'mono':
            if frame.ndim == 2:
                gray = frame
            elif frame.shape[2] == 4:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGRA2GRAY)
            else:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            frame = gray
            self.status['output_mode'] = 'mono'
            self.status['processing_format'] = 'Y8'
        else:
            self.status['output_mode'] = 'color'
            self.status['processing_format'] = self.status.get('capture_format') or self.status.get('pixel_format')
        return frame

    def _vision_settings(self):
        cam = self.config.get('camera', {})
        mode = str(cam.get('vision_mode', 'balanced')).lower().strip()
        if mode not in {'off', 'balanced', 'deep', 'custom'}:
            mode = 'balanced'
        presets = {
            'off': dict(target=18.0, max_gain=1.0, gamma=1.0, tnr='off', sharpen=0.0),
            'balanced': dict(target=34.0, max_gain=1.8, gamma=0.72, tnr='off', sharpen=0.05),
            'deep': dict(target=46.0, max_gain=2.5, gamma=0.60, tnr='low', sharpen=0.07),
        }
        params = presets.get(mode, presets['balanced']).copy()
        if mode == 'custom':
            params.update({
                'target': float(cam.get('vision_target_median', 38.0)),
                'max_gain': float(cam.get('vision_max_gain', 2.2)),
                'gamma': float(cam.get('vision_gamma_min', 0.68)),
                'tnr': str(cam.get('vision_tnr', 'off')).lower(),
                'sharpen': float(cam.get('vision_sharpen', 0.05)),
            })
        override_tnr = str(cam.get('vision_tnr', 'auto')).lower()
        if override_tnr != 'auto':
            params['tnr'] = override_tnr
        return mode, params

    @staticmethod
    def _luminance(frame):
        if frame.ndim == 2:
            return frame
        f = frame.astype(np.float32)
        return (0.114 * f[:, :, 0] + 0.587 * f[:, :, 1] + 0.299 * f[:, :, 2]).astype(np.uint8)

    def _temporal_denoise(self, frame, gray, level):
        # TNR is optional and intentionally conservative. It is disabled in the
        # default Balanced profile to preserve the requested camera frame rate.
        if level not in {'low', 'medium', 'high'}:
            self._tnr_accumulator = None
            return frame
        if self._tnr_accumulator is None or self._tnr_accumulator.shape != frame.shape:
            self._tnr_accumulator = frame.astype(np.float32)
            return frame
        weight = {'low': 0.80, 'medium': 0.65, 'high': 0.50}[level]
        # Build the motion mask from a tiny image, then scale it back. This is
        # much cheaper than full-resolution temporal analysis.
        small_now = cv2.resize(gray, (160, 90), interpolation=cv2.INTER_AREA)
        previous = cv2.convertScaleAbs(self._tnr_accumulator)
        small_prev = cv2.resize(self._luminance(previous), (160, 90), interpolation=cv2.INTER_AREA)
        mask = cv2.threshold(cv2.absdiff(small_now, small_prev), 10, 255, cv2.THRESH_BINARY)[1]
        mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=1)
        mask = cv2.resize(mask, (frame.shape[1], frame.shape[0]), interpolation=cv2.INTER_NEAREST)
        cv2.accumulateWeighted(frame.astype(np.float32), self._tnr_accumulator, weight)
        filtered = cv2.convertScaleAbs(self._tnr_accumulator)
        filtered[mask > 0] = frame[mask > 0]
        return filtered

    def _enhance(self, frame):
        """VIGILIS Vision Engine 1.1 — lightweight night processing.

        No full-resolution histogram, percentile scan or CLAHE is performed.
        A 64x36 luminance sample supplies background, mean and bright-point
        statistics. A single scale and LUT are then applied to the frame.
        """
        mode, p = self._vision_settings()
        raw_gray = self._luminance(frame)
        sample = cv2.resize(raw_gray, (64, 36), interpolation=cv2.INTER_AREA)
        mean = float(sample.mean())
        median = float(np.median(sample))
        background = float(np.percentile(sample, 35))
        bright_points = int(np.count_nonzero(sample >= max(40, background + 18)))

        processed = self._temporal_denoise(frame, raw_gray, p['tnr'])
        scale = 1.0
        gamma = 1.0
        if mode != 'off':
            # Smooth global luminance gain; protects highlights and costs only
            # one optimized OpenCV operation per frame.
            scale = min(float(p['max_gain']), max(1.0, float(p['target']) / max(median, 1.0)))
            if scale > 1.01:
                processed = cv2.convertScaleAbs(processed, alpha=scale, beta=0)
            gamma = max(0.35, min(1.0, float(p['gamma'])))
            if gamma < 0.995:
                lut = np.array([((i / 255.0) ** gamma) * 255 for i in range(256)], dtype=np.uint8)
                processed = cv2.LUT(processed, lut)
            if p['sharpen'] > 0:
                blurred = cv2.GaussianBlur(processed, (0, 0), 0.8)
                processed = cv2.addWeighted(processed, 1.0 + p['sharpen'], blurred, -p['sharpen'], 0)

        self.status.update(
            vision_engine='Vision Engine 1.1',
            image_enhancement=mode,
            vision_gamma=round(gamma, 3),
            vision_mean=round(mean, 2),
            vision_median=round(median, 2),
            vision_background=round(background, 2),
            vision_bright_points=bright_points,
            vision_tnr=p['tnr'],
        )
        return processed

    def _run(self):
        window = deque(maxlen=60)
        while not self.stop_event.is_set():
            target_fps = max(1.0, float(self.config['camera'].get('fps', 10)))
            period = 1.0 / target_fps
            if not (self.picam or self.cap or self.zwo):
                if not self._open():
                    time.sleep(float(self.config['camera'].get('reconnect_seconds', 3)))
                    continue
            started = time.time()
            try:
                ok, frame = self._read()
            except Exception as exc:
                ok, frame = False, None
                self.status['last_error'] = str(exc)
            if not ok or frame is None:
                self.status.update(camera_ok=False, running=False)
                self.status['dropped'] += 1
                self._close()
                time.sleep(1)
                continue
            frame = self._transform(frame)
            frame = self._enhance(frame)
            with self.lock:
                self.frame = frame
                self.seq += 1
            now = time.time()
            window.append(now)
            fps = (len(window) - 1) / (window[-1] - window[0]) if len(window) > 1 and window[-1] > window[0] else 0
            self.status.update(
                running=True,
                camera_ok=True,
                fps=round(fps, 2),
                frames=self.status['frames'] + 1,
                last_frame_at=now,
                last_error='',
            )
            if self.picam is not None and self.status['frames'] % 10 == 0:
                try:
                    metadata = self.picam.capture_metadata()
                    if metadata:
                        self.status['exposure_us'] = metadata.get('ExposureTime', self.status.get('exposure_us'))
                        gain = metadata.get('AnalogueGain', self.status.get('analogue_gain'))
                        self.status['analogue_gain'] = round(float(gain), 2) if gain is not None else None
                        self.status['frame_duration_us'] = metadata.get('FrameDuration', self.status.get('frame_duration_us'))
                        lux = metadata.get('Lux')
                        self.status['lux'] = round(float(lux), 3) if lux is not None else None
                except Exception:
                    pass
            elif self.zwo is not None and self.status['frames'] % 10 == 0:
                try:
                    metadata = self.zwo.metadata()
                    self.status.update(metadata)
                    self.status['exposure_us'] = metadata.get('zwo_exposure_us_actual', self.status.get('exposure_us'))
                    self.status['analogue_gain'] = metadata.get('zwo_gain_actual', self.status.get('analogue_gain'))
                except Exception:
                    pass
            sleep = period - (time.time() - started)
            if sleep > 0:
                time.sleep(sleep)

    def get_frame(self, copy=True):
        with self.lock:
            return (None, self.seq) if self.frame is None else (self.frame.copy() if copy else self.frame, self.seq)

    def jpeg(self, height):
        frame, _ = self.get_frame()
        if frame is None:
            return None
        if height and frame.shape[0] != height:
            w = int(frame.shape[1] * (height / frame.shape[0]))
            frame = cv2.resize(frame, (w, height), interpolation=cv2.INTER_AREA)
        ok, b = cv2.imencode(
            '.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(self.config['camera'].get('jpeg_quality', 75))]
        )
        return b.tobytes() if ok else None
