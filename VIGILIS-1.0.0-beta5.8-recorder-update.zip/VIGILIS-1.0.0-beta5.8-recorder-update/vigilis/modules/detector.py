from __future__ import annotations

import datetime as dt
import gc
import json
import math
import os
import queue
import shutil
import subprocess
import threading
import time
from collections import deque
from pathlib import Path

import cv2
import numpy as np

from .classification import EventClassifier


class Detector:
    """Detection Engine 2.0.

    The engine is designed for low frame-rate meteor cameras. It combines:
    - single-frame flash/trail detection,
    - short fast-trail detection,
    - multi-frame tracking for slow objects such as satellites,
    while keeping recording memory bounded.
    """

    def __init__(self, config, camera, observation, root, logger, event_index=None):
        self.config = config
        self.camera = camera
        self.observation = observation
        self.root = Path(root)
        self.logger = logger
        self.event_index = event_index
        self.thread = None
        self.stop_event = threading.Event()
        self.mask = None
        self.background = None
        self.previous_gray = None
        self.tracks: list[dict] = []
        self.next_track_id = 1
        self._sun_active = False
        self._warmup_remaining = 0
        self._start_gate_ready = False
        self._start_gate_reason = ""
        self._reset_request = threading.Event()
        self.status = {
            'running': False,
            'mode': 'waiting',
            'engine': 'Detection Engine 2.1',
            'events_today': 0,
            'last_error': '',
            'last_score': 0,
            'last_event': None,
            'recording': False,
            'writer_open': False,
            'trigger_path': None,
            'objects': 0,
            'tracks': 0,
            'debug': {},
            'start_gate_ready': False,
            'start_gate_reason': 'initializing observation',
        }
        self._load_mask()

    def _load_mask(self):
        p = self.root / self.config.get('detection', {}).get('mask_file', 'data/detection_mask.png')
        self.mask = cv2.imread(str(p), cv2.IMREAD_GRAYSCALE) if p.exists() else None

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._run, daemon=True, name='detector')
        self.thread.start()

    def request_reset(self):
        """Clear pre-event frames and relearn the background before detection."""
        self._reset_request.set()

    def set_start_gate(self, ready: bool, reason: str = ''):
        ready = bool(ready)
        if ready and not self._start_gate_ready:
            self.request_reset()
        self._start_gate_ready = ready
        self._start_gate_reason = '' if ready else str(reason or 'preparing detector')
        self.status['start_gate_ready'] = ready
        self.status['start_gate_reason'] = self._start_gate_reason

    def _schedule_active(self):
        d = self.config.get('detection', {})
        mode = str(d.get('schedule_mode', 'always')).lower().replace('-', '_')
        if not d.get('enabled', True) or mode == 'disabled':
            return False, 'disabled'
        if mode == 'always':
            return True, 'detecting'
        if mode == 'custom':
            active = self.observation.time_window_active(d.get('custom_start', '20:00'), d.get('custom_stop', '06:00'))
            return active, 'detecting' if active else 'waiting for schedule'
        if mode in {'sun', 'sun_altitude'}:
            sun = self.observation.sun_altitude()
            if sun is None:
                return False, 'sun unavailable'
            start = float(d.get('start_sun_altitude', -6))
            stop = float(d.get('stop_sun_altitude', -4))
            if self._sun_active:
                if sun >= stop:
                    self._sun_active = False
            elif sun <= start:
                self._sun_active = True
            return self._sun_active, 'detecting' if self._sun_active else 'waiting for sunset'
        return True, 'detecting'

    def _params(self):
        d = self.config.get('detection', {})
        sensitivity = max(0, min(100, int(d.get('sensitivity', 70))))
        # Higher UI sensitivity means lower thresholds and smaller accepted targets.
        diff_threshold = int(round(34 - sensitivity * 0.24))  # 34 .. 10
        min_area = max(2, int(round(26 - sensitivity * 0.21)))
        single_flash_delta = max(18, int(round(72 - sensitivity * 0.46)))
        trail_min_length = max(5, int(round(28 - sensitivity * 0.20)))
        track_distance = int(d.get('track_distance_px', 70))
        return {
            'sensitivity': sensitivity,
            'diff_threshold': max(6, diff_threshold),
            'min_area': int(d.get('min_area_override', 0)) or min_area,
            'single_flash_delta': int(d.get('single_flash_delta', single_flash_delta)),
            'trail_min_length': int(d.get('trail_min_length_px', trail_min_length)),
            'track_distance': track_distance,
            'track_timeout_frames': max(1, int(d.get('track_timeout_frames', 5))),
            'slow_track_min_frames': max(2, int(d.get('slow_track_min_frames', 3))),
            'min_event_score': max(1, min(100, int(d.get('min_event_score', 55)))),
            'background_alpha': max(0.001, min(0.2, float(d.get('background_alpha', 0.02)))),
            'warmup_frames': max(3, int(d.get('warmup_frames', 20))),
            'max_global_motion_percent': max(1.0, min(90.0, float(d.get('max_global_motion_percent', 18.0)))),
            'max_blob_fraction': max(0.01, min(0.9, float(d.get('max_blob_fraction', 0.18)))),
            'brightness_compensation': bool(d.get('brightness_compensation', True)),
        }

    def _prepare(self, frame):
        gray = frame if frame.ndim == 2 else cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        rw = int(self.config.get('detection', {}).get('resize_width', 960))
        if rw and gray.shape[1] > rw:
            gray = cv2.resize(gray, (rw, int(gray.shape[0] * rw / gray.shape[1])), interpolation=cv2.INTER_AREA)
        gray = cv2.GaussianBlur(gray, (3, 3), 0)
        mask = None
        if self.mask is not None:
            mask = cv2.resize(self.mask, (gray.shape[1], gray.shape[0]), interpolation=cv2.INTER_NEAREST)
        ignore_bottom = max(0, min(80, int(self.config.get('detection', {}).get('ignore_bottom_percent', 0))))
        if ignore_bottom:
            if mask is None:
                mask = np.zeros_like(gray, dtype=np.uint8)
            start = int(gray.shape[0] * (100 - ignore_bottom) / 100)
            mask[start:, :] = 255
        return gray, mask

    @staticmethod
    def _line_metrics(contour):
        x, y, w, h = cv2.boundingRect(contour)
        length = max(w, h)
        width = max(1, min(w, h))
        elongation = length / width
        return x, y, w, h, length, elongation

    def _update_tracks(self, detections, params):
        for track in self.tracks:
            track['matched'] = False
            track['age'] += 1

        for det in detections:
            cx, cy = det['centroid']
            best = None
            best_dist = float('inf')
            for track in self.tracks:
                tx, ty = track['centroid']
                dist = math.hypot(cx - tx, cy - ty)
                if dist < best_dist and dist <= params['track_distance']:
                    best, best_dist = track, dist
            if best is None:
                best = {
                    'id': self.next_track_id,
                    'centroid': (cx, cy),
                    'first': (cx, cy),
                    'frames': 0,
                    'distance': 0.0,
                    'max_brightness': 0,
                    'max_length': 0,
                    'age': 0,
                    'matched': True,
                }
                self.next_track_id += 1
                self.tracks.append(best)
            else:
                best['distance'] += best_dist
                best['centroid'] = (cx, cy)
                best['age'] = 0
                best['matched'] = True
            best['frames'] += 1
            best['max_brightness'] = max(best['max_brightness'], det['brightness'])
            best['max_length'] = max(best['max_length'], det['length'])
            det['track'] = best

        self.tracks = [t for t in self.tracks if t['age'] <= params['track_timeout_frames']]

    def _analyse(self, frame):
        params = self._params()
        gray, exclusion_mask = self._prepare(frame)

        if self.background is None or self.background.shape != gray.shape:
            self.background = gray.astype(np.float32)
            self.previous_gray = gray.copy()
            self._warmup_remaining = params['warmup_frames']
            return 0, None, {
                'state': 'warming_up', 'warmup_remaining': self._warmup_remaining,
                'objects': 0, 'tracks': 0, 'threshold': params['diff_threshold'],
                'motion_percent': 0.0, 'largest_blob_area': 0.0, 'reason': 'background initialized'
            }

        background_u8 = cv2.convertScaleAbs(self.background)

        # Vision processing and automatic exposure can change the brightness of
        # the entire frame. Compensate a global level shift before calculating
        # motion so that a gamma/exposure step is not interpreted as an event.
        analysis_gray = gray
        brightness_shift = 0.0
        if params['brightness_compensation']:
            sample_gray = gray[::8, ::8]
            sample_bg = background_u8[::8, ::8]
            brightness_shift = float(np.median(sample_bg)) - float(np.median(sample_gray))
            if abs(brightness_shift) >= 1.0:
                analysis_gray = np.clip(gray.astype(np.int16) + int(round(brightness_shift)), 0, 255).astype(np.uint8)

        bg_diff = cv2.absdiff(analysis_gray, background_u8)
        frame_diff = cv2.absdiff(analysis_gray, self.previous_gray) if self.previous_gray is not None else bg_diff
        self.previous_gray = analysis_gray.copy()

        if self._warmup_remaining > 0:
            cv2.accumulateWeighted(analysis_gray, self.background, max(0.12, params['background_alpha']))
            self._warmup_remaining -= 1
            return 0, None, {
                'state': 'warming_up', 'warmup_remaining': self._warmup_remaining,
                'objects': 0, 'tracks': len(self.tracks), 'threshold': params['diff_threshold'],
                'motion_percent': 0.0, 'largest_blob_area': 0.0,
                'brightness_shift': round(brightness_shift, 2), 'reason': 'learning background'
            }

        cv2.accumulateWeighted(analysis_gray, self.background, params['background_alpha'])

        # A target can be evident against the background even when it moves only
        # a few pixels between two low-FPS frames. Use the stronger difference.
        diff = cv2.max(bg_diff, frame_diff)
        if exclusion_mask is not None:
            diff[exclusion_mask > 127] = 0

        _, binary = cv2.threshold(diff, params['diff_threshold'], 255, cv2.THRESH_BINARY)
        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
        binary = cv2.dilate(binary, np.ones((2, 2), np.uint8), iterations=1)

        motion_percent = float(cv2.countNonZero(binary)) * 100.0 / float(binary.size)
        # A large part of the image changing at once is normally exposure/gamma,
        # clouds, vibration or a camera transition—not a local astronomical event.
        if motion_percent > params['max_global_motion_percent']:
            cv2.accumulateWeighted(analysis_gray, self.background, 0.35)
            self.tracks.clear()
            return 0, None, {
                'state': 'global_change_rejected', 'objects': 0, 'tracks': 0,
                'threshold': params['diff_threshold'], 'motion_percent': round(motion_percent, 3),
                'largest_blob_area': 0.0, 'brightness_shift': round(brightness_shift, 2),
                'reason': 'global image change'
            }

        contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        detections = []
        best_single = 0
        best_trail = 0
        largest_blob_area = 0.0
        frame_area = float(gray.shape[0] * gray.shape[1])
        for contour in contours:
            area = float(cv2.contourArea(contour))
            largest_blob_area = max(largest_blob_area, area)
            if area < params['min_area'] or area > frame_area * params['max_blob_fraction']:
                continue
            x, y, w, h, length, elongation = self._line_metrics(contour)
            roi_diff = diff[y:y+h, x:x+w]
            roi_gray = gray[y:y+h, x:x+w]
            brightness = int(roi_gray.max()) if roi_gray.size else 0
            delta = int(roi_diff.max()) if roi_diff.size else 0
            moments = cv2.moments(contour)
            if moments['m00']:
                centroid = (moments['m10'] / moments['m00'], moments['m01'] / moments['m00'])
            else:
                centroid = (x + w / 2, y + h / 2)

            detection = {
                'area': area,
                'length': length,
                'elongation': elongation,
                'brightness': brightness,
                'delta': delta,
                'centroid': centroid,
                'bbox': (x, y, w, h),
            }
            detections.append(detection)

            # Single-frame events are crucial at 5 FPS. Brightness change,
            # shape and area all contribute, but no second frame is required.
            flash_score = min(100, int(delta * 0.8 + math.sqrt(area) * 3.0))
            if delta >= params['single_flash_delta']:
                best_single = max(best_single, flash_score)

            if length >= params['trail_min_length'] and elongation >= 2.0:
                trail_score = min(100, int(length * 1.6 + elongation * 4 + delta * 0.25))
                best_trail = max(best_trail, trail_score)

        self._update_tracks(detections, params)
        best_track = 0
        for detection in detections:
            track = detection.get('track')
            if not track or track['frames'] < params['slow_track_min_frames']:
                continue
            displacement = math.hypot(track['centroid'][0] - track['first'][0], track['centroid'][1] - track['first'][1])
            if displacement < 2:
                continue
            track_score = min(100, int(track['frames'] * 9 + displacement * 1.8 + track['max_brightness'] * 0.12))
            best_track = max(best_track, track_score)

        candidates = [('single_frame', best_single), ('fast_trail', best_trail), ('tracked_object', best_track)]
        trigger_path, score = max(candidates, key=lambda item: item[1])
        if score <= 0:
            trigger_path = None

        reason = 'below event score' if score < params['min_event_score'] else f'candidate: {trigger_path}'
        boxes = []
        gh, gw = gray.shape[:2]
        for detection in detections:
            x, y, w, h = detection['bbox']
            boxes.append({
                'x': round(x / gw, 6), 'y': round(y / gh, 6),
                'w': round(w / gw, 6), 'h': round(h / gh, 6),
                'brightness': int(detection['brightness']),
                'delta': int(detection['delta']),
            })
        debug = {
            'state': 'analysing',
            'objects': len(detections),
            'tracks': len(self.tracks),
            'threshold': params['diff_threshold'],
            'single_frame_score': best_single,
            'fast_trail_score': best_trail,
            'tracked_object_score': best_track,
            'trigger_path': trigger_path,
            'motion_percent': round(motion_percent, 3),
            'largest_blob_area': round(largest_blob_area, 1),
            'brightness_shift': round(brightness_shift, 2),
            'minimum_event_score': params['min_event_score'],
            'reason': reason,
            'boxes': boxes,
        }
        return score, trigger_path, debug

    def _event_paths(self, when):
        day = when.strftime('%Y-%m-%d')
        raw = str(self.config.get('storage', {}).get('recordings_path', '') or '').strip()
        base = Path(raw).expanduser() if raw else self.root / 'recordings'
        if not base.is_absolute():
            base = self.root / base
        base = base.resolve()
        if str(base).startswith(('/media/', '/mnt/')):
            mounted = any(
                os.path.ismount(parent) and (str(parent) in {'/media','/mnt'} or str(parent).startswith(('/media/','/mnt/')))
                for parent in (base, *base.parents)
            )
            if not mounted:
                base = (self.root / 'recordings').resolve()
        folder = base / day / 'unknown'
        folder.mkdir(parents=True, exist_ok=True)
        sequence = self.event_index.allocate_sequence(day) if self.event_index else 1
        event_id = f"event_{when.strftime('%Y%m%d_%H%M%S')}_{sequence:03d}"
        return event_id, sequence, base, folder, folder / f'{event_id}.mp4', folder / f'{event_id}.jpg', folder / f'{event_id}.json'

    def _recording_worker(self, event, initial_frames):
        """Write buffered and live frames without blocking detection.

        The detector thread only enqueues frames. Opening the codec, writing the
        two-second prebuffer and all following disk I/O happen here, so the
        transition from pre-event footage to live footage remains continuous.
        """
        writer = None
        try:
            first_frame = initial_frames[-1][2]
            h, w = first_frame.shape[:2]
            is_color = first_frame.ndim == 3
            writer = cv2.VideoWriter(
                str(event['video']),
                cv2.VideoWriter_fourcc(*self.config['recording'].get('codec', 'mp4v')),
                float(event['fps']),
                (w, h),
                isColor=is_color,
            )
            if not writer.isOpened():
                raise RuntimeError('VideoWriter could not open output file')
            event['writer_opened'].set()

            previous_seq = None
            for seq, captured_at, frame in initial_frames:
                if previous_seq is not None and seq > previous_seq + 1:
                    event['source_dropped_frames'] += seq - previous_seq - 1
                writer.write(frame)
                event['written_frames'] += 1
                previous_seq = seq

            while True:
                packet = event['frame_queue'].get()
                if packet is None:
                    break
                seq, captured_at, frame = packet
                if previous_seq is not None and seq > previous_seq + 1:
                    event['source_dropped_frames'] += seq - previous_seq - 1
                writer.write(frame)
                event['written_frames'] += 1
                previous_seq = seq
        except Exception as exc:
            event['writer_error'] = str(exc)
            self.logger.exception('Asynchronous event writer failed')
        finally:
            if writer is not None:
                writer.release()
            event['writer_finished'].set()

    def _open_writer(self, first_frame, fps, score, pre_frames, trigger_path):
        now = dt.datetime.now()
        event_id, sequence, recordings_root, folder, video, thumb, meta = self._event_paths(now)
        queue_seconds = max(5, int(self.config.get('recording', {}).get('writer_queue_seconds', 15)))
        event = {
            'writer': None,
            'id': event_id,
            'daily_sequence': sequence,
            'recordings_root': recordings_root,
            'created_at': now,
            'video': video,
            'thumb': thumb,
            'meta': meta,
            'score': score,
            'trigger_path': trigger_path,
            'frames': len(pre_frames),
            'prebuffer_frames': len(pre_frames),
            'fps': float(fps),
            'detections': [],
            'frame_queue': queue.Queue(maxsize=max(30, int(float(fps) * queue_seconds))),
            'writer_opened': threading.Event(),
            'writer_finished': threading.Event(),
            'writer_error': '',
            'written_frames': 0,
            'queue_dropped_frames': 0,
            'source_dropped_frames': 0,
        }
        # The thumbnail uses the actual trigger frame, not the last pre-event frame.
        cv2.imwrite(str(thumb), first_frame)
        event['writer_thread'] = threading.Thread(
            target=self._recording_worker,
            args=(event, pre_frames),
            daemon=True,
            name=f"event-writer-{sequence:03d}",
        )
        event['writer_thread'].start()
        return event

    def _enqueue_recording_frame(self, event, seq, captured_at, frame):
        try:
            event['frame_queue'].put_nowait((seq, captured_at, frame))
            return True
        except queue.Full:
            event['queue_dropped_frames'] += 1
            self.logger.warning('Recording queue full for %s; dropping frame %s', event.get('id'), seq)
            return False

    def _close_recording_worker(self, event):
        if not event['writer_finished'].is_set():
            # A full queue should be allowed to drain rather than losing the final
            # frames. The detector is no longer feeding this event at this point.
            event['frame_queue'].put(None)
            timeout = max(30.0, float(event.get('frames', 0)) / max(1.0, float(event.get('fps', 1))) * 2.0)
            event['writer_thread'].join(timeout=timeout)
            if event['writer_thread'].is_alive():
                raise RuntimeError('Event writer did not finish before timeout')
        if event.get('writer_error'):
            raise RuntimeError(event['writer_error'])


    def _apply_faststart(self, video_path: Path):
        """Move MP4 metadata to the beginning for immediate browser playback.

        The remux copies the encoded video stream without re-encoding. A failure
        leaves the original recording untouched.
        """
        if not self.config.get('recording', {}).get('faststart', True):
            return
        video_path = Path(video_path)
        temp = video_path.with_name(f'{video_path.stem}.faststart.tmp.mp4')
        try:
            result = subprocess.run(
                ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', str(video_path),
                 '-map', '0', '-c', 'copy', '-movflags', '+faststart', str(temp)],
                capture_output=True, text=True, timeout=120,
            )
            if result.returncode == 0 and temp.exists() and temp.stat().st_size > 0:
                temp.replace(video_path)
            else:
                temp.unlink(missing_ok=True)
                self.logger.warning('MP4 faststart skipped for %s: %s', video_path, (result.stderr or '').strip())
        except Exception as exc:
            temp.unlink(missing_ok=True)
            self.logger.warning('MP4 faststart failed for %s: %s', video_path, exc)

    def _finish_event(self, event):
        self._close_recording_worker(event)
        self._apply_faststart(event['video'])
        now = event['created_at']
        detections = event.get('detections', [])
        if detections and event['thumb'].exists():
            image = cv2.imread(str(event['thumb']), cv2.IMREAD_COLOR)
            if image is not None:
                first = detections[0]
                box = first.get('box', {})
                ih, iw = image.shape[:2]
                x1 = int(box.get('x', 0) * iw); y1 = int(box.get('y', 0) * ih)
                x2 = int((box.get('x', 0) + box.get('w', 0)) * iw)
                y2 = int((box.get('y', 0) + box.get('h', 0)) * ih)
                cv2.rectangle(image, (x1, y1), (x2, y2), (60, 230, 90), 2)
                cv2.imwrite(str(event['thumb']), image)
        classifier_cfg = self.config.get('classification', {})
        classification = {'classification': 'unknown', 'aircraft_score': 0.0, 'meteor_score': 0.0, 'features': {}, 'reason': 'classification disabled'}
        if classifier_cfg.get('enabled', True):
            classification = EventClassifier.classify(
                detections, event.get('fps', 0), event.get('frames', 0), event.get('trigger_path'),
                aircraft_threshold=int(classifier_cfg.get('aircraft_threshold', 70)),
                meteor_threshold=int(classifier_cfg.get('meteor_threshold', 78)),
            )
        data = {
            'id': event['id'],
            'created_at': now.isoformat(),
            'daily_sequence': int(event.get('daily_sequence', 0)),
            'classification': classification['classification'],
            'classification_engine': 'VIGILIS Classification Engine 1.0',
            'classification_reason': classification.get('reason'),
            'aircraft_score': classification.get('aircraft_score', 0),
            'meteor_score': classification.get('meteor_score', 0),
            'classification_features': classification.get('features', {}),
            'favorite': False,
            'storage_location': 'sd' if event.get('recordings_root', self.root / 'recordings').resolve() == (self.root / 'recordings').resolve() else 'ssd',
            'score': int(event['score']),
            'trigger_path': event.get('trigger_path'),
            'fps': round(float(event.get('fps', 0)), 3),
            'frames': int(event.get('frames', 0)),
            'recording_health': {
                'prebuffer_frames': int(event.get('prebuffer_frames', 0)),
                'expected_frames': int(event.get('frames', 0)),
                'written_frames': int(event.get('written_frames', 0)),
                'source_dropped_frames': int(event.get('source_dropped_frames', 0)),
                'queue_dropped_frames': int(event.get('queue_dropped_frames', 0)),
            },
            'duration_seconds': round(int(event.get('frames', 0)) / max(0.1, float(event.get('fps', 1))), 3),
            'detections': detections,
            'video': 'storage:' + str(event['video'].relative_to(event['recordings_root'])),
            'thumbnail': 'storage:' + str(event['thumb'].relative_to(event['recordings_root'])),
        }
        event['meta'].write_text(json.dumps(data, indent=2), encoding='utf-8')
        final_meta = event['meta']

        # Sort completed events into physical classification folders only after
        # the writer is closed, then add the final paths to the local event DB.
        if classifier_cfg.get('sort_into_folders', True):
            category = str(data.get('classification') or 'unknown').lower()
            if category not in {'meteor', 'aircraft', 'satellite', 'insect', 'false_positive', 'unknown'}:
                category = 'unknown'
            target = event['video'].parent.parent / category
            target.mkdir(parents=True, exist_ok=True)
            moved = {}
            for key, source in (('video', event['video']), ('thumbnail', event['thumb'])):
                destination = target / source.name
                if source.exists() and source.resolve() != destination.resolve():
                    shutil.move(str(source), str(destination))
                moved[key] = destination
            meta_destination = target / event['meta'].name
            data['video'] = 'storage:' + str(moved['video'].relative_to(event['recordings_root']))
            data['thumbnail'] = 'storage:' + str(moved['thumbnail'].relative_to(event['recordings_root']))
            meta_destination.write_text(json.dumps(data, indent=2), encoding='utf-8')
            if event['meta'].exists() and event['meta'].resolve() != meta_destination.resolve():
                event['meta'].unlink()
            try:
                event['video'].parent.rmdir()
            except OSError:
                pass
            final_meta = meta_destination
        if self.event_index:
            self.event_index.upsert(data, final_meta, event['recordings_root'])
        return data

    def _reset_analysis(self):
        self.background = None
        self.previous_gray = None
        self.tracks.clear()
        self._warmup_remaining = 0

    def _run(self):
        fps = max(1, int(self.config['camera'].get('fps', 15)))
        # VIGILIS keeps a fixed two-second raw-frame prebuffer. Avoiding JPEG
        # encode/decode work removes the most likely hitch at the trigger boundary.
        pre_seconds = 2.0
        pre = deque(maxlen=max(1, int(fps * pre_seconds)))
        recording = None
        last_trigger = 0.0
        quiet = 0
        last_seq = -1

        while not self.stop_event.is_set():
            active, label = self._schedule_active()
            if active and not self._start_gate_ready:
                active = False
                label = self._start_gate_reason or 'preparing detector'
            if self._reset_request.is_set() and not recording:
                self._reset_analysis()
                pre.clear()
                last_seq = -1
                self._reset_request.clear()
            if not active:
                if recording:
                    try:
                        self.status['last_event'] = self._finish_event(recording)
                        self.status['events_today'] += 1
                    except Exception:
                        self.logger.exception('Event finalization failed')
                    recording = None
                    gc.collect()
                self.status.update(running=False, mode=label, recording=False, writer_open=False)
                self._reset_analysis()
                pre.clear()
                time.sleep(0.5)
                continue

            frame, seq = self.camera.get_frame()
            if frame is None or seq == last_seq:
                time.sleep(0.01)
                continue

            if not recording:
                measured = float(self.camera.status.get('fps') or self.config['camera'].get('fps', 15))
                new_fps = max(1, int(round(measured)))
                if new_fps != fps:
                    fps = new_fps
                    pre = deque(pre, maxlen=max(1, int(fps * pre_seconds)))

            last_seq = seq
            self.status.update(running=True, mode='recording' if recording else label, recording=bool(recording), writer_open=bool(recording))
            score, trigger_path, debug = self._analyse(frame)
            self.status.update(last_score=score, trigger_path=trigger_path, objects=debug['objects'], tracks=debug['tracks'], debug=debug)

            captured_at = time.monotonic()
            if not recording:
                # get_frame() already returns an owned copy, so this raw frame can
                # safely stay in the two-second ring buffer without JPEG overhead.
                pre.append((seq, captured_at, frame))

            threshold = self._params()['min_event_score']
            now = time.time()
            if not recording and score >= threshold and now - last_trigger >= float(self.config['detection'].get('cooldown_seconds', 3)):
                try:
                    last_trigger = now
                    recording = self._open_writer(frame, fps, score, list(pre), trigger_path)
                    for box in debug.get('boxes', []):
                        recording['detections'].append({'time': round(recording['frames'] / max(1, fps), 3), 'box': box, 'score': int(score), 'trigger': trigger_path})
                    pre.clear()
                    quiet = 0
                    self.logger.info('Event started: path=%s score=%s', trigger_path, score)
                except Exception as exc:
                    self.status['last_error'] = str(exc)
                    self.logger.exception('Event writer start failed')
                    recording = None
            elif recording:
                self._enqueue_recording_frame(recording, seq, captured_at, frame)
                recording['frames'] += 1
                recording['score'] = max(recording['score'], score)
                for box in debug.get('boxes', []):
                    recording['detections'].append({'time': round(recording['frames'] / max(1, fps), 3), 'box': box, 'score': int(score), 'trigger': trigger_path})
                quiet = 0 if score >= max(20, threshold // 2) else quiet + 1
                mode = self.config['recording'].get('mode', 'event')
                fixed = int(self.config['recording'].get('fixed_seconds', 10)) * fps
                end_quiet = int(self.config['recording'].get('event_end_seconds', 2)) * fps
                maximum = int(self.config['recording'].get('max_event_seconds', 300)) * fps
                finished = (mode == 'fixed' and recording['frames'] >= fixed) or (mode == 'event' and quiet >= end_quiet) or recording['frames'] >= maximum
                if finished:
                    try:
                        event_data = self._finish_event(recording)
                        self.status['last_event'] = event_data
                        self.status['events_today'] += 1
                    except Exception as exc:
                        self.status['last_error'] = str(exc)
                        self.logger.exception('Event finalization failed')
                        try:
                            self._close_recording_worker(recording)
                        except Exception:
                            pass
                    recording = None
                    quiet = 0
                    self.status.update(recording=False, writer_open=False)
                    # Re-learn the current sky after every event. Otherwise the
                    # event itself can remain in the background model and cause
                    # an immediate retrigger loop.
                    self._reset_analysis()
                    pre.clear()
                    gc.collect()
