from __future__ import annotations
from pathlib import Path
import datetime as dt
import json
import threading
import time


class SensorReader:
    """Read one or two DHT22 sensors and keep a daily climate history."""
    def __init__(self, config, logger):
        self.config=config; self.logger=logger; self.stop_event=threading.Event(); self.thread=None
        self.latest={
            'ok':False,'status':'initializing','temperature_c':None,'humidity':None,
            'dome':self._empty('initializing'),'outdoor':self._empty('disabled'),
            'error':'not started','updated_at':None,'last_valid_at':None,'consecutive_failures':0,
        }
        self.history_root=Path(__file__).resolve().parents[2]/'data'/'environment_history'
        self.history_root.mkdir(parents=True,exist_ok=True)
        self._last_history=0.0

    @staticmethod
    def _empty(status='initializing'):
        return {'ok':False,'status':status,'temperature_c':None,'humidity':None,'error':'','updated_at':None,'last_valid_at':None,'consecutive_failures':0}

    def start(self):
        if self.thread and self.thread.is_alive(): return
        self.thread=threading.Thread(target=self._run,daemon=True,name='dht22-sensors'); self.thread.start()

    def _open_sensor(self, enabled, pin_no, name):
        if not enabled: return None
        try:
            import board, adafruit_dht
            pin=getattr(board,f'D{int(pin_no)}')
            return adafruit_dht.DHT22(pin,use_pulseio=False)
        except Exception as exc:
            self.logger.warning('%s DHT22 unavailable: %s',name,exc)
            return None

    def _read_one(self, device, previous, name, warning_after, fault_after, stale_after):
        now=time.time()
        if device is None:
            state=dict(previous); state.update(ok=False,status='disabled',updated_at=now)
            return state
        try:
            t=device.temperature; h=device.humidity
            if t is None or h is None or not (-50 <= float(t) <= 100) or not (0 <= float(h) <= 100):
                raise RuntimeError('invalid sensor value')
            return {'ok':True,'status':'ok','temperature_c':round(float(t),1),'humidity':round(float(h),1),'error':'','updated_at':now,'last_valid_at':now,'consecutive_failures':0}
        except Exception as exc:
            failures=int(previous.get('consecutive_failures',0))+1
            last_valid=previous.get('last_valid_at'); age=(now-last_valid) if last_valid else None
            if failures >= fault_after or (age is not None and age > stale_after): status='fault'; ok=False
            elif failures >= warning_after: status='warning'; ok=True
            else: status='ok'; ok=True
            state=dict(previous); state.update(ok=ok,status=status,error=str(exc),updated_at=now,consecutive_failures=failures)
            if failures in {warning_after,fault_after}: self.logger.warning('%s DHT22 read failure (%d): %s',name,failures,exc)
            return state

    def _write_history(self, now):
        interval=max(30,float(self.config.get('sensor',{}).get('history_interval_seconds',60)))
        if now-self._last_history < interval: return
        self._last_history=now
        record={'timestamp':now,'iso':dt.datetime.fromtimestamp(now).isoformat(timespec='seconds'),'dome':self.latest.get('dome',{}),'outdoor':self.latest.get('outdoor',{})}
        path=self.history_root/f'{dt.date.today().isoformat()}.jsonl'
        with path.open('a',encoding='utf-8') as f: f.write(json.dumps(record,separators=(',',':'))+'\n')

    def history(self, day):
        path=self.history_root/f'{day}.jsonl'; out=[]
        if not path.exists(): return out
        for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
            try: out.append(json.loads(line))
            except Exception: pass
        return out

    def available_days(self):
        return sorted((p.stem for p in self.history_root.glob('*.jsonl')),reverse=True)

    def history_range(self, start, end, max_points=1800):
        """Load an inclusive local-date range and aggregate it for chart display.

        Statistics are calculated from all valid raw samples, while the returned
        chart samples are averaged into time buckets when the selected range is
        large. This keeps one-year charts responsive on Raspberry Pi.
        """
        if isinstance(start, str): start=dt.date.fromisoformat(start)
        if isinstance(end, str): end=dt.date.fromisoformat(end)
        if end < start: start,end=end,start
        raw=[]; day=start
        while day <= end:
            raw.extend(self.history(day.isoformat()))
            day += dt.timedelta(days=1)
        raw.sort(key=lambda item: float(item.get('timestamp',0) or 0))
        stats={}; fields=('temperature_c','humidity')
        for key in ('dome','outdoor'):
            stats[key]={}
            for field in fields:
                values=[]
                for item in raw:
                    value=(item.get(key) or {}).get(field)
                    if isinstance(value,(int,float)): values.append(float(value))
                stats[key][field]={
                    'min':round(min(values),2) if values else None,
                    'avg':round(sum(values)/len(values),2) if values else None,
                    'max':round(max(values),2) if values else None,
                    'count':len(values),
                }
        if not raw or len(raw) <= max_points:
            return raw,stats,len(raw)
        first=float(raw[0].get('timestamp',0) or 0); last=float(raw[-1].get('timestamp',first) or first)
        span=max(1.0,last-first); bucket_seconds=max(60.0,span/max_points)
        buckets={}
        for item in raw:
            timestamp=float(item.get('timestamp',0) or 0)
            bucket=int((timestamp-first)//bucket_seconds)
            acc=buckets.setdefault(bucket,{'timestamp_sum':0.0,'timestamp_count':0,'values':{}})
            acc['timestamp_sum']+=timestamp; acc['timestamp_count']+=1
            for key in ('dome','outdoor'):
                for field in fields:
                    value=(item.get(key) or {}).get(field)
                    if isinstance(value,(int,float)):
                        slot=acc['values'].setdefault((key,field),[0.0,0])
                        slot[0]+=float(value); slot[1]+=1
        samples=[]
        for bucket in sorted(buckets):
            acc=buckets[bucket]; timestamp=acc['timestamp_sum']/max(1,acc['timestamp_count'])
            record={'timestamp':timestamp,'iso':dt.datetime.fromtimestamp(timestamp).isoformat(timespec='seconds'),'dome':{},'outdoor':{}}
            for (key,field),(total,count) in acc['values'].items(): record[key][field]=round(total/count,2)
            samples.append(record)
        return samples,stats,len(raw)

    def _run(self):
        scfg=self.config.get('sensor',{}); gcfg=self.config.get('gpio',{})
        dome=self._open_sensor(bool(scfg.get('dht22_enabled',True)),gcfg.get('dht_pin',4),'Dome')
        outdoor=self._open_sensor(bool(scfg.get('outdoor_dht22_enabled',False)),gcfg.get('outdoor_dht_pin',18),'Outdoor')
        interval=max(3.0,float(scfg.get('read_interval_seconds',10)))
        warning_after=max(1,int(scfg.get('warning_after_failures',2))); fault_after=max(warning_after+1,int(scfg.get('fault_after_failures',5)))
        stale_after=max(interval*2,float(scfg.get('stale_after_seconds',60)))
        while not self.stop_event.is_set():
            self.latest['dome']=self._read_one(dome,self.latest.get('dome',self._empty()),'Dome',warning_after,fault_after,stale_after)
            # DHT22 sensors need some quiet time between reads.
            if outdoor is not None: time.sleep(2.1)
            self.latest['outdoor']=self._read_one(outdoor,self.latest.get('outdoor',self._empty('disabled')),'Outdoor',warning_after,fault_after,stale_after)
            d=self.latest['dome']; self.latest.update({
                'ok':d.get('ok',False),'status':d.get('status','fault'),'temperature_c':d.get('temperature_c'),'humidity':d.get('humidity'),
                'error':d.get('error',''),'updated_at':d.get('updated_at'),'last_valid_at':d.get('last_valid_at'),'consecutive_failures':d.get('consecutive_failures',0),
            })
            self._write_history(time.time())
            self.stop_event.wait(interval)
