from __future__ import annotations

"""Fast local event catalogue for VIGILIS.

The recordings themselves remain on the selected recording medium.  Only the
small searchable catalogue is stored in ``data/events.db`` on the Raspberry
Pi's system storage.  This prevents the web UI from recursively scanning an
NTFS/FUSE SSD for every dashboard refresh, thumbnail and video range request.
"""

import datetime as dt
import json
import sqlite3
import threading
from pathlib import Path
from typing import Iterable




class EventIndex:
    def __init__(self, root: Path, config: dict, logger=None):
        self.root = Path(root).resolve()
        self.config = config
        self.logger = logger
        self.db_path = self.root / "data" / "events.db"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._index_lock = threading.Lock()
        self._index_thread: threading.Thread | None = None
        self._status = {
            "running": False,
            "processed": 0,
            "total": 0,
            "error": "",
            "root": "",
            "started_at": None,
            "finished_at": None,
        }
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.db_path, timeout=30, check_same_thread=False)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        con.execute("PRAGMA foreign_keys=ON")
        return con

    def _init_schema(self) -> None:
        with self._connect() as con:
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS events (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    day TEXT NOT NULL,
                    sequence INTEGER NOT NULL DEFAULT 0,
                    classification TEXT NOT NULL DEFAULT 'unknown',
                    favorite INTEGER NOT NULL DEFAULT 0,
                    score INTEGER NOT NULL DEFAULT 0,
                    duration_seconds REAL NOT NULL DEFAULT 0,
                    aircraft_score REAL NOT NULL DEFAULT 0,
                    meteor_score REAL NOT NULL DEFAULT 0,
                    metadata_path TEXT NOT NULL,
                    video_path TEXT,
                    thumbnail_path TEXT,
                    overlay_path TEXT,
                    storage_root TEXT NOT NULL,
                    storage_location TEXT NOT NULL DEFAULT 'sd',
                    data_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_events_day_created
                    ON events(day, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_events_day_class_created
                    ON events(day, classification, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_events_favorite_created
                    ON events(favorite, created_at DESC);

                CREATE TABLE IF NOT EXISTS daily_sequences (
                    day TEXT PRIMARY KEY,
                    last_sequence INTEGER NOT NULL
                );

                CREATE TABLE IF NOT EXISTS index_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                """
            )

    @staticmethod
    def event_day(data: dict, path: Path | None = None) -> str:
        created = str(data.get("created_at", ""))
        if len(created) >= 10:
            return created[:10]
        if path is not None:
            for part in Path(path).parts:
                try:
                    dt.date.fromisoformat(part)
                    return part
                except (TypeError, ValueError):
                    continue
        event_id = str(data.get("id", ""))
        if event_id.startswith("event_") and len(event_id) >= 14:
            raw = event_id[6:14]
            return f"{raw[:4]}-{raw[4:6]}-{raw[6:8]}"
        return "unknown"

    @staticmethod
    def _sequence_from_data(data: dict) -> int:
        # Beta 5.1 IDs ended in milliseconds (for example ``_650``). They
        # deliberately must not be interpreted as the new daily sequence. New
        # Beta 5.2 events store ``daily_sequence`` explicitly in their JSON.
        try:
            sequence = int(data.get("daily_sequence", 0) or 0)
            return sequence if sequence > 0 else 0
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _resolve_value(value, metadata_path: Path, recordings_root: Path) -> Path | None:
        if not value:
            return None
        raw = str(value)
        if raw.startswith("storage:"):
            return (recordings_root / raw[8:]).resolve()
        path = Path(raw).expanduser()
        if path.is_absolute():
            return path.resolve()
        local = (metadata_path.parent / path.name).resolve()
        if local.exists():
            return local
        return (recordings_root / path).resolve()

    def _storage_location(self, recordings_root: Path) -> str:
        internal = (self.root / "recordings").resolve()
        try:
            recordings_root.resolve().relative_to(internal)
            return "sd"
        except ValueError:
            return "ssd"

    def upsert(self, data: dict, metadata_path: Path, recordings_root: Path) -> dict:
        metadata_path = Path(metadata_path).resolve()
        recordings_root = Path(recordings_root).resolve()
        item = dict(data)
        event_id = str(item.get("id") or metadata_path.stem)
        item["id"] = event_id
        day = self.event_day(item, metadata_path)
        sequence = self._sequence_from_data(item)
        item.setdefault("day", day)
        if sequence:
            item["daily_sequence"] = sequence

        video = self._resolve_value(item.get("video"), metadata_path, recordings_root)
        thumb = self._resolve_value(item.get("thumbnail"), metadata_path, recordings_root)
        overlay = self._resolve_value(item.get("overlay_video"), metadata_path, recordings_root)
        storage_location = str(item.get("storage_location") or self._storage_location(recordings_root))
        item["storage_location"] = storage_location

        created_at = str(item.get("created_at") or dt.datetime.fromtimestamp(metadata_path.stat().st_mtime).isoformat())
        classification = str(item.get("classification") or "unknown").lower()
        favorite = bool(item.get("favorite") or "favorites" in metadata_path.parts)
        item["favorite"] = favorite
        item["classification"] = classification

        with self._connect() as con:
            con.execute(
                """
                INSERT INTO events (
                    id, created_at, day, sequence, classification, favorite,
                    score, duration_seconds, aircraft_score, meteor_score,
                    metadata_path, video_path, thumbnail_path, overlay_path,
                    storage_root, storage_location, data_json, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    created_at=excluded.created_at,
                    day=excluded.day,
                    sequence=excluded.sequence,
                    classification=excluded.classification,
                    favorite=excluded.favorite,
                    score=excluded.score,
                    duration_seconds=excluded.duration_seconds,
                    aircraft_score=excluded.aircraft_score,
                    meteor_score=excluded.meteor_score,
                    metadata_path=excluded.metadata_path,
                    video_path=excluded.video_path,
                    thumbnail_path=excluded.thumbnail_path,
                    overlay_path=excluded.overlay_path,
                    storage_root=excluded.storage_root,
                    storage_location=excluded.storage_location,
                    data_json=excluded.data_json,
                    updated_at=excluded.updated_at
                """,
                (
                    event_id,
                    created_at,
                    day,
                    sequence,
                    classification,
                    1 if favorite else 0,
                    int(item.get("score", 0) or 0),
                    float(item.get("duration_seconds", 0) or 0),
                    float(item.get("aircraft_score", 0) or 0),
                    float(item.get("meteor_score", 0) or 0),
                    str(metadata_path),
                    str(video) if video else None,
                    str(thumb) if thumb else None,
                    str(overlay) if overlay else None,
                    str(recordings_root),
                    storage_location,
                    json.dumps(item, ensure_ascii=False, separators=(",", ":")),
                    dt.datetime.now().isoformat(),
                ),
            )
            if sequence > 0:
                con.execute(
                    """
                    INSERT INTO daily_sequences(day, last_sequence) VALUES (?, ?)
                    ON CONFLICT(day) DO UPDATE SET
                        last_sequence = MAX(last_sequence, excluded.last_sequence)
                    """,
                    (day, sequence),
                )
        return item

    def allocate_sequence(self, day: str) -> int:
        """Return the next persistent sequence number for a calendar day."""
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT last_sequence FROM daily_sequences WHERE day=?", (day,)).fetchone()
            if row is None:
                maximum = con.execute("SELECT COALESCE(MAX(sequence), 0) FROM events WHERE day=?", (day,)).fetchone()[0]
                next_value = int(maximum or 0) + 1
                con.execute("INSERT INTO daily_sequences(day, last_sequence) VALUES (?, ?)", (day, next_value))
            else:
                next_value = int(row[0]) + 1
                con.execute("UPDATE daily_sequences SET last_sequence=? WHERE day=?", (next_value, day))
            con.commit()
            return next_value

    @staticmethod
    def _row_item(row: sqlite3.Row) -> dict:
        try:
            item = json.loads(row["data_json"])
        except Exception:
            item = {}
        item.update(
            id=row["id"],
            created_at=row["created_at"],
            day=row["day"],
            daily_sequence=int(row["sequence"] or 0),
            classification=row["classification"],
            favorite=bool(row["favorite"]),
            score=int(row["score"] or 0),
            duration_seconds=float(row["duration_seconds"] or 0),
            aircraft_score=float(row["aircraft_score"] or 0),
            meteor_score=float(row["meteor_score"] or 0),
            storage_location=row["storage_location"],
        )
        return item

    def events(self, limit=200, offset=0, day=None, favorites=False, classification=None) -> list[dict]:
        clauses = []
        args: list = []
        if day:
            clauses.append("day=?")
            args.append(str(day))
        if favorites:
            clauses.append("favorite=1")
        if classification:
            clauses.append("classification=?")
            args.append(str(classification).lower())
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        if classification or favorites:
            order = " ORDER BY created_at DESC"
        else:
            # VIGILIS is a meteor station: meteors are intentionally first in
            # the combined archive, followed by unknowns and aircraft.
            order = " ORDER BY CASE classification WHEN 'meteor' THEN 0 WHEN 'unknown' THEN 1 WHEN 'aircraft' THEN 2 ELSE 3 END, created_at DESC"
        sql = "SELECT * FROM events" + where + order
        if limit is not None:
            sql += " LIMIT ? OFFSET ?"
            args.extend([max(1, int(limit)), max(0, int(offset))])
        with self._connect() as con:
            rows = con.execute(sql, args).fetchall()
        return [self._row_item(row) for row in rows]

    def count(self, day=None, favorites=False, classification=None) -> int:
        clauses = []
        args: list = []
        if day:
            clauses.append("day=?")
            args.append(str(day))
        if favorites:
            clauses.append("favorite=1")
        if classification:
            clauses.append("classification=?")
            args.append(str(classification).lower())
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        with self._connect() as con:
            return int(con.execute("SELECT COUNT(*) FROM events" + where, args).fetchone()[0])

    def event_days(self) -> list[dict]:
        with self._connect() as con:
            rows = con.execute(
                """
                SELECT day, classification, COUNT(*) AS count
                FROM events
                GROUP BY day, classification
                ORDER BY day DESC
                """
            ).fetchall()
        days: dict[str, dict] = {}
        for row in rows:
            entry = days.setdefault(row["day"], {"date": row["day"], "count": 0, "classifications": {}})
            count = int(row["count"])
            entry["count"] += count
            entry["classifications"][row["classification"]] = count
        return [days[key] for key in sorted(days, reverse=True)]

    def summary(self, day: str | None = None) -> dict:
        day = day or dt.date.today().isoformat()
        with self._connect() as con:
            rows = con.execute(
                "SELECT classification, storage_location, COUNT(*) AS count FROM events WHERE day=? GROUP BY classification, storage_location",
                (day,),
            ).fetchall()
        result = {
            "day": day,
            "total": 0,
            "meteor": 0,
            "aircraft": 0,
            "unknown": 0,
            "ssd": 0,
            "sd": 0,
        }
        for row in rows:
            count = int(row["count"])
            classification = str(row["classification"])
            storage = str(row["storage_location"])
            result["total"] += count
            if classification in result:
                result[classification] += count
            if storage in result:
                result[storage] += count
        return result

    def get(self, event_id: str) -> dict | None:
        with self._connect() as con:
            row = con.execute("SELECT * FROM events WHERE id=?", (str(event_id),)).fetchone()
        return self._row_item(row) if row else None

    def paths(self, event_id: str) -> dict | None:
        with self._connect() as con:
            row = con.execute(
                "SELECT metadata_path, video_path, thumbnail_path, overlay_path, storage_root FROM events WHERE id=?",
                (str(event_id),),
            ).fetchone()
        return dict(row) if row else None

    def metadata_path(self, event_id: str) -> Path | None:
        paths = self.paths(event_id)
        return Path(paths["metadata_path"]) if paths and paths.get("metadata_path") else None

    def event_file(self, event_id: str, kind: str) -> Path | None:
        paths = self.paths(event_id)
        if not paths:
            return None
        key = {"video": "video_path", "thumbnail": "thumbnail_path", "overlay": "overlay_path"}.get(kind)
        raw = paths.get(key) if key else None
        return Path(raw) if raw else None

    def delete(self, event_id: str) -> None:
        with self._connect() as con:
            con.execute("DELETE FROM events WHERE id=?", (str(event_id),))

    def _get_meta(self, key: str) -> str | None:
        with self._connect() as con:
            row = con.execute("SELECT value FROM index_meta WHERE key=?", (key,)).fetchone()
        return str(row[0]) if row else None

    def _set_meta(self, key: str, value: str) -> None:
        with self._connect() as con:
            con.execute(
                "INSERT INTO index_meta(key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, str(value)),
            )

    def rebuild(self, recordings_root: Path, force: bool = True) -> dict:
        recordings_root = Path(recordings_root).resolve()
        root_string = str(recordings_root)
        if not force and self.count() > 0 and self._get_meta("indexed_root") == root_string:
            return {"started": False, "reason": "already indexed", **self.status()}

        scan_started=dt.datetime.now().isoformat()
        with self._index_lock:
            self._status.update(
                running=True,
                processed=0,
                total=0,
                error="",
                root=root_string,
                started_at=dt.datetime.now().isoformat(),
                finished_at=None,
            )
        try:
            files = list(recordings_root.rglob("event_*.json")) if recordings_root.exists() else []
            with self._index_lock:
                self._status["total"] = len(files)
            found: set[str] = set()
            for number, path in enumerate(files, start=1):
                try:
                    data = json.loads(path.read_text(encoding="utf-8"))
                    event_id = str(data.get("id") or path.stem)
                    found.add(event_id)
                    self.upsert(data, path, recordings_root)
                except Exception as exc:
                    if self.logger:
                        self.logger.warning("Event index skipped %s: %s", path, exc)
                with self._index_lock:
                    self._status["processed"] = number

            # Remove stale rows from this root, but preserve events created
            # while the background scan was running. Their updated_at value is
            # newer than scan_started and they may not have been in the initial
            # file list yet.
            with self._connect() as con:
                rows = con.execute("SELECT id, updated_at FROM events WHERE storage_root=?", (root_string,)).fetchall()
                stale = [row["id"] for row in rows if row["id"] not in found and str(row["updated_at"]) < scan_started]
                con.executemany("DELETE FROM events WHERE id=?", ((event_id,) for event_id in stale))
            self._set_meta("indexed_root", root_string)
            self._set_meta("indexed_at", dt.datetime.now().isoformat())
        except Exception as exc:
            with self._index_lock:
                self._status["error"] = str(exc)
            if self.logger:
                self.logger.exception("Event index rebuild failed")
        finally:
            with self._index_lock:
                self._status["running"] = False
                self._status["finished_at"] = dt.datetime.now().isoformat()
        return self.status()

    def start_rebuild(self, recordings_root: Path, force: bool = True) -> dict:
        recordings_root = Path(recordings_root).resolve()
        with self._index_lock:
            already_running = bool(self._index_thread and self._index_thread.is_alive())
        if already_running:
            return {"started": False, "reason": "already running", **self.status()}
        if not force and self.count() > 0 and self._get_meta("indexed_root") == str(recordings_root):
            return {"started": False, "reason": "already indexed", **self.status()}
        with self._index_lock:
            # Check again after acquiring the lock so two requests cannot launch
            # two recursive scans at the same time.
            if self._index_thread and self._index_thread.is_alive():
                launch = False
            else:
                self._status.update(
                    running=True, processed=0, total=0, error="",
                    root=str(recordings_root), started_at=dt.datetime.now().isoformat(),
                    finished_at=None,
                )
                self._index_thread = threading.Thread(
                    target=self.rebuild,
                    args=(recordings_root, force),
                    daemon=True,
                    name="event-index-rebuild",
                )
                self._index_thread.start()
                launch = True
        if not launch:
            return {"started": False, "reason": "already running", **self.status()}
        return {"started": True, **self.status()}

    def status(self) -> dict:
        with self._index_lock:
            status = dict(self._status)
        status["events"] = self.count()
        status["database"] = str(self.db_path)
        status["indexed_root"] = self._get_meta("indexed_root") or ""
        status["indexed_at"] = self._get_meta("indexed_at") or ""
        return status
