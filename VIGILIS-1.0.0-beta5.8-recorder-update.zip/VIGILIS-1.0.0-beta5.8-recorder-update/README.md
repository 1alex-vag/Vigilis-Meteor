# VIGILIS 1.0 Beta 5.2

- Fast SQLite event catalogue stored on the Raspberry Pi system drive.
- Event browser organized by day and classification, with Meteors first.
- Paginated event loading and direct indexed video/thumbnail delivery.
- Sortable daily event names: `event_YYYYMMDD_HHMMSS_NNN`.
- Optional lens cover with configurable 0.5° pre-opening and detector reset.
- Sun altitude, date and time remain visible in mobile portrait and landscape views.
- Safe internal-SD fallback when the preferred external drive is unavailable.

# VIGILIS Meteor 1.0 RC7

Release candidate focused on event review and detector transparency.

Highlights:
- YUV420 to Y8 astronomy mono pipeline
- detection overlay in the event player
- marked event thumbnails and JSON detection coordinates
- date-based recording folders
- complete paginated event archive
- safe event deletion from the web UI
- bottom-of-frame exclusion and custom detection masks
- timezone-aware solar altitude
- selectable 1-15, 20, 25 and 30 FPS


# VIGILIS 1.0 Beta 5.1

- Protected Favorites archive; favorites survive day deletion and automatic cleanup.
- Selectable recording location for internal storage, USB SSDs and HDDs.
- Multi-select and bulk event deletion.
- Delete complete day folders while preserving favorites.
- Automatic event cleanup after 1, 3, 7, 14 or 30 days.
- Configurable detection-overlay margin.
- VIGILIS Event Stack export for a complete observation night.
- Existing RC7 event grouping and overlay-video export retained.
