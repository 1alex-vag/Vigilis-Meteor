#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${VIGILIS_DIR:-$HOME/vigilis}"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
SERVICE_NAME="vigilis.service"

if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
  echo "ERROR: Do not run this installer with sudo." >&2
  echo "Run it as your normal user instead:" >&2
  echo "  ./install.sh" >&2
  exit 1
fi

echo "VIGILIS 1.0.0 Beta 5.7 Climate Layout installer"
echo "Target: $APP_DIR"

if [[ -d "$APP_DIR" ]]; then
  BACKUP="$HOME/vigilis_backup_$(date +%Y%m%d_%H%M%S)"
  echo "[1/6] Existing installation found. Creating backup: $BACKUP"
  echo "      This may take several minutes when recordings or many small files exist."
  mkdir -p "$BACKUP"
  rsync -a --exclude 'recordings/' --exclude 'data/' --exclude 'logs/' --exclude 'backups/' --exclude '.venv/' "$APP_DIR/" "$BACKUP/"
  echo "      Backup complete."
fi

echo "[2/6] Installing application files..."
mkdir -p "$APP_DIR"
rsync -a --delete --exclude 'config.yaml' --exclude 'recordings/' --exclude 'logs/' --exclude 'data/' --exclude 'backups/' "$SRC_DIR/" "$APP_DIR/"
[[ -f "$APP_DIR/config.yaml" ]] || cp "$SRC_DIR/config.example.yaml" "$APP_DIR/config.yaml"
find "$APP_DIR" -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
find "$APP_DIR" -type f -name "*.pyc" -delete 2>/dev/null || true
mkdir -p "$APP_DIR/recordings" "$APP_DIR/logs" "$APP_DIR/data" "$APP_DIR/backups" "$APP_DIR/vigilis/tuning"

echo "[3/6] Checking system dependencies..."
sudo apt-get update
sudo apt-get install -y python3-venv python3-pip python3-numpy python3-opencv python3-picamera2 libusb-1.0-0 ffmpeg rsync curl util-linux parted e2fsprogs exfatprogs ntfs-3g
echo "[4/6] Updating Python environment..."
python3 -m venv --system-site-packages "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"
"$APP_DIR/.venv/bin/python" "$APP_DIR/tools/generate_tuning_profiles.py"

sed -e "s|__USER__|$USER|g" -e "s|__APP_DIR__|$APP_DIR|g" "$APP_DIR/systemd/vigilis.service.in" | sudo tee "/etc/systemd/system/$SERVICE_NAME" >/dev/null

# Permit the VIGILIS service user to perform only the three explicit system actions exposed in the UI.
SUDOERS_FILE="/etc/sudoers.d/vigilis"
printf '%s\n' "$USER ALL=(root) NOPASSWD: /bin/systemctl restart vigilis.service, /bin/systemctl reboot, /bin/systemctl poweroff, /usr/bin/systemctl restart vigilis.service, /usr/bin/systemctl reboot, /usr/bin/systemctl poweroff" | sudo tee "$SUDOERS_FILE" >/dev/null
sudo chmod 0440 "$SUDOERS_FILE"

# Install the root-owned signed-update verifier/installer.
sudo install -d -m 0755 /etc/vigilis
sudo install -m 0644 "$APP_DIR/systemd/update_public.pem" /etc/vigilis/update_public.pem
sed -e "s|__APP_DIR__|$APP_DIR|g" "$APP_DIR/systemd/vigilis-update-helper.in" | sudo tee /usr/local/sbin/vigilis-update-helper >/dev/null
sudo chmod 0755 /usr/local/sbin/vigilis-update-helper
sed -e "s|__APP_DIR__|$APP_DIR|g" "$APP_DIR/systemd/vigilis-update-launcher.in" | sudo tee /usr/local/sbin/vigilis-update-launcher >/dev/null
sudo chmod 0755 /usr/local/sbin/vigilis-update-launcher
sudo install -m 0755 "$APP_DIR/systemd/vigilis-dev-update-mode" /usr/local/sbin/vigilis-dev-update-mode
printf '%s\n' "$USER ALL=(root) NOPASSWD: /usr/local/sbin/vigilis-dev-update-mode status, /usr/local/sbin/vigilis-dev-update-mode enable, /usr/local/sbin/vigilis-dev-update-mode disable" | sudo tee -a "$SUDOERS_FILE" >/dev/null
sudo chmod 0440 "$SUDOERS_FILE"
printf '%s\n' "$USER ALL=(root) NOPASSWD: /usr/local/sbin/vigilis-update-helper --verify-only *, /usr/local/sbin/vigilis-update-launcher *" | sudo tee -a "$SUDOERS_FILE" >/dev/null
sudo chmod 0440 "$SUDOERS_FILE"

# Install the root-owned external-storage helper. It validates USB block devices before any destructive action.
sudo install -m 0755 "$APP_DIR/systemd/vigilis-storage-helper" /usr/local/sbin/vigilis-storage-helper
printf '%s\n' "$USER ALL=(root) NOPASSWD: /usr/local/sbin/vigilis-storage-helper *" | sudo tee -a "$SUDOERS_FILE" >/dev/null
sudo chmod 0440 "$SUDOERS_FILE"

sudo install -m 0755 systemd/vigilis-zwo-permissions /usr/local/sbin/vigilis-zwo-permissions
sudo /usr/local/sbin/vigilis-zwo-permissions || true
echo "[5/6] Installing service and hardware helpers..."
sudo systemctl daemon-reload
sudo install -m 0755 systemd/vigilis-zwo-permissions /usr/local/sbin/vigilis-zwo-permissions
sudo /usr/local/sbin/vigilis-zwo-permissions || true
sudo systemctl daemon-reload
sudo systemctl enable --now "$SERVICE_NAME"

echo "[6/6] Starting VIGILIS and running health checks..."
HEALTH_OK=0
for _ in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:5000/api/status >/dev/null 2>&1 && \
     curl -fsS http://127.0.0.1:5000/api/camera/scan >/dev/null 2>&1; then
    HEALTH_OK=1
    break
  fi
  sleep 1
done
if [[ "$HEALTH_OK" != "1" ]]; then
  echo "ERROR: VIGILIS health check failed." >&2
  sudo systemctl status "$SERVICE_NAME" --no-pager -l || true
  sudo journalctl -u "$SERVICE_NAME" -n 80 --no-pager || true
  exit 1
fi

echo
echo "Installation complete."
echo "Open: http://$(hostname -I | awk '{print $1}'):5000"
echo "Service status: sudo systemctl status $SERVICE_NAME"
